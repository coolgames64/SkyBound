using UnityEngine;
namespace Skybound {
[CreateAssetMenu(menuName="Skybound/Aircraft catalog")]
public class AircraftCatalog:ScriptableObject {
 public AircraftEntry[] Aircraft;
}
[System.Serializable] public class AircraftEntry {
 public string Name="Passenger airliner",Source="",License="",ResourcePath="",CockpitResourcePath="";
 public GameObject Prefab,CockpitPrefab; public float Length=37,YawOffset,PitchOffset,RollOffset;
 public Vector3 CockpitOffset=new Vector3(0,2,14);
}
}
