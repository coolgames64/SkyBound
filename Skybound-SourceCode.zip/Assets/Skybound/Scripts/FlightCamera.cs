using UnityEngine;
namespace Skybound {
public class FlightCamera:MonoBehaviour {
 public FlightController Aircraft;
 public bool Cockpit,Cabin,Discover=true;
 public string ViewName=>Cabin?"Cabin":Cockpit?"Cockpit":"Chase";
 public float Orbit=22,Distance=85,OrbitElevation=16,MouseSensitivity=.16f;
 float lookYaw,lookPitch,smoothLookYaw,smoothLookPitch,smoothOrbit=22,smoothElevation=16;bool looking,leftWasDown,leftLooking,snapView;int touchLook=-1;FlightHUD hud;AircraftVisual visual;Camera viewCamera;
 void Start(){hud=Object.FindFirstObjectByType<FlightHUD>();visual=Aircraft.Visual.GetComponent<AircraftVisual>();viewCamera=GetComponent<Camera>();}
 float DefaultLookPitch=>Cockpit&&visual&&visual.UsesSharedCockpit?7:0;
 public void ToggleView(){if(Cabin){Cabin=false;Cockpit=false;}else if(Cockpit){Cockpit=false;Cabin=true;}else Cockpit=true;lookYaw=smoothLookYaw=0;lookPitch=smoothLookPitch=DefaultLookPitch;snapView=true;ReleaseMouse();}
 void ReleaseMouse(){looking=false;leftLooking=false;touchLook=-1;Cursor.lockState=CursorLockMode.None;Cursor.visible=true;}
 void OnDisable(){ReleaseMouse();}
 void OnApplicationFocus(bool focus){if(!focus)ReleaseMouse();}
 void ApplyLook(Vector2 delta){if(Cockpit||Cabin){lookYaw=Cabin?lookYaw+delta.x:Mathf.Clamp(lookYaw+delta.x,-140,140);lookPitch=Mathf.Clamp(lookPitch-delta.y,-65,65);}else{Orbit+=delta.x;OrbitElevation=Mathf.Clamp(OrbitElevation-delta.y,-12,80);}}
 void LateUpdate(){
  if(!Aircraft)return;
  bool flight=hud&&hud.Menu==MenuPage.Flight&&(!hud.Mission.Finished||hud.ResultsDismissed);
  bool left=FlightInput.LeftMouseHeld;
  if(left&&!leftWasDown)leftLooking=flight&&!hud.PointerOverControl(FlightInput.PointerPosition);
  if(!left||!flight)leftLooking=false;leftWasDown=left;
  bool right=FlightInput.MouseLookHeld&&hud&&(flight||hud.Menu==MenuPage.Discover);
  if(right){if(!looking){looking=true;Cursor.lockState=CursorLockMode.Locked;Cursor.visible=false;}}else if(looking){looking=false;Cursor.lockState=CursorLockMode.None;Cursor.visible=true;}
  if(right||leftLooking)ApplyLook(FlightInput.MouseDelta*MouseSensitivity);
  if(flight){
   ApplyLook(FlightInput.ControllerLook*Time.unscaledDeltaTime*100);
   if(hud.MobileControls){
    if(touchLook<0){for(int i=0;i<FlightInput.TouchCount;i++){if(FlightInput.Touch(i,out var pos,out var delta,out bool began)&&began&&!hud.PointerOverControl(pos)){touchLook=i;break;}}}
    if(touchLook>=0){if(FlightInput.Touch(touchLook,out var pos,out var delta,out bool began))ApplyLook(delta*MouseSensitivity);else touchLook=-1;}
   }
  }else touchLook=-1;
  if(FlightInput.Down(KeyCode.B)){lookYaw=0;lookPitch=DefaultLookPitch;Orbit=22;OrbitElevation=16;Distance=85;}
  if(hud&&hud.Menu==MenuPage.Flight&&!Cockpit&&!Cabin)Distance=Mathf.Clamp(Distance-FlightInput.MouseWheel*8,45,240);
  float lookBlend=1-Mathf.Exp(-Time.unscaledDeltaTime*14);smoothLookYaw=Mathf.Lerp(smoothLookYaw,lookYaw,lookBlend);smoothLookPitch=Mathf.Lerp(smoothLookPitch,lookPitch,lookBlend);
  Vector3 p=Aircraft.RenderPosition;Quaternion rotation=Aircraft.RenderRotation,yaw=Quaternion.Euler(0,rotation.eulerAngles.y,0);
  visual.SetCockpitVisible(Cockpit&&!Discover);visual.SetCabinVisible(Cabin&&!Discover);visual.PlaceInteriors(p,rotation);
  visual.SetExteriorVisible(Discover||(!Cockpit&&!Cabin));
  Camera camera=viewCamera;
  if((Cockpit||Cabin)&&!Discover){transform.position=p+rotation*(Cabin?visual.CabinOffset:visual.CockpitOffset);transform.rotation=rotation*Quaternion.Euler(smoothLookPitch,smoothLookYaw,0);camera.fieldOfView=Cabin?82:78;camera.nearClipPlane=.04f;snapView=false;return;}
  camera.nearClipPlane=.5f;
  float distance=Discover?105:Distance;
  smoothOrbit=Mathf.LerpAngle(smoothOrbit,Orbit,lookBlend);smoothElevation=Mathf.Lerp(smoothElevation,OrbitElevation,lookBlend);
  Vector3 offset=yaw*Quaternion.Euler(smoothElevation,smoothOrbit,0)*new Vector3(0,0,-distance);
  Vector3 desired=p+offset;float ground=Aircraft.World?Aircraft.World.HeightAt(desired):0;desired.y=Mathf.Max(ground+12,desired.y);
  transform.position=snapView?desired:Vector3.Lerp(transform.position,desired,1-Mathf.Exp(-Time.unscaledDeltaTime*9));
  Vector3 target=p+yaw*(Discover?new Vector3(-42,-4,15):new Vector3(0,2,12));
  Quaternion desiredRotation=Quaternion.LookRotation(target-transform.position,Vector3.up);
  transform.rotation=snapView?desiredRotation:Quaternion.Slerp(transform.rotation,desiredRotation,1-Mathf.Exp(-Time.unscaledDeltaTime*12));snapView=false;
  camera.fieldOfView=Discover?50:62;
 }
}
}
