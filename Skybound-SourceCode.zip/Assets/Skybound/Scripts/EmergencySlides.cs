using System.Collections.Generic;
using UnityEngine;
namespace Skybound {
// Shared inflatable exit-slide layout, fitted to the selected airframe. No physics colliders are added.
public class EmergencySlides:MonoBehaviour {
 public AircraftVisual Visual;
 public bool Deployed {get;private set;} public float Inflation {get;private set;}
 public bool CanDeploy {
  get {if(!Visual||Visual.Loading||!Visual.Aircraft)return false;var a=Visual.Aircraft;if(a.Mission&&a.Mission.RunwayStartMode&&(a.Mission.WaitingForTakeoff||a.Mission.PreparingChallenge))return false;
   bool landed=a.Grounded&&a.Speed<5||a.Mission&&a.Mission.Finished&&!a.Active;
   return !Deployed&&landed&&Mathf.Abs(a.Roll)<=20&&Mathf.Abs(a.Pitch)<=20&&a.HeightAboveGround<=a.GroundClearance+1.5f;
  }
 }
 readonly List<GameObject> roots=new List<GameObject>();readonly List<Mesh> meshes=new List<Mesh>();readonly List<Material> materials=new List<Material>();
 int selection=-1;float deployedAt;bool evacuated;
 public static EmergencySlides For(AircraftVisual visual){var slides=visual.GetComponent<EmergencySlides>();if(!slides)slides=visual.gameObject.AddComponent<EmergencySlides>();slides.Visual=visual;return slides;}
 public void SetVisible(bool value){if(value)Deploy();else ResetSlides();}
 public void Deploy(){
  if(!CanDeploy)return;ResetSlides();selection=Visual.Selected;Deployed=true;evacuated=true;deployedAt=Time.unscaledTime;
  var a=Visual.Aircraft;a.StopForEvacuation();a.Mission?.Notify("EVACUATION · Exit slides inflating. Engines stopped.");
  float width=AircraftCabin.WidthFor(Visual.StockAircraftName),length=Visual.AircraftLength;
  var grey=Material(new Color(.52f,.57f,.59f),.22f);var black=Material(new Color(.045f,.05f,.055f),.15f);var yellow=Material(new Color(.92f,.7f,.16f),.2f);
  var stations=length>55?new[]{-.29f,.02f,.29f}:new[]{-.28f,.28f};
  foreach(float station in stations)for(int side=-1;side<=1;side+=2){
   Vector3 top=new Vector3(side*width*.51f,Visual.InteriorFloorHeight+.12f,station*length);
   Vector3 worldTop=transform.TransformPoint(top),outward=transform.TransformDirection(Vector3.right*side);outward.y=0;outward.Normalize();
   float ground=a.World?a.World.HeightAt(worldTop):0,height=Mathf.Max(.7f,worldTop.y-ground);
   Vector3 worldEnd=worldTop+outward*Mathf.Clamp(height*1.35f,2,18);worldEnd.y=(a.World?a.World.HeightAt(worldEnd):0)+.26f;
   Vector3 end=transform.InverseTransformPoint(worldEnd)-top;
   var root=new GameObject("Inflatable exit slide");root.transform.SetParent(transform,false);root.transform.localPosition=top;roots.Add(root);
   var rubber=new AirlinerMeshBatch();var floor=new AirlinerMeshBatch();var markings=new AirlinerMeshBatch();float half=.78f;
   // The two outer rails and centre rail form a two-lane slide with a soft bottom cross tube.
   for(int rail=-1;rail<=1;rail++)Tube(rubber,new Vector3(0,.14f,rail*half),end+new Vector3(0,.14f,rail*half),rail==0?.10f:.15f);
   Tube(rubber,new Vector3(0,.14f,-half),new Vector3(0,.14f,half),.15f);Tube(rubber,end+new Vector3(0,.14f,-half),end+new Vector3(0,.14f,half),.17f);
   floor.Quad(new Vector3(0,0,-half),new Vector3(0,0,half),end+new Vector3(0,0,half),end+new Vector3(0,0,-half));
   for(int step=0;step<14;step++){float t=(step+.5f)/14;Vector3 p=Vector3.Lerp(Vector3.zero,end,t);markings.Box(p+new Vector3(0,.02f,0),new Vector3(.065f,.015f,1.15f));}
   rubber.Box(new Vector3(-side*.02f,.7f,0),new Vector3(.08f,1.6f,.96f));
   floor.Box(new Vector3(side*.045f,.7f,0),new Vector3(.055f,1.45f,.77f));
   meshes.Add(rubber.Create(root.transform,"Inflated rails and door frame",grey));meshes.Add(floor.Create(root.transform,"Slide surface and open doorway",black));meshes.Add(markings.Create(root.transform,"Exit slide markings",yellow));
   root.transform.localScale=Vector3.one*.01f;
  }
 }
 Material Material(Color color,float smooth){var material=SkyboundBootstrap.MakeMaterial(color);material.SetFloat("_Cull",0);material.SetFloat("_Smoothness",smooth);materials.Add(material);return material;}
 static void Tube(AirlinerMeshBatch batch,Vector3 from,Vector3 to,float radius){Vector3 axis=(to-from).normalized,u=Vector3.Cross(axis,Vector3.forward).normalized;if(u.sqrMagnitude<.1f)u=Vector3.Cross(axis,Vector3.up).normalized;Vector3 v=Vector3.Cross(axis,u);const int sides=12;
  for(int i=0;i<sides;i++){float a=i*Mathf.PI*2/sides,b=(i+1)*Mathf.PI*2/sides;Vector3 p=(u*Mathf.Cos(a)+v*Mathf.Sin(a))*radius,q=(u*Mathf.Cos(b)+v*Mathf.Sin(b))*radius;batch.Quad(from+p,from+q,to+q,to+p);batch.Triangle(from,from+q,from+p);batch.Triangle(to,to+p,to+q);}
 }
 void Update(){if(!Visual)return;if(selection>=0&&Visual.Selected!=selection){ResetSlides();return;}if(evacuated&&(Visual.Aircraft.Active||!Visual.Aircraft.Grounded||Visual.Aircraft.HeightAboveGround>Visual.Aircraft.GroundClearance+1.5f)){ResetSlides();return;}if(!Deployed)return;Inflation=Mathf.SmoothStep(0,1,Mathf.Clamp01((Time.unscaledTime-deployedAt)/2.4f));foreach(var root in roots)if(root)root.transform.localScale=Vector3.one*Mathf.Max(.01f,Inflation);}
 public void ResetSlides(){foreach(var root in roots)if(root)Destroy(root);roots.Clear();foreach(var mesh in meshes)if(mesh)Destroy(mesh);meshes.Clear();foreach(var material in materials)if(material)Destroy(material);materials.Clear();Deployed=evacuated=false;Inflation=0;selection=-1;}
 void OnDestroy(){ResetSlides();}
}
}
