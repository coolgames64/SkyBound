using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif
namespace Skybound {
public static class FlightInput {
 public static bool LeftMouseHeld {
 get {
#if ENABLE_INPUT_SYSTEM
 return Mouse.current!=null&&Mouse.current.leftButton.isPressed;
#else
 return Input.GetMouseButton(0);
#endif
 }}
 public static Vector2 PointerPosition {
 get {
#if ENABLE_INPUT_SYSTEM
 return Mouse.current!=null?Mouse.current.position.ReadValue():Vector2.zero;
#else
 return Input.mousePosition;
#endif
 }}
 public static int TouchCount {
 get {
#if ENABLE_INPUT_SYSTEM
 return Touchscreen.current!=null?Touchscreen.current.touches.Count:0;
#else
 return Input.touchCount;
#endif
 }}
 public static bool Touch(int index,out Vector2 position,out Vector2 delta,out bool began){
  position=delta=Vector2.zero;began=false;
#if ENABLE_INPUT_SYSTEM
 if(Touchscreen.current==null||index>=Touchscreen.current.touches.Count)return false;
 var touch=Touchscreen.current.touches[index];position=touch.position.ReadValue();delta=touch.delta.ReadValue();began=touch.phase.ReadValue()==UnityEngine.InputSystem.TouchPhase.Began;return touch.press.isPressed;
#else
 if(index>=Input.touchCount)return false;var touch=Input.GetTouch(index);position=touch.position;delta=touch.deltaPosition;began=touch.phase==TouchPhase.Began;return touch.phase!=TouchPhase.Ended&&touch.phase!=TouchPhase.Canceled;
#endif
 }
 public static Vector2 FlightStick {
 get {
#if ENABLE_INPUT_SYSTEM
 Vector2 stick=Joystick.current!=null?Joystick.current.stick.ReadValue():Vector2.zero;
 if(Gamepad.current!=null){var pad=Gamepad.current.leftStick.ReadValue();if(pad.sqrMagnitude>stick.sqrMagnitude)stick=pad;}
 float magnitude=stick.magnitude;if(magnitude<=.10f)return Vector2.zero;
 return stick.normalized*Mathf.Pow(Mathf.Clamp01((magnitude-.10f)/.90f),1.25f);
#else
 return Vector2.zero;
#endif
 }}
 public static Vector2 ControllerLook {
 get {
#if ENABLE_INPUT_SYSTEM
 return Gamepad.current!=null?Gamepad.current.rightStick.ReadValue():Vector2.zero;
#else
 return Vector2.zero;
#endif
 }}
 public static string ControllerName {
 get {
#if ENABLE_INPUT_SYSTEM
 if(Joystick.current!=null)return Joystick.current.displayName;
 if(Gamepad.current!=null)return Gamepad.current.displayName;
#endif
 return "No controller connected";
 }}
 public static bool MouseLookHeld {
 get {
#if ENABLE_INPUT_SYSTEM
 return Mouse.current!=null&&Mouse.current.rightButton.isPressed;
#else
 return Input.GetMouseButton(1);
#endif
 }}
 public static Vector2 MouseDelta {
 get {
#if ENABLE_INPUT_SYSTEM
 return Mouse.current!=null?Mouse.current.delta.ReadValue():Vector2.zero;
#else
 return new Vector2(Input.GetAxisRaw("Mouse X"),Input.GetAxisRaw("Mouse Y"))*15;
#endif
 }}
 public static float MouseWheel {
 get {
#if ENABLE_INPUT_SYSTEM
 return Mouse.current!=null?Mouse.current.scroll.ReadValue().y/120:0;
#else
 return Input.mouseScrollDelta.y;
#endif
 }}
 public static bool Hold(KeyCode k) {
#if ENABLE_INPUT_SYSTEM
 var kb=Keyboard.current;if(kb==null)return false; var key=Convert(k);return key!=Key.None&&kb[key].isPressed;
#else
 return Input.GetKey(k);
#endif
 }
 public static bool Down(KeyCode k) {
#if ENABLE_INPUT_SYSTEM
 var kb=Keyboard.current;if(kb==null)return false;var key=Convert(k);return key!=Key.None&&kb[key].wasPressedThisFrame;
#else
 return Input.GetKeyDown(k);
#endif
 }
#if ENABLE_INPUT_SYSTEM
 static Key Convert(KeyCode k){switch(k){case KeyCode.W:return Key.W;case KeyCode.S:return Key.S;case KeyCode.A:return Key.A;case KeyCode.D:return Key.D;case KeyCode.Q:return Key.Q;case KeyCode.E:return Key.E;case KeyCode.R:return Key.R;case KeyCode.F:return Key.F;case KeyCode.G:return Key.G;case KeyCode.H:return Key.H;case KeyCode.V:return Key.V;case KeyCode.T:return Key.T;case KeyCode.X:return Key.X;case KeyCode.P:return Key.P;case KeyCode.M:return Key.M;case KeyCode.C:return Key.C;case KeyCode.B:return Key.B;case KeyCode.K:return Key.K;case KeyCode.Space:return Key.Space;case KeyCode.Escape:return Key.Escape;case KeyCode.UpArrow:return Key.UpArrow;case KeyCode.DownArrow:return Key.DownArrow;case KeyCode.LeftArrow:return Key.LeftArrow;case KeyCode.RightArrow:return Key.RightArrow;case KeyCode.LeftShift:return Key.LeftShift;case KeyCode.RightShift:return Key.RightShift;case KeyCode.LeftControl:return Key.LeftCtrl;case KeyCode.RightControl:return Key.RightCtrl;default:return Key.None;}}
#endif
 }
}
