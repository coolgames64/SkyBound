using UnityEngine;
#if UNITY_WEBGL && !UNITY_EDITOR
using System.Runtime.InteropServices;
#endif
namespace Skybound {
public static class BrowserPlatform {
#if UNITY_WEBGL && !UNITY_EDITOR
 [DllImport("__Internal")] private static extern int Skybound_IsTouchDevice();
#endif
 public static bool Mobile {
  get {
#if UNITY_WEBGL && !UNITY_EDITOR
   return Skybound_IsTouchDevice()!=0;
#else
   return Application.isMobilePlatform;
#endif
  }
 }
}
}
