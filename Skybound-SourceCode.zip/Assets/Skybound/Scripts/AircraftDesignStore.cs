using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace Skybound {
[Serializable]
public class AircraftDesign {
 public string Id="",Name="My airliner";
 public int BaseAircraftIndex;
 public Color Tint=Color.white;
 public float ThrustMultiplier=1,ControlSensitivity=1;
}

// A design uses an included airframe. It does not create or replace the source model.
public static class AircraftDesignStore {
 public const string PreferenceKey="Skybound.AircraftDesigns.v1";
 public const int MaxDesigns=20,MaxNameLength=40,StockAircraftCount=24;
 public const float MinimumMultiplier=.75f,MaximumMultiplier=1.25f;
 [Serializable]class SavedDesigns {public int Version=1;public List<AircraftDesign> Designs=new List<AircraftDesign>();}

 public static List<AircraftDesign> Load()=>Deserialize(PlayerPrefs.GetString(PreferenceKey,""));
 public static AircraftDesign Save(AircraftDesign design){
  if(design==null)return null;
  var safe=Sanitize(design);var designs=Load();int index=designs.FindIndex(item=>item.Id==safe.Id);
  if(index>=0)designs[index]=safe;
  else {if(designs.Count>=MaxDesigns)return null;designs.Add(safe);}
  PlayerPrefs.SetString(PreferenceKey,Serialize(designs));PlayerPrefs.Save();return Sanitize(safe);
 }
 public static bool Delete(string id){
  if(string.IsNullOrEmpty(id))return false;
  var designs=Load();int removed=designs.RemoveAll(item=>item.Id==id);if(removed==0)return false;
  PlayerPrefs.SetString(PreferenceKey,Serialize(designs));PlayerPrefs.Save();return true;
 }
 public static string Serialize(List<AircraftDesign> designs){return JsonUtility.ToJson(new SavedDesigns{Designs=Normalize(designs)});}
 public static List<AircraftDesign> Deserialize(string json){
  if(string.IsNullOrEmpty(json)||json.Length>100000)return new List<AircraftDesign>();
  try {var data=JsonUtility.FromJson<SavedDesigns>(json);return data!=null&&data.Version==1?Normalize(data.Designs):new List<AircraftDesign>();}
  catch(ArgumentException){return new List<AircraftDesign>();}
 }
 static List<AircraftDesign> Normalize(List<AircraftDesign> input){
  var output=new List<AircraftDesign>();var seen=new HashSet<string>();if(input==null)return output;
  foreach(var design in input){if(design==null)continue;var safe=Sanitize(design);if(!seen.Add(safe.Id))continue;output.Add(safe);if(output.Count==MaxDesigns)break;}
  return output;
 }
 public static AircraftDesign Sanitize(AircraftDesign design,int aircraftCount=StockAircraftCount){
  if(design==null)design=new AircraftDesign();
  string id=Guid.TryParse(design.Id,out var parsed)?parsed.ToString("N"):Guid.NewGuid().ToString("N");
  return new AircraftDesign{Id=id,Name=SanitizeName(design.Name),BaseAircraftIndex=Mathf.Clamp(design.BaseAircraftIndex,0,Mathf.Max(0,aircraftCount-1)),Tint=SanitizeTint(design.Tint),ThrustMultiplier=ClampMultiplier(design.ThrustMultiplier),ControlSensitivity=ClampMultiplier(design.ControlSensitivity)};
 }
 public static float ClampMultiplier(float value)=>Finite(value)?Mathf.Clamp(value,MinimumMultiplier,MaximumMultiplier):1;
 public static Color SanitizeTint(Color value)=>new Color(Channel(value.r),Channel(value.g),Channel(value.b),1);
 static float Channel(float value)=>Finite(value)?Mathf.Clamp01(value):1;
 static bool Finite(float value)=>!float.IsNaN(value)&&!float.IsInfinity(value);
 public static string SanitizeName(string value){
  var name=new StringBuilder();bool space=false;
  foreach(char c in value??""){
   if(char.IsWhiteSpace(c)){space=name.Length>0;continue;}
   if(char.IsControl(c)||c=='<'||c=='>')continue;
   if(space&&name.Length<MaxNameLength)name.Append(' ');space=false;
   if(name.Length==MaxNameLength)break;name.Append(c);
  }
  string result=name.ToString().Trim();return result.Length==0?"My airliner":result;
 }
}
}
