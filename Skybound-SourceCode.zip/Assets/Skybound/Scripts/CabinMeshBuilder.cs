using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace Skybound {
// Cabin-only authoring. Geometry is built once and combined by material; no seat GameObjects survive.
internal sealed class CabinMeshBuilder {
 readonly List<Vector3> vertices=new List<Vector3>(1024),normals=new List<Vector3>(1024);
 readonly List<Vector2> uv=new List<Vector2>(1024);
 readonly List<int> triangles=new List<int>(1536);
 public int VertexCount=>vertices.Count;
 public int TriangleCount=>triangles.Count/3;
 static readonly Vector2 FlatUV=new Vector2(.1f,.5f);

 public void Quad(Vector3 a,Vector3 b,Vector3 c,Vector3 d){
  Vector3 n=Vector3.Cross(b-a,c-a).normalized;
  Quad(a,b,c,d,n,n,n,n,FlatUV,FlatUV,FlatUV,FlatUV);
 }
 public void Surface(Vector3 a,Vector3 b,Vector3 c,Vector3 d,Vector3 normal){
  Quad(a,b,c,d,normal,normal,normal,normal,FlatUV,FlatUV,FlatUV,FlatUV);
 }
 public void Quad(Vector3 a,Vector3 b,Vector3 c,Vector3 d,Vector3 na,Vector3 nb,Vector3 nc,Vector3 nd,
  Vector2 ua,Vector2 ub,Vector2 uc,Vector2 ud){
  int i=vertices.Count;
  Add(a,na,ua);Add(b,nb,ub);Add(c,nc,uc);Add(d,nd,ud);
  triangles.Add(i);triangles.Add(i+1);triangles.Add(i+2);triangles.Add(i);triangles.Add(i+2);triangles.Add(i+3);
 }
 public void Triangle(Vector3 a,Vector3 b,Vector3 c,Vector3 normal){
  int i=vertices.Count;Add(a,normal,FlatUV);Add(b,normal,FlatUV);Add(c,normal,FlatUV);
  triangles.Add(i);triangles.Add(i+1);triangles.Add(i+2);
 }
 void Add(Vector3 p,Vector3 n,Vector2 t){vertices.Add(p);normals.Add(n);uv.Add(t);}
 public void Box(Vector3 center,Vector3 size){Box(center,size,Quaternion.identity);}
 public void Box(Vector3 center,Vector3 size,Quaternion rotation){
  Vector3 e=size*.5f;
  Vector3 P(float x,float y,float z)=>center+rotation*new Vector3(x*e.x,y*e.y,z*e.z);
  Quad(P(-1,-1,-1),P(-1,1,-1),P(1,1,-1),P(1,-1,-1));
  Quad(P(-1,-1,1),P(1,-1,1),P(1,1,1),P(-1,1,1));
  Quad(P(-1,-1,-1),P(-1,-1,1),P(-1,1,1),P(-1,1,-1));
  Quad(P(1,-1,-1),P(1,1,-1),P(1,1,1),P(1,-1,1));
  Quad(P(-1,-1,-1),P(1,-1,-1),P(1,-1,1),P(-1,-1,1));
  Quad(P(-1,1,-1),P(-1,1,1),P(1,1,1),P(1,1,-1));
 }
 public void Carpet(float width,float length){
  Vector3 a=new Vector3(-width*.5f,.006f,-length*.5f),b=new Vector3(-width*.5f,.006f,length*.5f);
  Vector3 c=new Vector3(width*.5f,.006f,length*.5f),d=new Vector3(width*.5f,.006f,-length*.5f);
  Quad(a,b,c,d,Vector3.up,Vector3.up,Vector3.up,Vector3.up,new Vector2(0,0),new Vector2(0,length*5),new Vector2(width*5,length*5),new Vector2(width*5,0));
 }
 // A four-ring bevelled extrusion. Rounded edges have authored interpolated normals, rather than box faces.
 public void Cushion(Vector3 center,Vector3 size,Quaternion rotation,float radius,float bevel,int cornerSegments=2){
  float hx=size.x*.5f,hy=size.y*.5f,hz=size.z*.5f;
  radius=Mathf.Min(radius,Mathf.Min(hx,hy)*.85f);bevel=Mathf.Min(bevel,Mathf.Min(hz*.85f,Mathf.Min(hx,hy)*.35f));
  int count=4*(cornerSegments+1);
  var points=new Vector3[4,count];var ns=new Vector3[4,count];
  for(int ring=0;ring<4;ring++){
   float inset=ring==0||ring==3?bevel:0;
   float r=Mathf.Max(.004f,radius-inset*.35f),x=Mathf.Max(r,hx-inset),y=Mathf.Max(r,hy-inset);
   float z=ring==0?-hz:ring==1?-hz+bevel:ring==2?hz-bevel:hz;
   for(int corner=0;corner<4;corner++)for(int segment=0;segment<=cornerSegments;segment++){
    int i=corner*(cornerSegments+1)+segment;float angle=(corner*90+segment*90f/cornerSegments)*Mathf.Deg2Rad;
    float cx=corner==0||corner==3?x-r:-x+r,cy=corner<2?y-r:-y+r;
    Vector3 local=new Vector3(cx+Mathf.Cos(angle)*r,cy+Mathf.Sin(angle)*r,z);
    Vector3 n=new Vector3(Mathf.Cos(angle),Mathf.Sin(angle),ring==0?-.85f:ring==3?.85f:0).normalized;
    points[ring,i]=center+rotation*local;ns[ring,i]=rotation*n;
   }
  }
  Vector2 UV(int i,int ring)=>new Vector2(i/(float)count*3,ring*.33f);
  for(int ring=0;ring<3;ring++)for(int i=0;i<count;i++){
   int next=(i+1)%count;
   Quad(points[ring,i],points[ring,next],points[ring+1,next],points[ring+1,i],ns[ring,i],ns[ring,next],ns[ring+1,next],ns[ring+1,i],UV(i,ring),UV(i+1,ring),UV(i+1,ring+1),UV(i,ring+1));
  }
  Vector3 back=center+rotation*new Vector3(0,0,-hz),front=center+rotation*new Vector3(0,0,hz);
  for(int i=0;i<count;i++){
   int next=(i+1)%count;
   Cap(back,points[0,next],points[0,i],rotation*Vector3.back,center,rotation,size);
   Cap(front,points[3,i],points[3,next],rotation*Vector3.forward,center,rotation,size);
  }
 }
 // Thin padded armrests and tray faces need a rounded silhouette without three bevel bands.
 public void Panel(Vector3 center,Vector3 size,Quaternion rotation,float radius){
  float hx=size.x*.5f,hy=size.y*.5f,hz=size.z*.5f;radius=Mathf.Min(radius,Mathf.Min(hx,hy)*.85f);
  const int count=8;var p=new Vector3[2,count];var n=new Vector3[count];
  for(int corner=0;corner<4;corner++)for(int segment=0;segment<2;segment++){
   int i=corner*2+segment;float angle=(corner*90+segment*90)*Mathf.Deg2Rad;
   float cx=corner==0||corner==3?hx-radius:-hx+radius,cy=corner<2?hy-radius:-hy+radius;
   Vector3 q=new Vector3(cx+Mathf.Cos(angle)*radius,cy+Mathf.Sin(angle)*radius,0);n[i]=rotation*new Vector3(Mathf.Cos(angle),Mathf.Sin(angle),0);
   p[0,i]=center+rotation*(q+Vector3.back*hz);p[1,i]=center+rotation*(q+Vector3.forward*hz);
  }
  for(int i=0;i<count;i++){
   int next=(i+1)%count;
   Quad(p[0,i],p[0,next],p[1,next],p[1,i],n[i],n[next],n[next],n[i],FlatUV,FlatUV,FlatUV,FlatUV);
   Triangle(center+rotation*Vector3.back*hz,p[0,next],p[0,i],rotation*Vector3.back);
   Triangle(center+rotation*Vector3.forward*hz,p[1,i],p[1,next],rotation*Vector3.forward);
  }
 }
 void Cap(Vector3 a,Vector3 b,Vector3 c,Vector3 normal,Vector3 center,Quaternion rotation,Vector3 size){
  Vector2 UV(Vector3 p){Vector3 q=Quaternion.Inverse(rotation)*(p-center);return new Vector2(q.x/size.x*2+.5f,q.y/size.y*2+.5f);}
  int i=vertices.Count;Add(a,normal,UV(a));Add(b,normal,UV(b));Add(c,normal,UV(c));triangles.Add(i);triangles.Add(i+1);triangles.Add(i+2);
 }
 // Opaque wall connects each oval to all four edges of its rectangular module.
 public void WindowWall(float x,float y,float z,float moduleWidth,float bandHeight,float openingWidth,float openingHeight,int side){
  const int segments=24;
  Vector3 Outer(float t){float s=Mathf.Sin(t),c=Mathf.Cos(t),d=Mathf.Max(Mathf.Abs(s),Mathf.Abs(c));return new Vector3(x,y+c/d*bandHeight*.5f,z+s/d*moduleWidth*.5f);}
  Vector3 Inner(float t)=>new Vector3(x,y+Mathf.Cos(t)*openingHeight,z+Mathf.Sin(t)*openingWidth);
  for(int i=0;i<segments;i++){float a=i*Mathf.PI*2/segments,b=(i+1)*Mathf.PI*2/segments;Surface(Outer(a),Outer(b),Inner(b),Inner(a),new Vector3(-side,0,0));}
 }
 public void OvalRing(float x,float y,float z,float outerWidth,float outerHeight,float innerWidth,float innerHeight,int side){
  for(int i=0;i<24;i++){
   float a=i*Mathf.PI*2/24,b=(i+1)*Mathf.PI*2/24;
   Vector3 P(float t,float w,float h)=>new Vector3(x,y+Mathf.Cos(t)*h,z+Mathf.Sin(t)*w);
   Surface(P(a,outerWidth,outerHeight),P(b,outerWidth,outerHeight),P(b,innerWidth,innerHeight),P(a,innerWidth,innerHeight),new Vector3(-side,0,0));
  }
 }
 public void WindowReveal(float outerX,float innerX,float y,float z,float outerWidth,float outerHeight,float innerWidth,float innerHeight){
  for(int i=0;i<24;i++){
   float a=i*Mathf.PI*2/24,b=(i+1)*Mathf.PI*2/24;
   Vector3 P(float t,float x,float w,float h)=>new Vector3(x,y+Mathf.Cos(t)*h,z+Mathf.Sin(t)*w);
   Quad(P(a,outerX,outerWidth,outerHeight),P(b,outerX,outerWidth,outerHeight),P(b,innerX,innerWidth,innerHeight),P(a,innerX,innerWidth,innerHeight));
  }
 }
 public void Section(Vector2[] section,float z0,float z1){
  Vector2 center=Vector2.zero;float area=0;
  for(int i=0;i<section.Length;i++){var a=section[i];var b=section[(i+1)%section.Length];center+=a;area+=a.x*b.y-b.x*a.y;}center/=section.Length;
  for(int i=0;i<section.Length;i++){
   var a=section[i];var b=section[(i+1)%section.Length];
   if(area>0)Quad(new Vector3(a.x,a.y,z0),new Vector3(b.x,b.y,z0),new Vector3(b.x,b.y,z1),new Vector3(a.x,a.y,z1));
   else Quad(new Vector3(a.x,a.y,z0),new Vector3(a.x,a.y,z1),new Vector3(b.x,b.y,z1),new Vector3(b.x,b.y,z0));
   Triangle(new Vector3(center.x,center.y,z0),new Vector3(b.x,b.y,z0),new Vector3(a.x,a.y,z0),Vector3.back);
   Triangle(new Vector3(center.x,center.y,z1),new Vector3(a.x,a.y,z1),new Vector3(b.x,b.y,z1),Vector3.forward);
  }
 }
 public void Sign(Vector3 center,float width,float height,bool front){
  Vector3 a=center+new Vector3(-width*.5f,-height*.5f,0),b=center+new Vector3(-width*.5f,height*.5f,0);
  Vector3 c=center+new Vector3(width*.5f,height*.5f,0),d=center+new Vector3(width*.5f,-height*.5f,0);
  Vector3 normal=front?Vector3.forward:Vector3.back;
  // Looking aft reverses cabin-local X, so reverse U to keep the EXIT lettering readable.
  float leftU=front?1:.5f,rightU=front?.5f:1;
  Quad(a,b,c,d,normal,normal,normal,normal,new Vector2(leftU,0),new Vector2(leftU,1),new Vector2(rightU,1),new Vector2(rightU,0));
 }
 public Mesh Create(Transform parent,string name,Material material){
  var mesh=new Mesh{name=name};if(vertices.Count>65535)mesh.indexFormat=IndexFormat.UInt32;
  mesh.SetVertices(vertices);mesh.SetNormals(normals);mesh.SetUVs(0,uv);mesh.SetTriangles(triangles,0);mesh.RecalculateBounds();
  var go=new GameObject(name);go.transform.SetParent(parent,false);go.AddComponent<MeshFilter>().sharedMesh=mesh;
  var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=material;renderer.shadowCastingMode=ShadowCastingMode.Off;renderer.receiveShadows=false;
  return mesh;
 }
}
}
