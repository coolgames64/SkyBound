using UnityEngine;
namespace Skybound {
[RequireComponent(typeof(AudioSource))]
public class FlightAudio:MonoBehaviour {
 public FlightController Aircraft;public bool Muted;AudioSource source;
 void Start(){source=GetComponent<AudioSource>();source.loop=true;source.spatialBlend=0;source.volume=.08f;int samples=44100;var clip=AudioClip.Create("Synthesized turbine ambience",samples,1,44100,false);float[] data=new float[samples];System.Random random=new System.Random(42);float low=0;for(int i=0;i<samples;i++){low=low*.92f+(float)(random.NextDouble()*2-1)*.08f;data[i]=low*.5f+Mathf.Sin(i*Mathf.PI*2*90/44100)*.15f+Mathf.Sin(i*Mathf.PI*2*180/44100)*.05f;}clip.SetData(data,0);source.clip=clip;source.Play();}
 void Update(){if(!source)return;source.volume=Muted?0:Aircraft.Active?.018f+.112f*Aircraft.EnginePower:.015f;source.pitch=.5f+Aircraft.EnginePower*.9f;}
}
}
