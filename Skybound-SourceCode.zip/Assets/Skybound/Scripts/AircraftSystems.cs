namespace Skybound {
// Availability reflects the representative family; electrical/hydraulic power is simplified for gameplay.
public static class AircraftSystems {
 public static bool SupportsRAT(string aircraftName){
  string name=(aircraftName??"").ToUpperInvariant();
  return name.Contains("AIRBUS")||name.Contains("757")||name.Contains("767")||name.Contains("777")||name.Contains("787")||name.Contains("MD-11")||name.Contains("DC-10")||name.Contains("E190")||name.Contains("CONCORDE");
 }
}
}
