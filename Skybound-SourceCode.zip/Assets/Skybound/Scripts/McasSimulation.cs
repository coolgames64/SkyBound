using System;
namespace Skybound {
// A bounded gameplay approximation of updated MCAS safeguards, not aircraft software.
// Thresholds, rate and authority are deliberately simplified simulator values.
public sealed class McasSimulation {
 public const float ActivationAoa=12,RecoveryAoa=8,MaxTrimDegrees=1.8f,TrimRate=.7f;
 public bool Installed {get;private set;} public bool CutOut {get;private set;}
 public bool Active {get;private set;} public bool SensorDisagree {get;private set;}
 public float LeftSensorBias,RightSensorBias;
 public float NoseDownRate {get;private set;} public float TrimDegrees {get;private set;}
 public string Status {get;private set;}="NOT FITTED";
 bool fired;float activationTime,lowAoaTime;
 public void Reset(bool installed){Installed=installed;CutOut=Active=SensorDisagree=fired=false;LeftSensorBias=RightSensorBias=NoseDownRate=TrimDegrees=activationTime=lowAoaTime=0;Status=installed?"STANDBY":"NOT FITTED";}
 public void SetCutout(bool value){CutOut=value;Active=false;NoseDownRate=0;if(Installed)Status=value?"CUTOUT":"STANDBY";}
 public void Step(float dt,bool airborne,bool manualFlight,bool flapsUp,float actualAoa,bool powered,float pilotPitch){
  NoseDownRate=0;dt=Math.Max(0,Math.Min(.05f,dt));
  if(!Installed){Active=false;Status="NOT FITTED";return;}
  float left=actualAoa+LeftSensorBias,right=actualAoa+RightSensorBias;SensorDisagree=Math.Abs(left-right)>5;
  if(left<RecoveryAoa&&right<RecoveryAoa&&!SensorDisagree){lowAoaTime+=dt;if(lowAoaTime>=1){fired=Active=false;TrimDegrees=activationTime=0;}}else lowAoaTime=0;
  if(CutOut){Active=false;Status="CUTOUT";return;}
  if(SensorDisagree){Active=false;Status="AOA DISAGREE";return;}
  if(!airborne||!manualFlight||!flapsUp||!powered){Active=false;Status="STANDBY";return;}
  if(!fired&&left>=ActivationAoa&&right>=ActivationAoa){fired=Active=true;activationTime=0;}
  if(!Active){Status=fired?"CYCLE COMPLETE":"ARMED";return;}
  activationTime+=dt;
  if(activationTime>3||TrimDegrees>=MaxTrimDegrees){Active=false;Status="CYCLE COMPLETE";return;}
  if(pilotPitch>.15f){Status="PILOT OVERRIDE";return;}
  if(left<RecoveryAoa||right<RecoveryAoa){Active=false;Status="RECOVERING";return;}
  NoseDownRate=dt>0?Math.Min(TrimRate,(MaxTrimDegrees-TrimDegrees)/dt):0;
  TrimDegrees=Math.Min(MaxTrimDegrees,TrimDegrees+NoseDownRate*dt);Status="NOSE-DOWN TRIM";
 }
}
}
