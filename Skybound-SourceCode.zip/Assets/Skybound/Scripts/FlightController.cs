using UnityEngine;
namespace Skybound {
[DefaultExecutionOrder(-100)]
public class FlightController : MonoBehaviour {
 public McasSimulation Mcas {get;}=new McasSimulation();
 public bool McasInstalled=>Mcas.Installed;
 public void ToggleMcas(){if(!McasInstalled)return;Mcas.SetCutout(!Mcas.CutOut);Mission?.Notify(Mcas.CutOut?"MCAS (SIM) · Automatic trim cut out. Pitch control remains available.":"MCAS (SIM) · Automatic trim enabled. Flaps-up manual flight only.");}
 public float Speed=85,Throttle=.65f,Pitch,Roll,Heading=208,VerticalSpeed;
 public bool Engines=true,Gear,Assist,Stalled,Grounded,Active;
 public bool LeftEngine=true,RightEngine=true,GearJammedUp;
 public bool GearJammedDown,FlapsJammed,ThrottleJammed,BrakeHeld,AutoBrake;
 public float JammedThrottle=.3f;
 public float FuelRemaining=1,GustStrength;
 [SerializeField]float thrustMultiplier=1,controlSensitivity=1;
 public float ThrustMultiplier {get=>AircraftDesignStore.ClampMultiplier(thrustMultiplier);set=>thrustMultiplier=AircraftDesignStore.ClampMultiplier(value);}
 public float ControlSensitivity {get=>AircraftDesignStore.ClampMultiplier(controlSensitivity);set=>controlSensitivity=AircraftDesignStore.ClampMultiplier(value);}
 public bool RATAvailable=true,RATDeployed;
 public float RATPosition {get;private set;}
 public float EmergencyPower=>RATAvailable?RATPosition*Mathf.Clamp01((Speed-10)/35):0;
 public float ElectricalPower=>(Engines&&(LeftEngine||RightEngine)&&FuelRemaining>0)||EnginePower>.08f?1:EmergencyPower;
 public float GustWind=>Wind+GustStrength*(Mathf.Sin(Elapsed*.67f)*.65f+Mathf.Sin(Elapsed*1.71f)*.35f);
 public int Flaps;public float Elapsed,Wind,TargetHeading=208;
 public Transform Visual; public float Wingspan=35;
 public SatelliteWorld World;public MissionDirector Mission;
 public float TouchPitch,TouchRoll;
 public Vector3 RenderPosition {get;private set;} public Quaternion RenderRotation {get;private set;}
 public float EnginePower {get;private set;}
 public float LeftEnginePower {get;private set;} public float RightEnginePower {get;private set;}
 public float FlapPosition {get;private set;}
 public float FlightPathAngle {get;private set;}
 public float AngleOfAttack=>Pitch-FlightPathAngle;
 public float PitchRate {get;private set;} public float RollRate {get;private set;}
 public float LiftAcceleration {get;private set;} public float DragAcceleration {get;private set;}
 Vector3 previousPosition;Quaternion previousRotation;AircraftVisual aircraftVisual;bool flapJamCaptured;float jammedFlapPosition;
 public bool CatalogAllowsAssist=>!Mission||Mission.RunwayStartMode&&(Mission.WaitingForTakeoff||Mission.PreparingChallenge)||ChallengeCatalog.AllowsAssist(Mission.Mode);
 public bool CanRestartEngines=>Mission&&(Mission.Mode==FlightMode.FreeFlight||Mission.Mode==FlightMode.EngineRelight&&Mission.FaultTriggered&&FuelRemaining>0);
 // Interpolate the two fixed simulation poses so rendering stays smooth at any display refresh rate.
 void LateUpdate(){float alpha=Active&&Time.timeScale>0?Mathf.Clamp01((Time.time-Time.fixedTime)/Time.fixedDeltaTime):1;RenderPosition=Vector3.Lerp(previousPosition,transform.position,alpha);RenderRotation=Quaternion.Slerp(previousRotation,transform.rotation,alpha);if(Visual)Visual.SetPositionAndRotation(RenderPosition,RenderRotation);}


 public void Rebase(Vector3 shift){transform.position-=shift;previousPosition-=shift;RenderPosition-=shift;}
 float Density=>Mathf.Exp(-Mathf.Max(0,Altitude)/10500f);
 public float StallSpeed=>85*Mathf.Sqrt(.63f/((1.35f+FlapPosition*.5f)*Density));
 public float Altitude=>transform.position.y;
 public float GroundClearance {get {if(!aircraftVisual&&Visual)aircraftVisual=Visual.GetComponent<AircraftVisual>();return aircraftVisual?aircraftVisual.GroundClearance:3;}}
 public float HeightAboveGround=>Altitude-(World?World.HeightAt(transform.position):0);
 public Vector2d Coordinates=>World?World.Coordinates(transform.position):default;
 public void ConfigureAircraft(string name){var upper=(name??"").ToUpperInvariant();Mcas.Reset(upper.Contains("737")&&upper.Contains("MAX"));RATAvailable=AircraftSystems.SupportsRAT(name);if(!RATAvailable){RATDeployed=false;RATPosition=0;}}
 public void ToggleRAT(){if(!RATAvailable)return;if(!RATDeployed){RATDeployed=true;Mission?.Notify("RAM AIR TURBINE · Extending into the airflow for emergency power.");}else if(Grounded)RATDeployed=false;else Mission?.Notify("The ram-air turbine stays extended until landing.");}
 public void StopForEvacuation(){Speed=Throttle=VerticalSpeed=FlightPathAngle=PitchRate=RollRate=0;Engines=false;EnginePower=LeftEnginePower=RightEnginePower=0;BrakeHeld=AutoBrake=false;Grounded=true;Active=false;}
 public bool TryRestartEngines(){if(!CanRestartEngines)return false;if(Mission.Mode==FlightMode.FreeFlight)FuelRemaining=Mathf.Max(FuelRemaining,.1f);Engines=LeftEngine=RightEngine=true;Mission.Notify("Engines restarting. Add thrust and allow power to spool up.");return true;}
 public void SettleOnGround(){
  // A runway bounce must clear airborne momentum before the next taxi/rotation step.
  Grounded=true;Stalled=false;VerticalSpeed=FlightPathAngle=PitchRate=RollRate=Roll=0;Pitch=Mathf.Clamp(Pitch,-2,12);
  UpdateRotation();var position=transform.position;position.y=(World?World.HeightAt(position):0)+GroundClearance;transform.position=position;
  RenderPosition=previousPosition=position;RenderRotation=previousRotation=transform.rotation;
 }
 void Update(){if(!Active||Time.timeScale==0)return;if(FlightInput.Down(KeyCode.K))ToggleMcas();if(FlightInput.Down(KeyCode.G)&&!GearJammedUp&&!GearJammedDown)Gear=!Gear;if(FlightInput.Down(KeyCode.T))ToggleRAT();if(FlightInput.Down(KeyCode.F)&&!FlapsJammed)Flaps=(Flaps+1)%3;if(FlightInput.Down(KeyCode.H)){if(CatalogAllowsAssist)Assist=!Assist;else{Assist=false;Mission?.Notify("This recovery exercise uses manual flight controls.");}}if(FlightInput.Down(KeyCode.E)){Engines=false;Mission?.Notify("Both engines shut down. Pitch for a steady glide.");}if(FlightInput.Down(KeyCode.R))TryRestartEngines();}
 void FixedUpdate(){if(!Active)return;Step(Time.fixedDeltaTime,ReadPitch(),ReadRoll());}
 float ReadPitch(){float key=(FlightInput.Hold(KeyCode.W)||FlightInput.Hold(KeyCode.DownArrow)?1:0)-(FlightInput.Hold(KeyCode.S)||FlightInput.Hold(KeyCode.UpArrow)?1:0);return key!=0?key:Mathf.Clamp(TouchPitch-FlightInput.FlightStick.y,-1,1);}
 float ReadRoll(){float key=(FlightInput.Hold(KeyCode.D)||FlightInput.Hold(KeyCode.RightArrow)?1:0)-(FlightInput.Hold(KeyCode.A)||FlightInput.Hold(KeyCode.LeftArrow)?1:0);return key!=0?key:Mathf.Clamp(TouchRoll+FlightInput.FlightStick.x,-1,1);}
 public void ResetFlight(float alt,float speed,float heading,bool active){Mcas.Reset(Mcas.Installed);transform.position=new Vector3(0,alt,0);Speed=speed;Heading=TargetHeading=heading;Pitch=Roll=VerticalSpeed=Elapsed=Wind=GustStrength=0;Throttle=.65f;Engines=LeftEngine=RightEngine=true;FuelRemaining=1;Gear=GearJammedUp=GearJammedDown=FlapsJammed=ThrottleJammed=BrakeHeld=AutoBrake=flapJamCaptured=RATDeployed=false;JammedThrottle=.3f;jammedFlapPosition=0;RATPosition=0;Flaps=0;Stalled=Grounded=false;Active=active;EnginePower=LeftEnginePower=RightEnginePower=Throttle;FlapPosition=FlightPathAngle=PitchRate=RollRate=LiftAcceleration=DragAcceleration=0;UpdateRotation();RenderPosition=previousPosition=transform.position;RenderRotation=previousRotation=transform.rotation;TouchPitch=TouchRoll=0;}
 public void Step(float dt,float pitchInput,float rollInput){previousPosition=transform.position;previousRotation=transform.rotation;dt=Mathf.Clamp(dt,0,.05f);Elapsed+=dt;
  if(FlightInput.Hold(KeyCode.LeftShift)||FlightInput.Hold(KeyCode.RightShift))Throttle=Mathf.Min(1,Throttle+dt*.25f);
  if(FlightInput.Hold(KeyCode.LeftControl)||FlightInput.Hold(KeyCode.RightControl))Throttle=Mathf.Max(0,Throttle-dt*.25f);
  if(!CatalogAllowsAssist)Assist=false;
  Throttle=Mathf.Clamp01(ThrottleJammed?JammedThrottle:Throttle);Flaps=Mathf.Clamp(Flaps,0,2);
  FuelRemaining=Mathf.Clamp01(FuelRemaining-(Engines&&(LeftEngine||RightEngine)?dt*.0005f:0));
  if(FuelRemaining<=0)Engines=false;
  if(GearJammedUp)Gear=false;
  if(GearJammedDown)Gear=true;
  // The lever commands the engines; actual power and high-lift surfaces take time to respond.
  bool leftRunning=Engines&&LeftEngine,rightRunning=Engines&&RightEngine;
  LeftEnginePower=Mathf.MoveTowards(LeftEnginePower,leftRunning?Throttle:0,dt*(leftRunning?.3f:.7f));
  RightEnginePower=Mathf.MoveTowards(RightEnginePower,rightRunning?Throttle:0,dt*(rightRunning?.3f:.7f));
  EnginePower=(LeftEnginePower+RightEnginePower)*.5f;
  if(RATAvailable&&!Grounded&&Speed>25&&(!Engines||(!LeftEngine&&!RightEngine))&&EnginePower<.08f&&!RATDeployed){RATDeployed=true;Mission?.Notify("RAM AIR TURBINE · Automatic emergency-power deployment.");}
  RATPosition=Mathf.MoveTowards(RATPosition,RATAvailable&&RATDeployed?1:0,dt*.65f);
  if(FlapsJammed){if(!flapJamCaptured){jammedFlapPosition=FlapPosition;flapJamCaptured=true;}FlapPosition=jammedFlapPosition;}else{flapJamCaptured=false;FlapPosition=Mathf.MoveTowards(FlapPosition,Flaps,dt*.35f);}
  float pressure=Mathf.Max(.05f,Density*Speed*Speed/(85*85));
  float authority=Mathf.Clamp(Speed/75,.25f,1.25f);
  float desiredPitchRate=Mathf.Clamp(pitchInput,-1,1)*10*authority*ControlSensitivity;
  float desiredRollRate=Mathf.Clamp(rollInput,-1,1)*30*authority*ControlSensitivity;
  if(Assist&&Mathf.Abs(rollInput)<.01f){if(Mission)TargetHeading=Mission.AssistedHeading();float bank=Mathf.Clamp(Mathf.DeltaAngle(Heading,TargetHeading)*1.6f,-28,28);desiredRollRate=Mathf.Clamp((bank-Roll)*2,-30,30);}
  if(Assist&&Mathf.Abs(pitchInput)<.01f){
   // Assist controls the flight path by trimming angle of attack; it never redirects velocity directly.
   float path=Mission?Mission.AssistedPitch():Engines?0:-4;
   if(Grounded)desiredPitchRate=Mathf.Clamp((path-Pitch)*2,-10,10);
   else{if(Speed<StallSpeed+10)path=Mathf.Min(path,-6);
    float lift=9.81f*Mathf.Cos(FlightPathAngle*Mathf.Deg2Rad)/Mathf.Max(.4f,Mathf.Cos(Roll*Mathf.Deg2Rad))+Speed*(path-FlightPathAngle)*Mathf.Deg2Rad/2.5f;
    float alpha=Mathf.Clamp((lift*.63f/(9.81f*pressure)-.63f-FlapPosition*.13f)/.055f,-8,12);
    desiredPitchRate=Mathf.Clamp((FlightPathAngle+alpha-Pitch)*2,-10,10);}
  }
  Mcas.Step(dt,!Grounded,!Assist,Flaps==0&&FlapPosition<.02f,AngleOfAttack,ElectricalPower>.5f,pitchInput);desiredPitchRate-=Mcas.NoseDownRate;
  PitchRate=Mathf.Lerp(PitchRate,desiredPitchRate,1-Mathf.Exp(-dt*2.8f));
  RollRate=Mathf.Lerp(RollRate,desiredRollRate,1-Mathf.Exp(-dt*3.2f));
  if(Stalled&&!Assist)PitchRate-=Mathf.Max(0,AngleOfAttack-12)*dt*.5f;
  Pitch=Mathf.Clamp(Pitch+PitchRate*dt,-35,30);Roll=Mathf.Clamp(Roll+RollRate*dt,-70,70);
  float rudder=(FlightInput.Hold(KeyCode.Q)?-1:0); // E is intentionally reserved for engine failure.
  if(FlightInput.Hold(KeyCode.C))rudder=1;
  // Unequal thrust requires rudder; flight assist supplies that compensation when the pilot is not using rudder.
  float asymmetricYaw=(LeftEnginePower-RightEnginePower)*1.6f*ThrustMultiplier;
  if(Assist&&rudder==0)asymmetricYaw=0;
  Heading=Mathf.Repeat(Heading+Mathf.Tan(Roll*Mathf.Deg2Rad)*9.81f/Mathf.Max(Speed,30)*Mathf.Rad2Deg*dt+(rudder*2*ControlSensitivity+asymmetricYaw)*dt,360);
  if(Wind!=0||GustStrength!=0)RollRate+=(Mathf.Sin(Elapsed*2.4f)*Wind*.025f+Mathf.Sin(Elapsed*1.23f)*GustStrength*.09f)*dt;
  // Point-mass aerodynamics: lift bends the flight path; thrust, drag and gravity change energy.
  float maxLift=1.35f+FlapPosition*.5f,coefficient=.63f+FlapPosition*.13f+AngleOfAttack*.055f;
  if(AngleOfAttack>14)coefficient=Mathf.Max(.25f,maxLift-(AngleOfAttack-14)*.075f);
  coefficient=Mathf.Clamp(coefficient,-.8f,maxLift);
  LiftAcceleration=9.81f*pressure*coefficient/.63f;
  float load=LiftAcceleration/9.81f;
  DragAcceleration=.00006f*Density*Speed*Speed+.18f*load*load/pressure+FlapPosition*.15f+FlapPosition*FlapPosition*.04f+(Gear?.22f*pressure:0)+RATPosition*.025f*pressure;
  if(AngleOfAttack>14)DragAcceleration+=(AngleOfAttack-14)*.08f;
  float gamma=FlightPathAngle*Mathf.Deg2Rad;
  Speed=Mathf.Clamp(Speed+(EnginePower*2.7f*ThrustMultiplier-DragAcceleration-9.81f*Mathf.Sin(gamma))*dt,Grounded?0:5,240);
  if(!Grounded){float pathRate=(LiftAcceleration*Mathf.Cos(Roll*Mathf.Deg2Rad)-9.81f*Mathf.Cos(gamma))/Mathf.Max(Speed,20);FlightPathAngle=Mathf.Clamp(FlightPathAngle+pathRate*Mathf.Rad2Deg*dt,-80,60);}
  Stalled=!Grounded&&(Speed<StallSpeed||AngleOfAttack>14);
  VerticalSpeed=Mathf.Sin(FlightPathAngle*Mathf.Deg2Rad)*Speed;
  Vector3 pos=transform.position;float ground=World?World.HeightAt(pos):0;
  if(Grounded){bool braking=FlightInput.Hold(KeyCode.Space)||BrakeHeld||AutoBrake;VerticalSpeed=FlightPathAngle=Roll=RollRate=0;Pitch=Mathf.Clamp(Pitch,-2,12);pos.y=ground+GroundClearance;Speed=Mathf.Max(0,Speed-(braking?12:.15f)*dt);if(!braking&&Engines&&Speed>StallSpeed*1.12f&&Pitch>3&&LiftAcceleration>9.81f){Grounded=false;FlightPathAngle=2;VerticalSpeed=Mathf.Sin(2*Mathf.Deg2Rad)*Speed;pos.y+=.2f;}}
  float horizontalSpeed=Speed*Mathf.Cos(FlightPathAngle*Mathf.Deg2Rad);
  pos+=new Vector3(Mathf.Sin(Heading*Mathf.Deg2Rad)*horizontalSpeed+GustWind,Grounded?0:VerticalSpeed,Mathf.Cos(Heading*Mathf.Deg2Rad)*horizontalSpeed)*dt;
  float floor=(World?World.HeightAt(pos):0)+GroundClearance;
  bool contact=pos.y<=floor;
  // Resolve the surface every step, including taxi and the first seconds after a reset.
  // Landing assessment sees the pre-impact vertical speed, while the visible model stays above ground.
  if(contact||Grounded)pos.y=floor;
  transform.position=pos;UpdateRotation();
  if(!Grounded&&contact&&Elapsed>2)Mission?.Touchdown();
 }
 void UpdateRotation(){transform.rotation=Quaternion.Euler(0,Heading,0)*Quaternion.Euler(-Pitch,0,-Roll);}
}
}
