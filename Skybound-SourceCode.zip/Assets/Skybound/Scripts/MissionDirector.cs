using UnityEngine;
namespace Skybound {
public enum FlightMode {FreeFlight,Hudson,Glide,Crosswind,SingleEngine,FuelEmergency,GearFailure,SevereWeather,RightEngine,FlapFailure,GearDownLock,ThrottleFailure,GoAround,TouchAndGo,RejectedTakeoff,StallRecovery,EngineRelight,PrecisionLanding,FullStop,EmergencyPower,Evacuation}
public class MissionDirector:MonoBehaviour {
 public FlightController Aircraft;public SatelliteWorld World;public FlightCamera CameraRig;
 public FlightMode Mode; public string Place="New York",Message="",Result="";public bool Finished,Success;
 public float NoticeUntil,LandingSink,LandingSpeed,LandingBank;public Transform LandingMarker;
 public Vector3 RunwayStart,RunwayEnd; public float RunwayWidth=70,RunwayAltitude=24;
 public ChallengeDefinition CurrentChallenge {get;private set;}
 public float FailureDelay=>CurrentChallenge!=null?CurrentChallenge.FailureDelay:Mode==FlightMode.GearFailure?6:8;
 public bool RunwayStartMode {get;private set;} public bool WaitingForTakeoff {get;private set;} public bool PreparingChallenge {get;private set;}
 public bool GroundStartReady=>RunwayStartMode&&!runwaySceneryPending;
 public float EmergencyElapsed=>RunwayStartMode?WaitingForTakeoff||PreparingChallenge?0:Mathf.Max(0,Aircraft.Elapsed-emergencyStartedAt):Aircraft.Elapsed;
 public Vector3 ChallengeEntry {get;private set;} public float EntryHeading {get;private set;}
 public string DepartureRunway {get;private set;}="";
 ChallengeDefinition pendingChallenge;Transform entryMarker;Vector3 preparationWaypoint;float departureHeading,emergencyStartedAt;bool runwaySceneryPending,inboundToEntry;
 bool emergencyTriggered,fuelNoticeSent,fogBaselineSet;float clearFogStart,clearFogEnd;
 bool landingRecorded,stallObserved,goAroundClimbed;int goAroundStage;float goalHold,lastGoalElapsed;string goalProgress="";
 public bool FaultTriggered=>emergencyTriggered;
 public bool LandingRecorded=>landingRecorded;
 public string GoalProgress=>goalProgress;
 public string GoalDescription=>ChallengeCatalog.ProcedureFor(Mode);
 public string ResultDetails=>Mode==FlightMode.StallRecovery||Mode==FlightMode.EngineRelight?Success?"Recovered flight held for 5 seconds.":"Recovery objective was not completed.":Mode==FlightMode.RejectedTakeoff?"Runway stop: "+Aircraft.Speed.ToString("F1")+" m/s · "+Mathf.Max(0,RunwayLength-RunwayProgress).ToString("F0")+" m remaining":Mode==FlightMode.TouchAndGo&&Success?"Safe runway contact and powered climb completed.":"Touchdown: "+LandingSpeed.ToString("F0")+" kt · "+LandingSink.ToString("F1")+" m/s descent · "+LandingBank.ToString("F0")+"° bank";
 public float RunwayLength=>new Vector2(RunwayEnd.x-RunwayStart.x,RunwayEnd.z-RunwayStart.z).magnitude;
 public float RunwayProgress=>Vector3.Dot(Aircraft.transform.position-RunwayStart,RunwayForward);
 public float RunwayCrossTrack=>Mathf.Abs(Vector3.Dot(Aircraft.transform.position-RunwayStart,new Vector3(RunwayForward.z,0,-RunwayForward.x)));
 Vector3 RunwayForward {get{var axis=RunwayEnd-RunwayStart;axis.y=0;return axis.sqrMagnitude>1?axis.normalized:EntryForward();}}
 bool InsideRunway=>RunwayProgress>=0&&RunwayProgress<=RunwayLength&&RunwayCrossTrack<RunwayWidth*.5f;
 public static string NewNameFor(FlightMode mode){switch(mode){case FlightMode.RightEngine:return "One engine over Sydney";case FlightMode.FlapFailure:return "Amsterdam clean-wing landing";case FlightMode.GearDownLock:return "Vancouver gear stuck down";case FlightMode.ThrottleFailure:return "Dubai stuck thrust lever";case FlightMode.GoAround:return "Frankfurt go-around";case FlightMode.TouchAndGo:return "Montreal touch-and-go";case FlightMode.RejectedTakeoff:return "Dallas rejected takeoff";case FlightMode.StallRecovery:return "Auckland stall recovery";case FlightMode.EngineRelight:return "Haneda engine relight";case FlightMode.PrecisionLanding:return "Lisbon touchdown box";case FlightMode.FullStop:return "Boston full-stop landing";case FlightMode.EmergencyPower:return "Haneda emergency power";case FlightMode.Evacuation:return "Rome landing and evacuation";default:return "Free flight";}}
 public static string NameFor(FlightMode mode){switch(mode){case FlightMode.Hudson:return "Miracle on the Hudson";case FlightMode.Glide:return "The silent approach";case FlightMode.Crosswind:return "Into the crosswind";case FlightMode.SingleEngine:return "One engine home";case FlightMode.FuelEmergency:return "Running low on fuel";case FlightMode.GearFailure:return "Landing gear jammed";case FlightMode.SevereWeather:return "Through the storm";default:return NewNameFor(mode);}}
 public string MissionName=>CurrentChallenge!=null?CurrentChallenge.Name:NameFor(Mode);
 public string Coaching {
 get{if(Finished)return Result;
 if(runwaySceneryPending)return "Loading runway imagery and terrain. Your aircraft will remain stopped until the surface is ready.";
 if(WaitingForTakeoff)return "Ready on "+DepartureRunway+". Add thrust, stay on the centreline and rotate near "+(Aircraft.StallSpeed*1.15f*1.94384f).ToString("F0")+" kt. H toggles takeoff assist.";
 if(PreparingChallenge)return "Fly to the amber approach-entry beacon: "+ChallengeEntry.y.ToString("F0")+" m MSL, "+(pendingChallenge.StartSpeed*1.94384f).ToString("F0")+" kt. Engines and fuel remain available until the entry is reached.";
 if(Mode>=FlightMode.RightEngine)return NewCoaching();
 if(Mode==FlightMode.FreeFlight)return "Explore anywhere. M opens the world map.";
 if(!World.SurfaceLoaded(Aircraft.transform.position))return "Loading real world scenery. The challenge starts when the ground is ready.";
 if(Mode==FlightMode.Hudson){if(Aircraft.Engines)return "Bird strike in "+Mathf.CeilToInt(Mathf.Max(0,FailureDelay-EmergencyElapsed))+" seconds. Get ready to glide.";if(Aircraft.HeightAboveGround<35)return "Flare gently. Keep wings level and gear UP. Aim for a descent under 6 m/s.";return "Both engines lost. Flaps 1, stay over the river and preserve airspeed. Auto RAT supplies emergency power when fitted.";}
 if(Mode==FlightMode.SingleEngine){if(!emergencyTriggered)return "Left engine failure in "+Mathf.CeilToInt(Mathf.Max(0,FailureDelay-EmergencyElapsed))+" seconds. Prepare to balance the thrust.";return Aircraft.HeightAboveGround<35?"Flare gently: gear DOWN, wings level, descent under 4.5 m/s.":"Left engine failed. Use rudder to balance thrust; keep airspeed and follow the runway marker.";}
 if(Mode==FlightMode.FuelEmergency){if(!Aircraft.Engines)return "Engines stopped. Auto RAT supplies emergency power when fitted; glide to the runway, gear DOWN for touchdown.";return "Fuel reserve "+(Aircraft.FuelRemaining*100).ToString("F1")+"%. Avoid unnecessary thrust; keep this approach stable.";}
 if(Mode==FlightMode.GearFailure){if(!emergencyTriggered)return "Gear fault in "+Mathf.CeilToInt(Mathf.Max(0,FailureDelay-EmergencyElapsed))+" seconds. Prepare for a controlled belly landing.";return Aircraft.HeightAboveGround<35?"Keep wings level: gear UP, full flaps, descent under 3 m/s. Ease onto the runway.":"Gear is jammed UP. Full flaps, steady approach, under 175 kt at contact. Aim along the runway centre.";}
 if(Mode==FlightMode.SevereWeather)return Aircraft.HeightAboveGround<35?"Touch down aligned with the runway: gear DOWN, bank under 12°, descent under 4.5 m/s.":"Strong gusts and reduced visibility. Follow the runway marker; crab into the wind and make small corrections.";
 return Aircraft.HeightAboveGround<40?"Flare now. Gear DOWN, wings level. Touch down inside the marked runway.":"Follow the green runway marker. Gear DOWN. Set flaps 1 and control your descent.";}
 }
 public void StartFlight(FlightMode mode,double lat=40.773,double lon=-73.998,string place="New York",bool assist=false,bool startOnRunway=false){StartFlightCore(mode,lat,lon,place,assist,null,startOnRunway);}
 public void StartChallenge(ChallengeDefinition definition,bool assist,bool startOnRunway=false){var d=ChallengeCatalog.Normalize(definition);StartFlightCore(d.Mode,40.773,-73.998,"New York",assist,d,startOnRunway);}
 public void RetryChallenge(bool assist){bool runway=RunwayStartMode;if(CurrentChallenge!=null)StartChallenge(CurrentChallenge,assist,runway);else StartFlight(Mode,World.Latitude,World.Longitude,Place,assist,runway);}
 void StartFlightCore(FlightMode mode,double lat,double lon,string place,bool assist,ChallengeDefinition challenge,bool startOnRunway){StopAllCoroutines();if(Aircraft.Visual){var slides=Aircraft.Visual.GetComponent<EmergencySlides>();if(slides)slides.ResetSlides();}if(entryMarker)Destroy(entryMarker.gameObject);entryMarker=null;RunwayStartMode=WaitingForTakeoff=PreparingChallenge=runwaySceneryPending=inboundToEntry=false;ChallengeEntry=preparationWaypoint=Vector3.zero;EntryHeading=departureHeading=0;pendingChallenge=null;emergencyStartedAt=0;DepartureRunway="";CurrentChallenge=challenge;Mode=mode;Finished=Success=false;emergencyTriggered=fuelNoticeSent=false;Result="";Message="";NoticeUntil=LandingSink=LandingSpeed=LandingBank=0;Place=place;Time.timeScale=1;
  landingRecorded=stallObserved=goAroundClimbed=false;goAroundStage=0;goalHold=lastGoalElapsed=0;goalProgress="";
  if(mode==FlightMode.RejectedTakeoff)startOnRunway=true;
  if(mode>=FlightMode.RightEngine&&challenge==null){challenge=ChallengeCatalog.CreateDefault(mode);CurrentChallenge=challenge;}
  float alt=850,speed=85,heading=208;
  if(mode==FlightMode.Hudson){lat=40.800;lon=-73.991;alt=480;heading=209;Place="Hudson River, New York";}
  if(mode==FlightMode.Glide){lat=51.4647;lon=-.4085;alt=270;heading=270;Place="London Heathrow";}
  if(mode==FlightMode.Crosswind){lat=37.5946;lon=-122.33;alt=270;heading=298;Place="San Francisco";}
  bool heathrowEmergency=mode==FlightMode.SingleEngine||mode==FlightMode.FuelEmergency||mode==FlightMode.GearFailure;
  if(heathrowEmergency){lat=51.4647;lon=-.4085;alt=270;heading=270;Place="London Heathrow";}
  if(mode==FlightMode.SingleEngine)alt=240;
  if(mode==FlightMode.FuelEmergency)alt=220;
  if(mode==FlightMode.GearFailure)alt=200;
  if(mode==FlightMode.SevereWeather){lat=37.5946;lon=-122.33;alt=270;heading=298;Place="San Francisco";}
  if(mode==FlightMode.FreeFlight&&place=="Swiss Alps")alt=5500;
  if(mode==FlightMode.FreeFlight&&place=="Custom location")alt=6000;
  RunwayDefinition namedRunway=null;
  if(challenge!=null&&!string.IsNullOrEmpty(challenge.RunwayId)){
   namedRunway=RunwayCatalog.FindByIdent(challenge.RunwayId);
   if(namedRunway==null)throw new System.ArgumentException("Missing challenge runway: "+challenge.RunwayId);
   heading=namedRunway.Heading;Place=namedRunway.Name+" / "+namedRunway.Ident;
   var threshold=GeoMath.Project(namedRunway.Latitude,namedRunway.Longitude);double airportScale=System.Math.Cos(namedRunway.Latitude*System.Math.PI/180),distance=5000;
   var entry=GeoMath.Unproject(threshold.x-Mathf.Sin(heading*Mathf.Deg2Rad)*distance/airportScale,threshold.y-Mathf.Cos(heading*Mathf.Deg2Rad)*distance/airportScale);lat=entry.x;lon=entry.y;
  }
  if(challenge!=null){alt=challenge.StartAltitude;speed=challenge.StartSpeed;
   if(challenge.ApproachOffset!=0||challenge.LateralOffset!=0){float radians=heading*Mathf.Deg2Rad;double east=-Mathf.Sin(radians)*challenge.ApproachOffset+Mathf.Cos(radians)*challenge.LateralOffset,north=-Mathf.Cos(radians)*challenge.ApproachOffset-Mathf.Sin(radians)*challenge.LateralOffset;var origin=GeoMath.Project(lat,lon);double scale=System.Math.Cos(lat*System.Math.PI/180);var coordinates=GeoMath.Unproject(origin.x+east/scale,origin.y+north/scale);lat=coordinates.x;lon=coordinates.y;}
   heading=Mathf.Repeat(heading+challenge.HeadingOffset,360);
  }
  Aircraft.transform.position=Vector3.zero;World.SetLocation(lat,lon);Aircraft.ResetFlight(alt,speed,heading,true);Aircraft.Assist=assist&&(ChallengeCatalog.AllowsAssist(mode)||startOnRunway);Aircraft.Flaps=mode==FlightMode.Hudson?0:mode==FlightMode.FreeFlight?0:1;
  Aircraft.Gear=mode==FlightMode.Glide||mode==FlightMode.Crosswind||mode==FlightMode.SingleEngine||mode==FlightMode.FuelEmergency||mode==FlightMode.SevereWeather;Aircraft.Wind=mode==FlightMode.Crosswind?7:mode==FlightMode.SevereWeather?12:0;
  // ResetFlight owns all aircraft failure states. Scenario and visibility state
  // also reset here, so retries and a later free flight cannot inherit a fault.
  RunwayStart=RunwayEnd=Vector3.zero;RunwayWidth=70;RunwayAltitude=24;
  if(!fogBaselineSet){clearFogStart=RenderSettings.fogStartDistance;clearFogEnd=RenderSettings.fogEndDistance;fogBaselineSet=true;}
  RenderSettings.fogStartDistance=mode==FlightMode.SevereWeather?900:clearFogStart;RenderSettings.fogEndDistance=mode==FlightMode.SevereWeather?6500:clearFogEnd;
  if(heathrowEmergency){RunwayStart=World.Local(51.4647,-.4340,24);RunwayEnd=World.Local(51.4647,-.4848,24);Aircraft.Pitch=-3;Aircraft.Throttle=mode==FlightMode.SingleEngine?.55f:mode==FlightMode.GearFailure?.25f:.3f;}
  if(mode==FlightMode.FuelEmergency)Aircraft.FuelRemaining=.02f;
  if(mode==FlightMode.Glide){RunwayStart=World.Local(51.4647,-.4340,24);RunwayEnd=World.Local(51.4647,-.4848,24);RunwayAltitude=24;Aircraft.Engines=false;Aircraft.Pitch=-3;}
  if(mode==FlightMode.Crosswind){RunwayStart=World.Local(37.6063,-122.3570,4);RunwayEnd=World.Local(37.6233,-122.3930,4);RunwayAltitude=4;Aircraft.Pitch=-3;Aircraft.Throttle=.25f;}
  if(mode==FlightMode.SevereWeather){RunwayStart=World.Local(37.6063,-122.3570,4);RunwayEnd=World.Local(37.6233,-122.3930,4);RunwayAltitude=4;Aircraft.Pitch=-3;Aircraft.Throttle=.25f;Aircraft.GustStrength=10;}
  if(challenge!=null){Aircraft.Throttle=challenge.Throttle;Aircraft.FuelRemaining=challenge.Fuel;Aircraft.Wind=challenge.Wind;Aircraft.GustStrength=challenge.GustStrength;Aircraft.Pitch=challenge.StartPitch;Aircraft.Flaps=challenge.InitialFlaps;Aircraft.Gear=challenge.InitialGear;}
  if(namedRunway!=null){RunwayStart=World.Local(namedRunway.Latitude,namedRunway.Longitude,namedRunway.Elevation);RunwayEnd=World.Local(namedRunway.EndLatitude,namedRunway.EndLongitude,namedRunway.Elevation);RunwayWidth=namedRunway.Width;RunwayAltitude=namedRunway.Elevation;}
  ConfigureMarker();CameraRig.Discover=false;CameraRig.Cockpit=CameraRig.Cabin=false;
  if(startOnRunway){BeginRunwayStart();return;}
  Notify(mode==FlightMode.FreeFlight?"Your aircraft is ready. W/S pitch · A/D bank · Shift/Ctrl throttle":mode==FlightMode.FuelEmergency?"LOW FUEL · A limited reserve remains. Fly a stable approach; prepare to glide if it runs out.":mode==FlightMode.SevereWeather?"WEATHER ALERT · Strong gusts and reduced visibility. Make small corrections; H toggles assist.":"Challenge started. H toggles landing assist.");
 }
 void BeginRunwayStart(){
  var runway=CurrentChallenge!=null&&!string.IsNullOrEmpty(CurrentChallenge.RunwayId)?RunwayCatalog.FindByIdent(CurrentChallenge.RunwayId):RunwayCatalog.Nearest(World.Latitude,World.Longitude);
  if(runway==null){Notify("No runway data is available for this location.");return;}
  double entryLat=World.Latitude,entryLon=World.Longitude;float entryAltitude=Aircraft.Altitude;EntryHeading=Aircraft.Heading;
  var landingStart=World.Coordinates(RunwayStart);var landingEnd=World.Coordinates(RunwayEnd);
  pendingChallenge=Mode==FlightMode.FreeFlight?null:CurrentChallenge!=null?CurrentChallenge.Copy():ChallengeCatalog.CreateDefault(Mode);
  RunwayStartMode=WaitingForTakeoff=runwaySceneryPending=true;PreparingChallenge=pendingChallenge!=null&&Mode!=FlightMode.RejectedTakeoff;inboundToEntry=false;departureHeading=runway.Heading;DepartureRunway=runway.Name+" / "+runway.Ident;
  float radians=runway.Heading*Mathf.Deg2Rad;var projected=GeoMath.Project(runway.Latitude,runway.Longitude);double scale=System.Math.Cos(runway.Latitude*System.Math.PI/180);var padded=GeoMath.Unproject(projected.x+Mathf.Sin(radians)*80/scale,projected.y+Mathf.Cos(radians)*80/scale);
  Aircraft.transform.position=Vector3.zero;World.SetLocation(padded.x,padded.y);
  if(Mode==FlightMode.FreeFlight||Mode==FlightMode.RejectedTakeoff){RunwayStart=World.Local(runway.Latitude,runway.Longitude,runway.Elevation);RunwayEnd=World.Local(runway.EndLatitude,runway.EndLongitude,runway.Elevation);RunwayWidth=runway.Width;RunwayAltitude=runway.Elevation;}
  else{RunwayStart=World.Local(landingStart.x,landingStart.y,RunwayAltitude);RunwayEnd=World.Local(landingEnd.x,landingEnd.y,RunwayAltitude);}
  ChallengeEntry=World.Local(entryLat,entryLon,entryAltitude);Vector3 entryForward=EntryForward();float preparationSpeed=pendingChallenge!=null?pendingChallenge.StartSpeed:85,turnRadius=preparationSpeed*preparationSpeed/(9.81f*Mathf.Tan(28*Mathf.Deg2Rad));preparationWaypoint=ChallengeEntry-entryForward*Mathf.Clamp(turnRadius*2.8f,3200,9000);
  Aircraft.ResetFlight(runway.Elevation+Aircraft.GroundClearance,0,departureHeading,false);Aircraft.StopForEvacuation();Aircraft.Engines=Aircraft.LeftEngine=Aircraft.RightEngine=true;Aircraft.FuelRemaining=1;Aircraft.Gear=true;Aircraft.Grounded=true;Aircraft.Flaps=1;Aircraft.Pitch=Aircraft.Roll=0;
  Aircraft.transform.position=new Vector3(0,runway.Elevation+Aircraft.GroundClearance,0);Aircraft.SendMessage("LateUpdate");
  // Clear the emergency weather while the pilot departs and reaches the approach entry.
  Aircraft.Wind=Aircraft.GustStrength=0;RenderSettings.fogStartDistance=clearFogStart;RenderSettings.fogEndDistance=clearFogEnd;
  ConfigureMarker();if(PreparingChallenge)ConfigureEntryMarker();Notify("RUNWAY START · "+DepartureRunway+". Loading the real surface before you take control.");StartCoroutine(WaitForRunway());
 }
 System.Collections.IEnumerator WaitForRunway(){
  float deadline=Time.unscaledTime+35;
  while((!World.SurfaceLoaded(Vector3.zero)||(World.ElevationEnabled&&!World.ElevationLoadedAt(Vector3.zero)))&&Time.unscaledTime<deadline)yield return null;
  // The visible terrain is the contact reference, including the flat fallback when elevation is unavailable.
  Aircraft.transform.position=new Vector3(0,World.HeightAt(Vector3.zero)+Aircraft.GroundClearance,0);Aircraft.SendMessage("LateUpdate");runwaySceneryPending=false;Aircraft.Active=true;
  Notify(World.SurfaceLoaded(Vector3.zero)?"Ready on "+DepartureRunway+". Add thrust and rotate near "+(Aircraft.StallSpeed*1.15f*1.94384f).ToString("F0")+" kt.":"Runway start ready. Imagery is unavailable; check your internet connection.");
 }
 void ArmChallenge(){
  PreparingChallenge=false;emergencyStartedAt=Aircraft.Elapsed;var d=pendingChallenge;
  lastGoalElapsed=Aircraft.Elapsed;if(Mode==FlightMode.StallRecovery)Aircraft.Assist=false;
  Aircraft.Throttle=d.Throttle;Aircraft.FuelRemaining=d.Fuel;Aircraft.Wind=d.Wind;Aircraft.GustStrength=d.GustStrength;Aircraft.Flaps=d.InitialFlaps;Aircraft.Gear=d.InitialGear;
  if(Mode==FlightMode.Glide){Aircraft.Engines=false;Notify("APPROACH ENTRY · Engines stopped. The glide challenge has begun.");}
  else Notify("APPROACH ENTRY · "+MissionName+" has begun. Emergency timing starts now.");
  RenderSettings.fogStartDistance=Mode==FlightMode.SevereWeather?900:clearFogStart;RenderSettings.fogEndDistance=Mode==FlightMode.SevereWeather?6500:clearFogEnd;if(entryMarker)Destroy(entryMarker.gameObject);entryMarker=null;
 }
 void ConfigureEntryMarker(){
  if(entryMarker)Destroy(entryMarker.gameObject);var go=new GameObject("Approach entry beacon");entryMarker=go.transform;entryMarker.position=ChallengeEntry;entryMarker.rotation=Quaternion.Euler(0,EntryHeading,0);
  var ring=go.AddComponent<LineRenderer>();ring.useWorldSpace=false;ring.loop=true;ring.positionCount=48;ring.startWidth=ring.endWidth=4;ring.material=SkyboundBootstrap.MakeMaterial(new Color(1,.65f,.22f),true);
  for(int i=0;i<48;i++){float angle=i*Mathf.PI*2/48;ring.SetPosition(i,new Vector3(Mathf.Sin(angle)*110,Mathf.Cos(angle)*60,0));}
 }
 void Update(){if(Finished)return;
  if(Mode==FlightMode.Evacuation&&landingRecorded){var slides=EmergencySlides.For(Aircraft.Visual.GetComponent<AircraftVisual>());if(slides.Deployed&&slides.Inflation>=.98f&&!Aircraft.Engines&&Aircraft.Speed<1){FinishChallenge(true,"Landing complete. Engines stopped and exit slides fully inflated.");return;}}
  if(!Aircraft.Active)return;
  if(Mode==FlightMode.RejectedTakeoff&&RunwayStartMode){UpdateRejectedTakeoff();return;}
  if(RunwayStartMode){
   if(WaitingForTakeoff||PreparingChallenge){Aircraft.Engines=Aircraft.LeftEngine=Aircraft.RightEngine=true;Aircraft.FuelRemaining=1;}
   if(WaitingForTakeoff){if(Aircraft.Assist){Aircraft.Throttle=1;Aircraft.Gear=true;Aircraft.Flaps=1;}if(!Aircraft.Grounded&&Aircraft.HeightAboveGround>Aircraft.GroundClearance+15){WaitingForTakeoff=false;emergencyStartedAt=Aircraft.Elapsed;if(Mode==FlightMode.FreeFlight)Notify("Airborne. Explore anywhere; M opens the world map.");else Notify("Airborne. Fly to the amber entry beacon before the emergency exercise begins.");}}
   if(PreparingChallenge&&!WaitingForTakeoff){Vector3 toWaypoint=preparationWaypoint-Aircraft.transform.position;toWaypoint.y=0;if(!inboundToEntry&&toWaypoint.magnitude<450&&Mathf.Abs(Aircraft.Altitude-ChallengeEntry.y)<90)inboundToEntry=true;
    Vector3 toEntry=ChallengeEntry-Aircraft.transform.position;toEntry.y=0;if(toEntry.magnitude<300&&Mathf.Abs(Aircraft.Altitude-ChallengeEntry.y)<75&&Mathf.Abs(Mathf.DeltaAngle(Aircraft.Heading,EntryHeading))<35)ArmChallenge();
    else{if(inboundToEntry&&Vector3.Dot(Aircraft.transform.position-ChallengeEntry,EntryForward())>600)inboundToEntry=false;
     if(Aircraft.Assist){float targetSpeed=Mathf.Max(pendingChallenge.StartSpeed,Aircraft.StallSpeed+16),path=AssistedPitch()*Mathf.Deg2Rad;float steadyThrottle=(Aircraft.DragAcceleration+9.81f*Mathf.Sin(path))/(2.7f*Aircraft.ThrustMultiplier);Aircraft.Throttle=Mathf.Clamp01(steadyThrottle+(targetSpeed-Aircraft.Speed)*.08f);Aircraft.Gear=false;Aircraft.Flaps=pendingChallenge.StartSpeed<80?1:0;}
    }
   }
  }
  // Freeze the scenario timer until imagery and terrain beneath the start are ready.
  if(!World.SurfaceLoaded(Aircraft.transform.position)&&Aircraft.Elapsed<.1f){Aircraft.Active=false;StartCoroutine(WaitForScenery());return;}
  bool emergencyReady=!RunwayStartMode||!WaitingForTakeoff&&!PreparingChallenge;
  if(Mode>=FlightMode.RightEngine){if(emergencyReady)UpdateNewObjectives();else lastGoalElapsed=Aircraft.Elapsed;if(Finished)return;}
  if(emergencyReady&&Mode==FlightMode.Hudson&&EmergencyElapsed>=FailureDelay&&Aircraft.Engines){Aircraft.Engines=false;Aircraft.Flaps=1;Aircraft.Throttle=0;Notify("BIRD STRIKE · Both engines lost. You have control.");}
  if(emergencyReady&&Mode==FlightMode.SingleEngine&&!emergencyTriggered&&EmergencyElapsed>=FailureDelay){emergencyTriggered=true;Aircraft.LeftEngine=false;Notify("LEFT ENGINE FAILURE · One engine remains. Balance the thrust with rudder and keep a steady approach.");}
  if(emergencyReady&&Mode==FlightMode.GearFailure&&!emergencyTriggered&&EmergencyElapsed>=FailureDelay){emergencyTriggered=true;Aircraft.GearJammedUp=true;Aircraft.Gear=false;Aircraft.Flaps=2;Notify("GEAR JAMMED UP · Full flaps selected. Prepare for a gentle, wings-level belly landing on the runway.");}
  if(Mode==FlightMode.FuelEmergency&&!fuelNoticeSent&&Aircraft.FuelRemaining<=.0001f){fuelNoticeSent=true;Notify("FUEL EXHAUSTED · Both engines are stopping. Glide to the runway and preserve airspeed.");}
  if(!RunwayStartMode&&Mode==FlightMode.FreeFlight&&Aircraft.Elapsed<5){float ground=World.HeightAt(Aircraft.transform.position);if(ground+700>Aircraft.Altitude)Aircraft.transform.position=new Vector3(Aircraft.transform.position.x,ground+700,Aircraft.transform.position.z);}
  if(Aircraft.transform.position.x*Aircraft.transform.position.x+Aircraft.transform.position.z*Aircraft.transform.position.z>400000000){Vector3 shift=Aircraft.transform.position;shift.y=0;World.Rebase(shift);Aircraft.Rebase(shift);CameraRig.transform.position-=shift;RunwayStart-=shift;RunwayEnd-=shift;ChallengeEntry-=shift;preparationWaypoint-=shift;if(LandingMarker)LandingMarker.position-=shift;if(entryMarker)entryMarker.position-=shift;}
 }
 System.Collections.IEnumerator WaitForScenery(){float deadline=Time.unscaledTime+25;while(!World.SurfaceLoaded(Aircraft.transform.position)&&Time.unscaledTime<deadline)yield return null;Aircraft.Active=true;if(!World.SurfaceLoaded(Aircraft.transform.position))Notify("Imagery is unavailable. You can still fly; check your internet connection.");}
 string NewCoaching(){
  if(landingRecorded){if(Mode==FlightMode.TouchAndGo)return "Runway contact complete. Add thrust, rotate gently and climb 80 m above the contact plane for 3 seconds.";if(Mode==FlightMode.Evacuation)return Aircraft.Speed>=1?"Brake to a full stop with Space or the brake button, then deploy the exit slides with X.":"Stop the engines and deploy the exit slides with X. Wait for inflation to finish.";return "Runway contact complete. Idle thrust and brake to a full stop inside the runway.";}
  switch(Mode){
   case FlightMode.RightEngine:return emergencyTriggered?"RIGHT ENGINE FAILED · Balance the opposite yaw with rudder. Land gear down with descent below 4.5 m/s.":"Right engine failure in "+Mathf.CeilToInt(Mathf.Max(0,FailureDelay-EmergencyElapsed))+" seconds. Prepare for asymmetric thrust.";
   case FlightMode.FlapFailure:return emergencyTriggered?"FLAPS JAMMED · High-lift surfaces are frozen. Preserve clean-wing speed and land gear down.":"Flap actuator failure is approaching. Keep enough speed for a clean-wing landing.";
   case FlightMode.GearDownLock:return emergencyTriggered?"GEAR LOCKED DOWN · Retraction is unavailable. Account for the drag and land on the marked runway.":"The landing gear will lock down. Plan the approach with extra drag.";
   case FlightMode.ThrottleFailure:return emergencyTriggered?"THRUST LEVER JAMMED · Power is locked at 30%. Manage pitch and configuration; E cuts both engines if needed.":"The thrust lever will jam at reduced power. Prepare to manage your energy.";
   case FlightMode.GoAround:return goAroundClimbed?"Go-around climb complete. Follow the entry beacon for a second approach, then land.":goAroundStage==1?"GO AROUND · Add power and climb above 350 m AGL with speed above stall +10 m/s and bank below 15° for 3 seconds.":"First approach: expect a go-around instruction below 180 m AGL within 1.8 km of the runway. Do not touch down yet.";
   case FlightMode.TouchAndGo:return "Make a gentle gear-down runway contact, then add power and climb away. The first touchdown is not the finish.";
   case FlightMode.RejectedTakeoff:return emergencyTriggered?"REJECT TAKEOFF · Thrust lost. Stay on the runway and hold Space or the brake button until stopped.":"Accelerate straight ahead. Reject the takeoff when the alert appears at 68 kt; remain on the ground.";
   case FlightMode.StallRecovery:return stallObserved?"STALL OBSERVED · Lower the nose and add thrust. Hold speed above 1.2× stall, angle of attack below 8°, bank below 10°, and height above 150 m for 5 seconds.":"Manual training: idle thrust and gently raise the nose until the stall warning appears. Begin recovery above 150 m AGL.";
   case FlightMode.EngineRelight:return emergencyTriggered?"ENGINE RELIGHT · Press R or Restart engines, add thrust and hold a powered climb above 120 m AGL for 5 seconds.":"Both engines will stop. Be ready to use R to relight, add thrust and recover a climb.";
   case FlightMode.PrecisionLanding:return "Touch down 180–900 m beyond the threshold, within 12 m of centreline. Descent ≤3 m/s, bank ≤8°, heading error ≤10°.";
   case FlightMode.FullStop:return "Make a gentle runway landing, then brake to a full stop before leaving the paved runway.";
   case FlightMode.EmergencyPower:return emergencyTriggered?"MAIN THRUST LOST · Check the fitted RAT, then land with emergency power above 55%. T deploys it if needed.":"Both engines will stop. This landing also requires a fitted, extended ram-air turbine providing emergency power.";
   case FlightMode.Evacuation:return emergencyTriggered?"GEAR JAMMED UP · Full flaps. Belly-land gently, brake to a stop, then deploy exit slides with X.":"Prepare for gear failure, a controlled belly landing, a full stop and slide deployment.";
   default:return GoalDescription;
  }
 }
 void FinishChallenge(bool success,string text){Success=success;Result=text;Finished=true;WaitingForTakeoff=PreparingChallenge=false;Aircraft.Active=false;Aircraft.AutoBrake=false;Time.timeScale=0;if(success&&CurrentChallenge!=null)ChallengeStore.MarkCompleted(CurrentChallenge.Id);}
 void UpdateRejectedTakeoff(){
  if(runwaySceneryPending)return;
  if(!emergencyTriggered){Aircraft.Engines=Aircraft.LeftEngine=Aircraft.RightEngine=true;Aircraft.FuelRemaining=1;if(Aircraft.Assist)Aircraft.Throttle=1;if(Aircraft.Speed>=35){emergencyTriggered=true;WaitingForTakeoff=false;emergencyStartedAt=Aircraft.Elapsed;Aircraft.Engines=false;Aircraft.Throttle=0;Notify("REJECT TAKEOFF · Thrust lost at 68 kt. Brake now; keep the aircraft on the runway.");}}
  if(!emergencyTriggered)return;Aircraft.Throttle=0;Aircraft.AutoBrake=Aircraft.Assist;goalProgress="Stop on runway · "+Aircraft.Speed.ToString("F1")+" m/s · "+Mathf.Max(0,RunwayLength-RunwayProgress).ToString("F0")+" m remaining";
  if(!Aircraft.Grounded){FinishChallenge(false,"The rejected takeoff must stay on the ground. Brake as soon as the alert appears.");return;}
  if(!InsideRunway){FinishChallenge(false,"The aircraft left the runway during the rejected takeoff.");return;}
  if(Aircraft.Speed<1)FinishChallenge(true,"Takeoff rejected safely. The aircraft stopped inside the runway.");
 }
 void UpdateNewObjectives(){
  float dt=Mathf.Clamp(Aircraft.Elapsed-lastGoalElapsed,0,.1f);lastGoalElapsed=Aircraft.Elapsed;
  if(!emergencyTriggered&&ChallengeCatalog.HasTimedFailure(Mode)&&EmergencyElapsed>=FailureDelay){
   emergencyTriggered=true;
   switch(Mode){case FlightMode.RightEngine:Aircraft.RightEngine=false;break;case FlightMode.FlapFailure:Aircraft.FlapsJammed=true;break;case FlightMode.GearDownLock:Aircraft.GearJammedDown=true;Aircraft.Gear=true;break;case FlightMode.ThrottleFailure:Aircraft.ThrottleJammed=true;Aircraft.JammedThrottle=Aircraft.Throttle=.3f;break;case FlightMode.EngineRelight:case FlightMode.EmergencyPower:Aircraft.Engines=false;Aircraft.Throttle=0;break;case FlightMode.Evacuation:Aircraft.GearJammedUp=true;Aircraft.Gear=false;Aircraft.Flaps=2;break;}
   Notify(NewCoaching());
  }
  if(Mode==FlightMode.StallRecovery){
   Aircraft.Assist=false;if(Aircraft.Stalled&&!Aircraft.Grounded){stallObserved=emergencyTriggered=true;}
   bool stable=stallObserved&&!Aircraft.Stalled&&!Aircraft.Grounded&&Aircraft.Speed>=Aircraft.StallSpeed*1.2f&&Aircraft.AngleOfAttack<=8&&Mathf.Abs(Aircraft.Roll)<=10&&Aircraft.HeightAboveGround>150;
   goalHold=stable?goalHold+dt:0;goalProgress=(stallObserved?"Stable recovery ":"Induce a controlled stall ")+goalHold.ToString("F1")+" / 5 s";
   if(goalHold>=5)FinishChallenge(true,"Stall recovered. Safe airspeed and controlled flight held for five seconds.");return;
  }
  if(Mode==FlightMode.EngineRelight){
   if(Aircraft.Assist&&emergencyTriggered&&Aircraft.Engines)Aircraft.Throttle=.85f;
   bool stable=emergencyTriggered&&Aircraft.Engines&&Aircraft.LeftEngine&&Aircraft.RightEngine&&Aircraft.EnginePower>=.55f&&Aircraft.Speed>Aircraft.StallSpeed+10&&Aircraft.VerticalSpeed>0&&!Aircraft.Grounded&&Aircraft.HeightAboveGround>120;
   goalHold=stable?goalHold+dt:0;goalProgress="Powered climb "+goalHold.ToString("F1")+" / 5 s";if(goalHold>=5)FinishChallenge(true,"Engines relit. A stable powered climb was maintained for five seconds.");return;
  }
  if(Mode==FlightMode.GoAround&&!goAroundClimbed){
   if(goAroundStage==0&&RunwayProgress>=-1800&&RunwayProgress<900&&Aircraft.HeightAboveGround<180){goAroundStage=1;Notify("GO AROUND · Add power and climb. The runway landing is not yet cleared.");}
   if(goAroundStage==1){if(Aircraft.Assist){Aircraft.Throttle=1;Aircraft.Gear=false;Aircraft.Flaps=1;}bool stable=!Aircraft.Grounded&&Aircraft.HeightAboveGround>350&&Aircraft.Speed>Aircraft.StallSpeed+10&&Mathf.Abs(Aircraft.Roll)<15;goalHold=stable?goalHold+dt:0;goalProgress="Go-around climb "+goalHold.ToString("F1")+" / 3 s";
    if(goalHold>=3){goAroundClimbed=true;goAroundStage=2;PreparingChallenge=true;inboundToEntry=false;pendingChallenge=CurrentChallenge?.Copy()??ChallengeCatalog.CreateDefault(Mode);ConfigureEntryMarker();Notify("Go-around complete. Fly the circuit to the entry beacon for a second approach.");}
   }return;
  }
  if(landingRecorded){
   if(Mode==FlightMode.TouchAndGo){if(Aircraft.Assist){Aircraft.Throttle=1;Aircraft.Gear=true;Aircraft.Flaps=1;}bool climbed=!Aircraft.Grounded&&Aircraft.HeightAboveGround>Aircraft.GroundClearance+80&&Aircraft.Speed>Aircraft.StallSpeed+10&&Aircraft.VerticalSpeed>0;goalHold=climbed?goalHold+dt:0;goalProgress="Climb after contact "+goalHold.ToString("F1")+" / 3 s";if(goalHold>=3)FinishChallenge(true,"Touch-and-go complete. A gentle runway contact was followed by a stable climb.");}
   else if(Mode==FlightMode.FullStop||Mode==FlightMode.Evacuation){Aircraft.Throttle=0;Aircraft.AutoBrake=Aircraft.Assist;goalProgress=Aircraft.Speed<1?Mode==FlightMode.Evacuation?"Stopped · deploy exit slides with X":"Stopped inside runway":"Brake to stop · "+Aircraft.Speed.ToString("F1")+" m/s";if(!InsideRunway){FinishChallenge(false,"The landing roll left the runway before the objective was complete.");return;}if(Mode==FlightMode.FullStop&&Aircraft.Grounded&&Aircraft.Speed<1)FinishChallenge(true,"A gentle landing and a full stop inside the runway.");}
   return;
  }
  // New normal runway approaches trim power for their entry speed. Locked thrust stays a pilot problem.
  if(Aircraft.Assist&&Aircraft.Engines&&!Aircraft.ThrottleJammed&&Mode!=FlightMode.RejectedTakeoff){float target=CurrentChallenge!=null?CurrentChallenge.StartSpeed:85;float path=AssistedPitch()*Mathf.Deg2Rad,runningFraction=((Aircraft.LeftEngine?1:0)+(Aircraft.RightEngine?1:0))*.5f;Aircraft.Throttle=Mathf.Clamp01((Aircraft.DragAcceleration+9.81f*Mathf.Sin(path))/(2.7f*Aircraft.ThrustMultiplier*Mathf.Max(.5f,runningFraction))+(target-Aircraft.Speed)*.08f);}
 }
 public float AssistedHeading(){
  if(WaitingForTakeoff)return departureHeading;
  if(PreparingChallenge){Vector3 entryDelta=PreparationTarget()-Aircraft.transform.position;return Mathf.Atan2(entryDelta.x,entryDelta.z)*Mathf.Rad2Deg;}
  if(Mode==FlightMode.FreeFlight)return Aircraft.TargetHeading;
  if(Mode==FlightMode.StallRecovery||Mode==FlightMode.EngineRelight)return EntryHeading!=0?EntryHeading:Aircraft.TargetHeading;
  Vector3 target;
  if(Mode==FlightMode.Hudson){double lat=Aircraft.Coordinates.x-.006,lon;
   if(lat>40.791)lon=-73.999+(lat-40.791)/(40.836-40.791)*(.046);
   else if(lat>40.745)lon=-74.021+(lat-40.745)/(40.791-40.745)*(.022);
   else lon=-74.031+(lat-40.704)/(40.745-40.704)*(.010);
   target=World.Local(lat,lon);
  }else{
   Vector3 axis=RunwayEnd-RunwayStart;axis.y=0;float length=axis.magnitude;axis/=length;
   float progress=Vector3.Dot(Aircraft.transform.position-RunwayStart,axis);
   target=RunwayStart+axis*Mathf.Clamp(progress+900,0,length);
  }
  Vector3 delta=target-Aircraft.transform.position;
  float heading=Mathf.Atan2(delta.x,delta.z)*Mathf.Rad2Deg;
  if(Mode==FlightMode.Crosswind||Mode==FlightMode.SevereWeather||Mode>=FlightMode.RightEngine){delta.y=0;Vector3 direction=delta.normalized;float speed=Mathf.Max(30,Aircraft.Speed),wind=Aircraft.GustWind;
   float groundSpeed=wind*direction.x+Mathf.Sqrt(Mathf.Max(1,speed*speed-wind*wind*(1-direction.x*direction.x)));
   heading=Mathf.Atan2(direction.x*groundSpeed-wind,direction.z*groundSpeed)*Mathf.Rad2Deg;
  }
  return heading;
 }
 // Desired flight-path angle; the aerodynamic controller supplies the necessary pitch/angle of attack.
 public float AssistedPitch(){
  if(Mode==FlightMode.RejectedTakeoff)return 0;
  if(WaitingForTakeoff)return Aircraft.Speed>Aircraft.StallSpeed*1.15f?8:0;
  if(PreparingChallenge){Vector3 delta=PreparationTarget()-Aircraft.transform.position;delta.y=0;return Mathf.Clamp(Mathf.Atan2(ChallengeEntry.y-Aircraft.Altitude,Mathf.Max(600,delta.magnitude))*Mathf.Rad2Deg,-4,8);}
  if(Mode==FlightMode.TouchAndGo&&landingRecorded)return Aircraft.Grounded?Aircraft.Speed>Aircraft.StallSpeed*1.15f?8:0:6;
  if((Mode==FlightMode.FullStop||Mode==FlightMode.Evacuation)&&landingRecorded)return 0;
  if(Mode==FlightMode.GoAround&&goAroundStage==1)return 8;
  if(Mode==FlightMode.EngineRelight)return Aircraft.Engines?5:-3.2f;
  if(Mode==FlightMode.Evacuation)return Aircraft.HeightAboveGround<40?-.9f:-2.5f;
  if(Mode==FlightMode.PrecisionLanding){if(Aircraft.HeightAboveGround<25)return -1.8f;Vector3 target=RunwayStart+RunwayForward*500;float targetHeight=World.HeightAt(target)+Aircraft.GroundClearance;return Mathf.Clamp(Mathf.Atan2(targetHeight-Aircraft.Altitude,Mathf.Max(250,500-RunwayProgress))*Mathf.Rad2Deg,-4,-1.8f);}
  if(Mode==FlightMode.FreeFlight)return Aircraft.Engines?0:Aircraft.HeightAboveGround<25?1.2f:-3.2f;
  if(Mode==FlightMode.Hudson)return Aircraft.Engines?0:Aircraft.HeightAboveGround<35?1.2f:-3.2f;
  // Start the belly-landing flare earlier and keep a small descent so the
  // exercise reaches the surface gently instead of levelling above it.
  if(Mode==FlightMode.GearFailure)return Aircraft.HeightAboveGround<40?-.9f:-2.5f;
  // The low-fuel approach reaches the flare with more energy than an engine-out start.
  // Keep a shallow descent instead of commanding a climb that floats beyond the runway.
  if(Mode==FlightMode.FuelEmergency&&Aircraft.HeightAboveGround<25)return -1.4f;
  if(Aircraft.HeightAboveGround<25)return Aircraft.Engines?-1.4f:1.2f;
  return Aircraft.Engines?-2.5f:-3.2f;
 }
 Vector3 EntryForward()=>new Vector3(Mathf.Sin(EntryHeading*Mathf.Deg2Rad),0,Mathf.Cos(EntryHeading*Mathf.Deg2Rad));
 Vector3 PreparationTarget(){if(!inboundToEntry)return preparationWaypoint;Vector3 forward=EntryForward();float progress=Vector3.Dot(Aircraft.transform.position-ChallengeEntry,forward),lookAhead=Mathf.Clamp(Aircraft.Speed*12,800,1600);return ChallengeEntry+forward*(progress+lookAhead);}
 public bool OverHudson(){Vector2 p=new Vector2(Aircraft.transform.position.x,Aircraft.transform.position.z);Vector3 a=World.Local(40.836,-73.953),b=World.Local(40.791,-73.999),c=World.Local(40.745,-74.021),d=World.Local(40.704,-74.031);return Mathf.Min(GeoMath.DistanceToSegment(p,new Vector2(a.x,a.z),new Vector2(b.x,b.z)),Mathf.Min(GeoMath.DistanceToSegment(p,new Vector2(b.x,b.z),new Vector2(c.x,c.z)),GeoMath.DistanceToSegment(p,new Vector2(c.x,c.z),new Vector2(d.x,d.z))))<480;}
 public bool OnRunway(){Vector2 p=new Vector2(Aircraft.transform.position.x,Aircraft.transform.position.z),a=new Vector2(RunwayStart.x,RunwayStart.z),b=new Vector2(RunwayEnd.x,RunwayEnd.z);return GeoMath.DistanceToSegment(p,a,b)<RunwayWidth/2;}
 public void Touchdown(){if(Finished)return;LandingSink=Mathf.Abs(Aircraft.VerticalSpeed);LandingSpeed=Aircraft.Speed*1.94384f;LandingBank=Mathf.Abs(Aircraft.Roll);
  // The normalized models have different wheel/body heights; seat every landing at its actual contact plane.
  Vector3 contactPosition=Aircraft.transform.position;contactPosition.y=World.HeightAt(contactPosition)+Aircraft.GroundClearance;Aircraft.transform.position=contactPosition;
  // Departure contact precedes the exercise. Rotating model bounds or a bounce
  // must not score a Hudson ditching while the healthy aircraft is taking off.
  if(RunwayStartMode&&(WaitingForTakeoff||PreparingChallenge)){
   bool safeDepartureContact=Aircraft.Gear&&LandingSink<=6&&LandingBank<=15&&Aircraft.Pitch>=-7&&Aircraft.Pitch<=15&&Aircraft.Speed<105;
   if(safeDepartureContact){
    Aircraft.SettleOnGround();WaitingForTakeoff=true;Aircraft.Engines=Aircraft.LeftEngine=Aircraft.RightEngine=true;Aircraft.FuelRemaining=1;
    Aircraft.Active=true;Success=false;Result="";Time.timeScale=1;
    Notify("Runway contact. Continue takeoff with a gentle rotation, or reduce thrust and brake with Space.");return;
   }
   Success=false;Result="Hard contact during departure. Retry with the gear down and a gentler rotation.";
   WaitingForTakeoff=PreparingChallenge=false;Finished=true;Aircraft.Active=false;Time.timeScale=0;return;
  }
  float sinkLimit=Mode==FlightMode.GearFailure?3:Mode==FlightMode.SingleEngine||Mode==FlightMode.SevereWeather?4.5f:6;
  float bankLimit=Mode==FlightMode.GearFailure?7:Mode==FlightMode.SingleEngine||Mode==FlightMode.SevereWeather?12:15;
  float speedLimit=Mode==FlightMode.GearFailure?90:Mode==FlightMode.SingleEngine||Mode==FlightMode.SevereWeather?100:105;
  bool gentle=LandingSink<=sinkLimit&&LandingBank<=bankLimit&&Aircraft.Pitch>=-7&&Aircraft.Pitch<=15&&Aircraft.Speed<speedLimit&&!Aircraft.Stalled;
  bool water=Mode==FlightMode.Hudson?OverHudson():World.LooksLikeWater(Aircraft.transform.position);
  // These marked airport runways are known land. Blue-tinted asphalt and shadows in
  // aerial imagery must not turn an otherwise safe runway touchdown into a water landing.
  if(Mode!=FlightMode.Hudson&&Mode!=FlightMode.FreeFlight&&OnRunway())water=false;
  if(Mode>=FlightMode.RightEngine){NewTouchdown(water);return;}
  if(Mode==FlightMode.Hudson){Success=water&&!Aircraft.Gear&&gentle;Result=!water?"You missed the Hudson. Keep your flight path over the river.":Aircraft.Gear?"Retract the landing gear before ditching.":!gentle?"The impact was too hard. Level the wings and gently flare below 100 feet.":"You brought the aircraft down safely on the Hudson.";}
  else if(Mode==FlightMode.FreeFlight){Success=!water&&Aircraft.Gear&&gentle;Result=Success?"Smooth touchdown. Brake with Space, or add power to take off again.":water?"Water landing: try the Hudson mission for a ditching challenge.":!Aircraft.Gear?"Gear-up landing. Lower the gear with G before touchdown.":"Hard landing. Try a slower descent with level wings.";if(Success){Aircraft.Grounded=true;Notify(Result);return;}}
  else if(Mode==FlightMode.GearFailure){bool deployed=Aircraft.FlapPosition>=1.8f;Success=!water&&OnRunway()&&!Aircraft.Gear&&gentle&&deployed;Result=water||!OnRunway()?"Keep the belly landing inside the marked runway.":Aircraft.Gear?"This gear-failure exercise requires the jammed gear to remain up.":!deployed?"Use fully deployed flaps before the belly landing.":!gentle?"Ease onto the runway: descent under 3 m/s, bank under 7°, speed under 175 kt.":"A controlled belly landing. The emergency exercise is complete.";}
  else if(Mode==FlightMode.SevereWeather){Vector3 axis=RunwayEnd-RunwayStart;float runwayHeading=Mathf.Atan2(axis.x,axis.z)*Mathf.Rad2Deg;bool aligned=Mathf.Abs(Mathf.DeltaAngle(Aircraft.Heading,runwayHeading))<=20;Success=!water&&OnRunway()&&Aircraft.Gear&&gentle&&aligned;Result=water||!OnRunway()?"The approach missed the runway. Retry and follow the marker through the gusts.":!Aircraft.Gear?"Lower the landing gear before touchdown.":!aligned?"Align the aircraft with the runway before contact.":!gentle?"Make a gentler landing: descent under 4.5 m/s and bank under 12°.":"A stable runway landing through the gusts.";}
  else{Success=!water&&OnRunway()&&Aircraft.Gear&&gentle;Result=!OnRunway()?"You missed the marked runway. Follow the approach marker.":!Aircraft.Gear?"Lower the landing gear with G.":!gentle?"Hard touchdown. Reduce descent and keep the wings level.":"A safe runway landing. Nicely done.";}
  if(Success&&CurrentChallenge!=null)ChallengeStore.MarkCompleted(CurrentChallenge.Id);
  Finished=true;Aircraft.Active=false;Time.timeScale=0;
 }
 void NewTouchdown(bool water){
  if(Mode==FlightMode.StallRecovery||Mode==FlightMode.EngineRelight){FinishChallenge(false,"The airborne recovery objective was not completed before ground contact.");return;}
  if(Mode==FlightMode.RejectedTakeoff){FinishChallenge(false,"Reject the takeoff and stop on the runway without becoming airborne.");return;}
  if(Mode==FlightMode.GoAround&&!goAroundClimbed){FinishChallenge(false,"Complete the instructed go-around climb before returning to land.");return;}
  if(ChallengeCatalog.HasTimedFailure(Mode)&&!emergencyTriggered){FinishChallenge(false,"The emergency objective had not started before touchdown.");return;}
  bool belly=Mode==FlightMode.Evacuation;
  float sinkLimit=belly?3:Mode==FlightMode.PrecisionLanding?3:Mode==FlightMode.RightEngine?4.5f:6;
  float bankLimit=belly?7:Mode==FlightMode.PrecisionLanding?8:Mode==FlightMode.RightEngine?12:15;
  float speedLimit=belly?90:Mode==FlightMode.RightEngine?100:105;
  bool gentle=LandingSink<=sinkLimit&&LandingBank<=bankLimit&&Aircraft.Pitch>=-7&&Aircraft.Pitch<=15&&Aircraft.Speed<speedLimit&&!Aircraft.Stalled;
  bool correctGear=belly?!Aircraft.Gear&&Aircraft.GearJammedUp:Aircraft.Gear;
  if(water||!InsideRunway||!gentle||!correctGear||(belly&&Aircraft.FlapPosition<1.8f)){FinishChallenge(false,water||!InsideRunway?"Touch down inside the marked runway.":!correctGear?belly?"This evacuation exercise requires a controlled gear-up landing.":"Lower the landing gear before touchdown.":"Make a gentler landing with the required configuration and level wings.");return;}
  if(Mode==FlightMode.PrecisionLanding){float heading=Mathf.Atan2(RunwayForward.x,RunwayForward.z)*Mathf.Rad2Deg;if(RunwayProgress<180||RunwayProgress>900||RunwayCrossTrack>12||Mathf.Abs(Mathf.DeltaAngle(Aircraft.Heading,heading))>10){FinishChallenge(false,"The touchdown missed the precision box: 180–900 m beyond the threshold and within 12 m of centreline.");return;}}
  if(Mode==FlightMode.EmergencyPower&&(!Aircraft.RATAvailable||Aircraft.RATPosition<.95f||Aircraft.EmergencyPower<.55f)){FinishChallenge(false,"Land with the fitted RAT extended and emergency power above 55%.");return;}
  if(Mode==FlightMode.FullStop||Mode==FlightMode.TouchAndGo||Mode==FlightMode.Evacuation){landingRecorded=true;Aircraft.Pitch=0;Aircraft.SettleOnGround();Aircraft.Active=true;Aircraft.Throttle=Mode==FlightMode.TouchAndGo?Aircraft.Throttle:0;Aircraft.AutoBrake=Mode!=FlightMode.TouchAndGo&&Aircraft.Assist;goalHold=0;lastGoalElapsed=Aircraft.Elapsed;Notify(NewCoaching());return;}
  FinishChallenge(true,Mode==FlightMode.PrecisionLanding?"A controlled touchdown inside the precision box.":Mode==FlightMode.EmergencyPower?"Safe runway landing with ram-air turbine emergency power.":"A safe runway landing. The mission objective is complete.");
 }
 public void Notify(string text){Message=text;NoticeUntil=Time.unscaledTime+6;}
 void ConfigureMarker(){if(LandingMarker)Destroy(LandingMarker.gameObject);if(Mode==FlightMode.FreeFlight)return;
  var go=new GameObject("Landing target");LandingMarker=go.transform;
  if(Mode==FlightMode.Hudson){var p=World.Local(40.76,-74.014,5);go.transform.position=p;var ring=go.AddComponent<LineRenderer>();ring.useWorldSpace=false;ring.loop=true;ring.positionCount=64;ring.startWidth=ring.endWidth=5;ring.material=SkyboundBootstrap.MakeMaterial(new Color(.6f,1,.6f),true);for(int i=0;i<64;i++){float t=i*Mathf.PI*2/64;ring.SetPosition(i,new Vector3(Mathf.Sin(t)*170,0,Mathf.Cos(t)*600));}}
  else{go.transform.position=RunwayStart;go.transform.rotation=Quaternion.LookRotation(RunwayEnd-RunwayStart);float length=Vector3.Distance(RunwayStart,RunwayEnd),halfWidth=RunwayWidth*.5f;var outline=go.AddComponent<LineRenderer>();outline.useWorldSpace=false;outline.loop=true;outline.positionCount=4;outline.startWidth=outline.endWidth=3;outline.material=SkyboundBootstrap.MakeMaterial(new Color(.55f,1,.55f),true);outline.SetPositions(new[]{new Vector3(-halfWidth,2,0),new Vector3(halfWidth,2,0),new Vector3(halfWidth,2,length),new Vector3(-halfWidth,2,length)});
  if(Mode==FlightMode.PrecisionLanding){var box=new GameObject("Precision touchdown box");box.transform.SetParent(go.transform,false);var zone=box.AddComponent<LineRenderer>();zone.useWorldSpace=false;zone.loop=true;zone.positionCount=4;zone.startWidth=zone.endWidth=2;zone.material=SkyboundBootstrap.MakeMaterial(new Color(.7f,1,.3f),true);zone.SetPositions(new[]{new Vector3(-12,3,180),new Vector3(12,3,180),new Vector3(12,3,900),new Vector3(-12,3,900)});}
  for(int i=0;i<8;i++){var light=GameObject.CreatePrimitive(PrimitiveType.Sphere);light.name="Approach light";Destroy(light.GetComponent<Collider>());light.transform.SetParent(go.transform,false);light.transform.localPosition=new Vector3(0,8,-120-i*130);light.transform.localScale=Vector3.one*7;light.GetComponent<Renderer>().material=SkyboundBootstrap.MakeMaterial(new Color(.6f,1,.6f),true);}}
 }
}
}
