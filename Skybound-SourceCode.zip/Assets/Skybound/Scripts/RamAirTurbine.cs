using System.Collections.Generic;
using UnityEngine;

namespace Skybound {
public class RamAirTurbine:MonoBehaviour {
 FlightController aircraft;Transform arm,rotor;float angle;Renderer[] renderers;bool visible,exteriorVisible=true;
 readonly List<Mesh> meshes=new List<Mesh>();readonly List<Material> materials=new List<Material>();
 public float RotationAngle=>angle;
 public static RamAirTurbine Create(Transform parent,FlightController aircraft,float length,float bodyBottom){var go=new GameObject("Ram-air turbine");go.transform.SetParent(parent,false);go.transform.localPosition=new Vector3(-.42f,bodyBottom+.12f,-length*.12f);var rat=go.AddComponent<RamAirTurbine>();rat.aircraft=aircraft;rat.Build();go.SetActive(aircraft.RATAvailable);return rat;}
 void Build(){
  var metal=SkyboundBootstrap.MakeMaterial(new Color(.53f,.57f,.59f));if(metal.HasProperty("_Metallic"))metal.SetFloat("_Metallic",.65f);if(metal.HasProperty("_Cull"))metal.SetFloat("_Cull",0);materials.Add(metal);
  var dark=SkyboundBootstrap.MakeMaterial(new Color(.10f,.14f,.16f));if(dark.HasProperty("_Cull"))dark.SetFloat("_Cull",0);materials.Add(dark);
  arm=new GameObject("RAT deployment arm").transform;arm.SetParent(transform,false);
  var support=new AirlinerMeshBatch();support.Box(new Vector3(0,-.44f,0),new Vector3(.10f,.88f,.11f));support.Box(new Vector3(0,-.84f,.04f),new Vector3(.21f,.18f,.29f));meshes.Add(support.Create(arm,"RAT arm and generator",metal));
  rotor=new GameObject("Airflow-driven RAT propeller").transform;rotor.SetParent(arm,false);rotor.localPosition=new Vector3(0,-.89f,.22f);
  var prop=new AirlinerMeshBatch();for(int side=-1;side<=1;side+=2)prop.Quad(new Vector3(-.035f,side*.045f,0),new Vector3(.045f,side*.055f,0),new Vector3(.085f,side*.42f,.014f),new Vector3(-.035f,side*.43f,0));prop.Box(Vector3.zero,new Vector3(.10f,.10f,.09f));meshes.Add(prop.Create(rotor,"RAT propeller blades",dark));
  arm.localRotation=Quaternion.Euler(0,0,90);
  renderers=GetComponentsInChildren<Renderer>(true);foreach(var renderer in renderers)renderer.enabled=false;
 }
 public void SetExteriorVisible(bool value){exteriorVisible=value;}
 void LateUpdate(){if(!aircraft)return;float extension=aircraft.RATPosition;arm.localRotation=Quaternion.Euler(0,0,Mathf.Lerp(90,0,extension));bool nextVisible=exteriorVisible&&extension>.015f;if(nextVisible!=visible){visible=nextVisible;foreach(var renderer in renderers)renderer.enabled=visible;}
  if(Time.timeScale>0&&Time.deltaTime>0&&extension>.5f){angle=Mathf.Repeat(angle+Mathf.Min(24,Mathf.Min(620,aircraft.Speed*8)*Time.deltaTime),360);rotor.localRotation=Quaternion.AngleAxis(angle,Vector3.forward);}
 }
 void OnDestroy(){foreach(var mesh in meshes)if(mesh)Destroy(mesh);foreach(var material in materials)if(material)Destroy(material);}
}
}
