using System;
using UnityEngine;
namespace Skybound {
// Optional standalone benchmark: launch with --skybound-benchmark. Normal play does not collect samples.
public class FlightPerformance:MonoBehaviour {
 bool enabledProbe,started,reported;int count,phase;float warmupUntil;float[] samples=new float[600];SkyboundBootstrap bootstrap;
 void Start(){var args=Environment.GetCommandLineArgs();enabledProbe=Array.IndexOf(args,"--skybound-benchmark")>=0;bootstrap=GetComponent<SkyboundBootstrap>();
  if(enabledProbe)foreach(string arg in args){const string prefix="--skybound-benchmark-aircraft=";if(arg.StartsWith(prefix)&&int.TryParse(arg.Substring(prefix.Length),out int index)&&index>=0&&index<bootstrap.Catalog.Aircraft.Length)bootstrap.HUD.Visual.Select(index);}
 }
 void LateUpdate(){if(!enabledProbe||reported)return;
  if(!started){if(bootstrap.World.LoadedTiles<65||bootstrap.HUD.Visual.Loading)return;bootstrap.Aircraft.Active=true;bootstrap.Aircraft.Assist=true;bootstrap.CameraRig.Discover=false;bootstrap.CameraRig.Cockpit=bootstrap.CameraRig.Cabin=false;bootstrap.HUD.Menu=MenuPage.Flight;Time.timeScale=1;started=true;warmupUntil=Time.unscaledTime+2;Debug.Log("SKYBOUND_BENCHMARK_START aircraft="+bootstrap.HUD.Visual.AircraftName);return;}
  if(bootstrap.Mission.WaitingForTakeoff){warmupUntil=Time.unscaledTime+2;return;}
  if(Time.unscaledTime<warmupUntil)return;
  samples[count++]=Time.unscaledDeltaTime*1000;if(count<samples.Length)return;
  double total=0;foreach(float value in samples)total+=value;Array.Sort(samples);Debug.Log("SKYBOUND_FRAME_TIMING view="+bootstrap.CameraRig.ViewName+" frames="+count+" fps="+(1000/(total/count)).ToString("F1")+" medianMs="+samples[count/2].ToString("F2")+" p95Ms="+samples[(int)(count*.95f)].ToString("F2")+" maxMs="+samples[count-1].ToString("F2")+" tiles="+bootstrap.World.LoadedTiles);if(++phase>=3){reported=true;return;}count=0;bootstrap.CameraRig.ToggleView();warmupUntil=Time.unscaledTime+2;
 }
}
}
