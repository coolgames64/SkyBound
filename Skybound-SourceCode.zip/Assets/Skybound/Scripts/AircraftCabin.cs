using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace Skybound {
// Original generated passenger interior, combined by material and instantiated only when cabin view opens.
public class AircraftCabin:MonoBehaviour {
 public const int RendererBudget=8,TriangleBudget=320000;
 public float Width {get;private set;} public float Length {get;private set;}
 public int SeatCount {get;private set;} public Vector3 EyeOffset {get;private set;}
 public int WindowCount=>windowCenters.Count;
 public IReadOnlyList<Vector3> WindowCenters=>windowCenters;
 public int BinDoorCount {get;private set;}
 public int TriangleCount {get;private set;} public int VertexCount {get;private set;}
 public int BatchedRendererCount=>meshes.Count;
 public int OwnedTextureCount=>textures.Count;
 readonly List<Vector3> windowCenters=new List<Vector3>();
 readonly List<Mesh> meshes=new List<Mesh>();readonly List<Material> materials=new List<Material>();
 readonly List<Texture2D> textures=new List<Texture2D>();
 public static AircraftCabin Create(Transform parent,float aircraftLength,string aircraftName,float floorHeight){
  var go=new GameObject("Passenger cabin");go.transform.SetParent(parent,false);go.transform.localPosition=new Vector3(0,floorHeight,0);
  var cabin=go.AddComponent<AircraftCabin>();
  try{cabin.Build(aircraftLength,aircraftName);return cabin;}catch{Destroy(go);throw;}
 }
 public static float WidthFor(string name){string n=name.ToUpperInvariant();if(n.Contains("A380"))return 6.45f;if(n.Contains("777")||n.Contains("747"))return 5.9f;if(n.Contains("787")||n.Contains("A350"))return 5.65f;if(n.Contains("A300")||n.Contains("A310")||n.Contains("A330")||n.Contains("A340")||n.Contains("MD-11")||n.Contains("DC-10"))return 5.45f;if(n.Contains("ATR")||n.Contains("CONCORDE"))return 2.5f;if(n.Contains("190")||n.Contains("REGIONAL"))return 2.75f;if(n.Contains("A220")||n.Contains("CS300")||n.Contains("717"))return 3.15f;return 3.6f;}
 void Build(float aircraftLength,string aircraftName){
  Width=WidthFor(aircraftName);Length=Mathf.Clamp(aircraftLength*.69f,12,52);float half=Length*.5f,pitch=.9f;
  var shell=new CabinMeshBuilder();var trim=new CabinMeshBuilder();var seat=new CabinMeshBuilder();var cloth=new CabinMeshBuilder();
  var metal=new CabinMeshBuilder();var dark=new CabinMeshBuilder();var carpet=new CabinMeshBuilder();var lights=new CabinMeshBuilder();
  dark.Box(new Vector3(0,-.07f,0),new Vector3(Width,.14f,Length));carpet.Carpet(Width,Length);
  BuildShell(shell,trim,dark,half,pitch);
  BuildBins(shell,trim,metal,dark,lights,half,pitch);
  float[] columns=SeatColumns(Width);float seatWidth=Width<3?.405f:.445f;
  int rows=Mathf.Clamp(Mathf.FloorToInt((Length-3.6f)/pitch),8,54);float first=-half+1.6f;
  foreach(float x in columns){
   // Thin floor rails make the repeated seats feel attached to the airframe.
   metal.Box(new Vector3(x,.016f,first+(rows-1)*pitch*.5f),new Vector3(.046f,.014f,(rows-1)*pitch+.64f));
   for(int row=0;row<rows;row++)BuildSeat(seat,cloth,trim,metal,dark,x,first+row*pitch,seatWidth);
  }
  BuildBulkhead(shell,trim,metal,dark,lights,half,true);
  BuildBulkhead(shell,trim,metal,dark,lights,-half,false);
  BuildDoors(trim,metal,dark,half);
  // Light channels are emissive geometry: no added real-time lights, shadows or per-seat objects.
  foreach(float x in new[]{-Width*.19f,Width*.19f})lights.Box(new Vector3(x,2.405f,0),new Vector3(.045f,.018f,Length-1.8f));
  Texture2D weave=WeaveTexture("Cabin seat weave",false),floor=WeaveTexture("Cabin carpet weave",true),signs=LightingAtlas();
  Add(shell,"Curved cabin shell and bins",new Color(.80f,.79f,.75f),.28f,null,.065f);
  Add(trim,"Window reveals and cabin panels",new Color(.62f,.65f,.65f),.30f,null,.025f);
  Add(seat,"Contoured seat upholstery",new Color(.055f,.105f,.155f),.18f,weave,.015f);
  Add(cloth,"Headrests and seat pockets",new Color(.20f,.29f,.34f),.20f,weave,.025f);
  Add(metal,"Seat rails and galley fittings",new Color(.44f,.47f,.49f),.52f,null,.025f);
  Add(dark,"Armrests and cabin seams",new Color(.047f,.054f,.059f),.22f,null,.02f);
  Add(carpet,"Woven aisle carpet",new Color(.12f,.13f,.145f),.06f,floor,.035f);
  Add(lights,"Warm cabin light channels and EXIT signs",Color.white,.05f,signs,0,true);
  // The existing view position is preserved for every narrow-body and wide-body layout.
  float aisle=Width>4?Width>=6.1f?1.25f:Width>=5.8f?.97f:1.25f:0;
  EyeOffset=new Vector3(aisle,1.43f,-Length*.22f);
 }
 void BuildShell(CabinMeshBuilder shell,CabinMeshBuilder trim,CabinMeshBuilder dark,float half,float pitch){
  int windows=Mathf.FloorToInt((Length-4)/pitch);float span=windows*pitch,first=-span*.5f;
  const float windowY=1.09f,bandHeight=1.02f;
  for(int side=-1;side<=1;side+=2){
   float x=side*Width*.5f;
   // Lower sidewall rounds in towards the floor; the window band remains structural and opaque.
   Vector2[] lower={new Vector2(side*Width*.445f,0),new Vector2(side*Width*.482f,.30f),new Vector2(x,.58f)};
   for(int i=0;i<lower.Length-1;i++){
    var a=lower[i];var b=lower[i+1];
    Vector3 n=new Vector3(-side,.25f,0).normalized;
    shell.Surface(new Vector3(a.x,a.y,-half),new Vector3(b.x,b.y,-half),new Vector3(b.x,b.y,half),new Vector3(a.x,a.y,half),n);
   }
   trim.Box(new Vector3(side*Width*.45f,.075f,0),new Vector3(.028f,.09f,Length));
   for(int i=0;i<windows;i++){
    float z=first+(i+.5f)*pitch;
    shell.WindowWall(x,windowY,z,pitch,bandHeight,.237f,.355f,side);
    trim.WindowReveal(x,x-side*.060f,windowY,z,.237f,.355f,.214f,.331f);
    trim.OvalRing(x-side*.066f,windowY,z,.280f,.404f,.214f,.331f,side);
    dark.OvalRing(x-side*.069f,windowY,z,.284f,.408f,.278f,.400f,side);
    windowCenters.Add(new Vector3(x,windowY,z));
   }
   float gap=(Length-span)*.5f;
   shell.Box(new Vector3(x,windowY,-half+gap*.5f),new Vector3(.055f,bandHeight,gap));
   shell.Box(new Vector3(x,windowY,half-gap*.5f),new Vector3(.055f,bandHeight,gap));
  }
  // An elliptical crown joins the walls continuously; authored inward normals smooth the cross-section.
  const int segments=28;float crown=Width>4?.98f:.94f;
  for(int i=0;i<segments;i++){
   float t0=-Mathf.PI*.5f+i*Mathf.PI/segments,t1=-Mathf.PI*.5f+(i+1)*Mathf.PI/segments;
   Vector3 P(float t,float z)=>new Vector3(Mathf.Sin(t)*Width*.5f,1.60f+Mathf.Cos(t)*crown,z);
   Vector3 N(float t)=>new Vector3(-Mathf.Sin(t)/ (Width*.5f),-Mathf.Cos(t)/crown,0).normalized;
   shell.Quad(P(t0,-half),P(t1,-half),P(t1,half),P(t0,half),N(t0),N(t1),N(t1),N(t0),Vector2.zero,Vector2.zero,Vector2.zero,Vector2.zero);
  }
  // Panel joints break up the crown without introducing separate renderer objects.
  for(float z=-half+2;z<half-1;z+=3.6f){
   for(int i=7;i<21;i++){
    float a=-Mathf.PI*.5f+i*Mathf.PI/28,b=-Mathf.PI*.5f+(i+1)*Mathf.PI/28;
    Vector3 P(float t,float dz)=>new Vector3(Mathf.Sin(t)*Width*.5f*.998f,1.60f+Mathf.Cos(t)*(crown-.008f),z+dz);
    trim.Quad(P(a,-.006f),P(b,-.006f),P(b,.006f),P(a,.006f));
   }
  }
 }
 void BuildBins(CabinMeshBuilder shell,CabinMeshBuilder trim,CabinMeshBuilder metal,CabinMeshBuilder dark,CabinMeshBuilder lights,float half,float pitch){
  int modules=Mathf.FloorToInt((Length-3.5f)/pitch);float start=-modules*pitch*.5f;
  for(int side=-1;side<=1;side+=2){
   float inner=Width*.27f,outer=Width*.465f;
   float RoofAt(float x)=>1.60f+(Width>4?.98f:.94f)*Mathf.Sqrt(Mathf.Max(0,1-Mathf.Pow(x/(Width*.5f),2)))-.025f;
   Vector2[] section={new Vector2(side*inner,1.735f),new Vector2(side*(inner+.065f),1.79f),new Vector2(side*(inner+.18f),Mathf.Min(2.16f,RoofAt(inner+.18f))),new Vector2(side*(inner+.34f),Mathf.Min(2.245f,RoofAt(inner+.34f))),new Vector2(side*outer,Mathf.Min(2.055f,RoofAt(outer))),new Vector2(side*Width*.48f,1.765f)};
   dark.Box(new Vector3(side*(inner+.11f),1.982f,0),new Vector3(.055f,.46f,modules*pitch));
   for(int i=0;i<modules;i++){
    float z=start+(i+.5f)*pitch;
    shell.Section(section,z-pitch*.5f+.014f,z+pitch*.5f-.014f);BinDoorCount++;
    // Door latch, hinge seam and passenger-service unit below each bin module.
    metal.Panel(new Vector3(side*(inner+.021f),1.787f,z),new Vector3(.13f,.034f,.045f),Quaternion.Euler(0,90,0),.01f);
    trim.Box(new Vector3(side*(inner+.13f),1.69f,z),new Vector3(.32f,.025f,.38f));
    for(int vent=0;vent<3;vent++)dark.Box(new Vector3(side*(inner+.13f),1.673f,z-.09f+vent*.025f),new Vector3(.11f,.005f,.009f));
    lights.Box(new Vector3(side*(inner+.08f),1.672f,z+.11f),new Vector3(.065f,.006f,.068f));
    dark.Box(new Vector3(side*(inner+.19f),1.672f,z+.11f),new Vector3(.035f,.006f,.032f));
   }
   lights.Box(new Vector3(side*(inner+.24f),Mathf.Min(2.255f,RoofAt(inner+.24f)-.009f),0),new Vector3(.034f,.018f,modules*pitch));
  }
  if(Width>4){
   // Wide-body layouts also have storage above the centre seat block, between the two aisles.
   float w=Width>=5.8f?1.48f:1.86f;
   Vector2[] center={new Vector2(-w*.5f,2.025f),new Vector2(-w*.43f,1.88f),new Vector2(w*.43f,1.88f),new Vector2(w*.5f,2.025f),new Vector2(w*.42f,2.44f),new Vector2(-w*.42f,2.44f)};
   for(int i=0;i<modules;i++){
    float z=start+(i+.5f)*pitch;shell.Section(center,z-pitch*.5f+.014f,z+pitch*.5f-.014f);BinDoorCount+=2;
    foreach(int side in new[]{-1,1}){metal.Box(new Vector3(side*w*.485f,2.05f,z),new Vector3(.025f,.045f,.13f));lights.Box(new Vector3(side*(w*.5f+.03f),2.30f,z),new Vector3(.025f,.015f,pitch-.02f));}
   }
  }
 }
 void BuildSeat(CabinMeshBuilder seat,CabinMeshBuilder cloth,CabinMeshBuilder trim,CabinMeshBuilder metal,CabinMeshBuilder dark,float x,float z,float width){
  Quaternion recline=Quaternion.Euler(-8,0,0);
  seat.Cushion(new Vector3(x,.545f,z+.02f),new Vector3(width,.445f,.13f),Quaternion.Euler(90,0,0),.065f,.027f);
  seat.Cushion(new Vector3(x,.885f,z-.19f),new Vector3(width,.64f,.15f),recline,.065f,.027f);
  cloth.Cushion(new Vector3(x,1.235f,z-.14f),new Vector3(width*.83f,.235f,.17f),recline,.052f,.024f,1);
  foreach(int side in new[]{-1,1}){
   cloth.Box(new Vector3(x+side*width*.39f,1.225f,z-.072f),new Vector3(.055f,.17f,.10f),Quaternion.Euler(-8,-side*12,0));
   dark.Panel(new Vector3(x+side*width*.54f,.705f,z),new Vector3(.055f,.355f,.075f),Quaternion.Euler(90,0,0),.023f);
   metal.Box(new Vector3(x+side*width*.54f,.596f,z-.05f),new Vector3(.025f,.20f,.032f));
  }
  // Rear tray and elastic literature pocket face passengers looking forward along the aisle.
  trim.Panel(new Vector3(x,.905f,z-.296f),new Vector3(width*.78f,.235f,.032f),recline,.025f);
  dark.Box(new Vector3(x,.988f,z-.326f),new Vector3(.055f,.02f,.009f),recline);
  cloth.Box(new Vector3(x,.673f,z-.272f),new Vector3(width*.72f,.18f,.022f),recline);
  trim.Box(new Vector3(x,.765f,z-.286f),new Vector3(width*.74f,.012f,.009f),recline);
  metal.Box(new Vector3(x,.305f,z-.03f),new Vector3(.055f,.34f,.055f));
  metal.Box(new Vector3(x,.126f,z),new Vector3(width*.76f,.043f,.32f));
  // Seatbelt webbing and a small metal buckle sit on the cushion.
  dark.Box(new Vector3(x,.617f,z+.012f),new Vector3(width*.77f,.012f,.033f),Quaternion.Euler(0,-8,0));
  metal.Box(new Vector3(x+.028f,.626f,z+.012f),new Vector3(.055f,.012f,.045f));
  SeatCount++;
 }
 void BuildBulkhead(CabinMeshBuilder shell,CabinMeshBuilder trim,CabinMeshBuilder metal,CabinMeshBuilder dark,CabinMeshBuilder lights,float end,bool front){
  float inward=front?-1:1,z=end+inward*.12f,crown=Width>4?.98f:.94f;
  var contour=new List<Vector2>{new Vector2(-Width*.445f,0),new Vector2(-Width*.482f,.30f),new Vector2(-Width*.5f,.58f),new Vector2(-Width*.5f,1.60f)};
  for(int i=1;i<=28;i++){float t=-Mathf.PI*.5f+i*Mathf.PI/28;contour.Add(new Vector2(Mathf.Sin(t)*Width*.5f,1.60f+Mathf.Cos(t)*crown));}
  contour.Add(new Vector2(Width*.5f,.58f));contour.Add(new Vector2(Width*.482f,.30f));contour.Add(new Vector2(Width*.445f,0));
  var center=new Vector3(0,1.12f,z);Vector3 n=new Vector3(0,0,inward);
  for(int i=0;i<contour.Count;i++){var a=contour[i];var b=contour[(i+1)%contour.Count];shell.Triangle(center,new Vector3(a.x,a.y,z),new Vector3(b.x,b.y,z),n);}
  trim.Cushion(new Vector3(0,1.055f,z+inward*.024f),new Vector3(.84f,2.02f,.045f),Quaternion.identity,.07f,.010f);
  dark.Box(new Vector3(.31f,1.0f,z+inward*.053f),new Vector3(.035f,.115f,.014f));
  metal.Box(new Vector3(.31f,1.0f,z+inward*.064f),new Vector3(.08f,.022f,.018f));
  lights.Sign(new Vector3(0,2.21f,z+inward*.03f),.47f,.13f,!front);
  if(!front)return;
  for(int side=-1;side<=1;side+=2){
   float x=side*Width*.315f,w=Width*.255f,face=end-.79f;
   trim.Cushion(new Vector3(x,.76f,end-.52f),new Vector3(w,1.49f,.53f),Quaternion.identity,.035f,.013f);
   dark.Box(new Vector3(x,1.525f,end-.54f),new Vector3(w+.035f,.035f,.56f));
   for(int drawer=0;drawer<4;drawer++){
    float y=.23f+drawer*.28f;
    metal.Cushion(new Vector3(x,y,face),new Vector3(w-.10f,.247f,.022f),Quaternion.identity,.014f,.004f);
    dark.Box(new Vector3(x,y+.053f,face-.014f),new Vector3(Mathf.Min(.22f,w*.5f),.028f,.011f));
   }
   dark.Box(new Vector3(x,1.82f,end-.21f),new Vector3(w-.04f,.36f,.09f));
   trim.Box(new Vector3(x,1.83f,end-.273f),new Vector3(w-.13f,.28f,.035f));
   metal.Box(new Vector3(x,1.78f,end-.30f),new Vector3(w*.65f,.025f,.016f));
  }
 }
 void BuildDoors(CabinMeshBuilder trim,CabinMeshBuilder metal,CabinMeshBuilder dark,float half){
  foreach(int side in new[]{-1,1})foreach(int end in new[]{-1,1}){
   float x=side*(Width*.5f-.08f),z=end*(half-1.05f);
   Quaternion turn=Quaternion.Euler(0,90,0);
   trim.Cushion(new Vector3(x,1.075f,z),new Vector3(.77f,2.06f,.042f),turn,.10f,.012f);
   dark.Cushion(new Vector3(x-side*.025f,1.49f,z),new Vector3(.26f,.34f,.015f),turn,.10f,.004f);
   metal.Cushion(new Vector3(x-side*.026f,.99f,z),new Vector3(.23f,.04f,.025f),turn,.012f,.006f);
   dark.Box(new Vector3(x-side*.028f,.17f,z),new Vector3(.025f,.045f,.63f));
   metal.Box(new Vector3(x-side*.031f,.21f,z),new Vector3(.017f,.012f,.66f));
  }
 }
 static float[] SeatColumns(float width){if(width<3)return new[]{-1.00f,-.51f,.51f,1.00f};if(width<3.4f)return new[]{-1.28f,-.78f,.3f,.78f,1.26f};if(width<4)return new[]{-1.51f,-1.03f,-.55f,.55f,1.03f,1.51f};if(width>=6.1f)return new[]{-2.75f,-2.25f,-1.75f,-.75f,-.25f,.25f,.75f,1.75f,2.25f,2.75f};if(width>=5.8f)return new[]{-2.42f,-1.92f,-1.42f,-.5f,0,.5f,1.42f,1.92f,2.42f};return new[]{-2.23f,-1.73f,-.75f,-.25f,.25f,.75f,1.73f,2.23f};}
 void Add(CabinMeshBuilder batch,string name,Color color,float smooth,Texture2D texture,float ambient,bool unlit=false){
  var material=SkyboundBootstrap.MakeMaterial(color,unlit);material.name=name;
  if(material.HasProperty("_Cull"))material.SetFloat("_Cull",0);
  if(material.HasProperty("_Smoothness"))material.SetFloat("_Smoothness",smooth);
  if(material.HasProperty("_Metallic"))material.SetFloat("_Metallic",name.Contains("fittings")?.22f:0);
  if(texture){if(material.HasProperty("_BaseMap"))material.SetTexture("_BaseMap",texture);if(material.HasProperty("_MainTex"))material.SetTexture("_MainTex",texture);}
  if(ambient>0&&material.HasProperty("_EmissionColor")){material.EnableKeyword("_EMISSION");material.SetColor("_EmissionColor",color*ambient);}
  materials.Add(material);meshes.Add(batch.Create(transform,name,material));VertexCount+=batch.VertexCount;TriangleCount+=batch.TriangleCount;
 }
 Texture2D WeaveTexture(string name,bool carpet){
  const int size=64;var texture=new Texture2D(size,size,TextureFormat.RGB24,true){name=name,wrapMode=TextureWrapMode.Repeat,filterMode=FilterMode.Trilinear,anisoLevel=2};
  var pixels=new Color[size*size];
  for(int y=0;y<size;y++)for(int x=0;x<size;x++){
   int hash=(x*1973+y*9277+89173)&255;float noise=hash/255f;
   bool warp=(x%4<2),weft=(y%4<2);float v=.74f+(warp!=weft?.13f:0)+noise*.065f;
   if(carpet)v=.57f+(x%8<4?.13f:0)+(y%8<4?.09f:0)+noise*.11f;
   pixels[y*size+x]=new Color(v,v,v,1);
  }
  texture.SetPixels(pixels);texture.Apply(true,false);textures.Add(texture);return texture;
 }
 Texture2D LightingAtlas(){
  const int width=256,height=64;var texture=new Texture2D(width,height,TextureFormat.RGB24,false){name="Cabin warm channels and EXIT lettering",wrapMode=TextureWrapMode.Clamp,filterMode=FilterMode.Bilinear};
  var pixels=new Color[width*height];for(int y=0;y<height;y++)for(int x=0;x<width;x++)pixels[y*width+x]=x<width/2?new Color(1,.87f,.67f):new Color(.025f,.33f,.19f);
  string[] glyphs={"11111/10000/10000/11110/10000/10000/11111","10001/01010/00100/00100/00100/01010/10001","11111/00100/00100/00100/00100/00100/11111","11111/00100/00100/00100/00100/00100/00100"};
  const int scale=4,startX=144,startY=18;
  for(int letter=0;letter<glyphs.Length;letter++){
   var lines=glyphs[letter].Split('/');for(int row=0;row<7;row++)for(int col=0;col<5;col++)if(lines[row][col]=='1')for(int py=0;py<scale;py++)for(int px=0;px<scale;px++){
    int x=startX+letter*24+col*scale+px,y=startY+(6-row)*scale+py;pixels[y*width+x]=new Color(.91f,1,.93f);
   }
  }
  texture.SetPixels(pixels);texture.Apply(false,false);textures.Add(texture);return texture;
 }
 void OnDestroy(){foreach(var mesh in meshes)if(mesh)Destroy(mesh);foreach(var material in materials)if(material)Destroy(material);foreach(var texture in textures)if(texture)Destroy(texture);}
}

// Small shared mesh authoring utility; one generated mesh and renderer per material group.
internal class AirlinerMeshBatch {
 readonly List<Vector3> vertices=new List<Vector3>();readonly List<int> triangles=new List<int>();readonly Vector3[] boxPoints=new Vector3[8];
 public void Quad(Vector3 a,Vector3 b,Vector3 c,Vector3 d){int i=vertices.Count;vertices.Add(a);vertices.Add(b);vertices.Add(c);vertices.Add(d);triangles.Add(i);triangles.Add(i+1);triangles.Add(i+2);triangles.Add(i);triangles.Add(i+2);triangles.Add(i+3);}
 public void Triangle(Vector3 a,Vector3 b,Vector3 c){int i=vertices.Count;vertices.Add(a);vertices.Add(b);vertices.Add(c);triangles.Add(i);triangles.Add(i+1);triangles.Add(i+2);}
 public void Box(Vector3 center,Vector3 size){Box(center,size,Quaternion.identity);}
 public void Box(Vector3 center,Vector3 size,Quaternion rotation){Vector3 e=size*.5f;Vector3[] p=boxPoints;for(int i=0;i<8;i++)p[i]=center+rotation*new Vector3((i&1)==0?-e.x:e.x,(i&2)==0?-e.y:e.y,(i&4)==0?-e.z:e.z);Quad(p[0],p[2],p[3],p[1]);Quad(p[4],p[5],p[7],p[6]);Quad(p[0],p[4],p[6],p[2]);Quad(p[1],p[3],p[7],p[5]);Quad(p[0],p[1],p[5],p[4]);Quad(p[2],p[6],p[7],p[3]);}
 public void WindowPanel(float x,float y,float z,float width,float height,float openingWidth,float openingHeight,int side){for(int i=0;i<32;i++){float a=i*Mathf.PI*2/32,b=(i+1)*Mathf.PI*2/32;Vector3 Outer(float t){float s=Mathf.Sin(t),c=Mathf.Cos(t),d=Mathf.Max(Mathf.Abs(s),Mathf.Abs(c));return new Vector3(x,y+c/d*height*.5f,z+s/d*width*.5f);}Vector3 Inner(float t)=>new Vector3(x,y+Mathf.Cos(t)*openingHeight,z+Mathf.Sin(t)*openingWidth);if(side>0)Quad(Outer(a),Outer(b),Inner(b),Inner(a));else Quad(Outer(b),Outer(a),Inner(a),Inner(b));}}
 public Mesh Create(Transform parent,string name,Material material){var mesh=new Mesh{name=name};if(vertices.Count>65535)mesh.indexFormat=IndexFormat.UInt32;mesh.SetVertices(vertices);mesh.SetTriangles(triangles,0);mesh.RecalculateNormals();mesh.RecalculateBounds();var go=new GameObject(name);go.transform.SetParent(parent,false);go.AddComponent<MeshFilter>().sharedMesh=mesh;var renderer=go.AddComponent<MeshRenderer>();renderer.sharedMaterial=material;renderer.shadowCastingMode=ShadowCastingMode.Off;return mesh;}
}
}
