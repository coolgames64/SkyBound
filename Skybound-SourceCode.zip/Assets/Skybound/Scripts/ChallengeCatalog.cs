using System;
using System.Collections.Generic;
using UnityEngine;

namespace Skybound {
[Serializable]
public class ChallengeDefinition {
 public string Id,Name,Description;
 // Empty retains the original destination for saved v1 challenges.
 public string RunwayId="";
 public FlightMode Mode=FlightMode.Hudson;
 public int Difficulty=2;
 public float StartAltitude=480,StartSpeed=85,Throttle=.65f,Fuel=1,Wind,GustStrength,FailureDelay=8;
 // Positive approach offset moves the start farther behind the existing approach.
 public float ApproachOffset,LateralOffset,HeadingOffset,StartPitch;
 public int InitialFlaps;
 public bool InitialGear;
 public ChallengeDefinition Copy()=>(ChallengeDefinition)MemberwiseClone();
}

public static class ChallengeCatalog {
 public const int ExpectedCount=20;
 public static readonly FlightMode[] SupportedModes={FlightMode.Hudson,FlightMode.Glide,FlightMode.Crosswind,FlightMode.SingleEngine,FlightMode.FuelEmergency,FlightMode.GearFailure,FlightMode.SevereWeather,FlightMode.RightEngine,FlightMode.FlapFailure,FlightMode.GearDownLock,FlightMode.ThrottleFailure,FlightMode.GoAround,FlightMode.TouchAndGo,FlightMode.RejectedTakeoff,FlightMode.StallRecovery,FlightMode.EngineRelight,FlightMode.PrecisionLanding,FlightMode.FullStop,FlightMode.EmergencyPower,FlightMode.Evacuation};
 static readonly IReadOnlyList<ChallengeDefinition> builtIn=Build().AsReadOnly();
 public static IReadOnlyList<ChallengeDefinition> BuiltIn=>builtIn;
 public static bool IsSupported(FlightMode mode)=>mode>=FlightMode.Hudson&&mode<=FlightMode.Evacuation;
 public static string IdForMode(FlightMode mode)=>mode<=FlightMode.SevereWeather?"original-"+mode.ToString().ToLowerInvariant():"mission-"+mode.ToString().ToLowerInvariant();
 public static bool RequiresRAT(FlightMode mode)=>mode==FlightMode.EmergencyPower;
 public static bool AllowsAssist(FlightMode mode)=>mode!=FlightMode.StallRecovery;
 public static bool HasTimedFailure(FlightMode mode){
  switch(mode){case FlightMode.Hudson:case FlightMode.SingleEngine:case FlightMode.GearFailure:case FlightMode.RightEngine:case FlightMode.FlapFailure:case FlightMode.GearDownLock:case FlightMode.ThrottleFailure:case FlightMode.EngineRelight:case FlightMode.EmergencyPower:case FlightMode.Evacuation:return true;default:return false;}
 }
 public static ChallengeDefinition CreateDefault(FlightMode mode){
  if(!IsSupported(mode))mode=FlightMode.Hudson;
  if(mode>FlightMode.SevereWeather)return CreateNewDefault(mode);
  // The original seven defaults and IDs are kept exact for saved challenges and compatibility APIs.
  var d=new ChallengeDefinition{Id=IdForMode(mode),Mode=mode,Name=MissionDirector.NameFor(mode),Description=DescriptionFor(mode),Difficulty=mode==FlightMode.SevereWeather||mode==FlightMode.GearFailure?4:mode==FlightMode.Crosswind||mode==FlightMode.SingleEngine?3:2,StartAltitude=mode==FlightMode.Hudson?480:mode==FlightMode.SingleEngine?240:mode==FlightMode.FuelEmergency?220:mode==FlightMode.GearFailure?200:270,StartPitch=mode==FlightMode.Hudson?0:-3,InitialFlaps=mode==FlightMode.Hudson?0:1,InitialGear=mode!=FlightMode.Hudson&&mode!=FlightMode.GearFailure,FailureDelay=mode==FlightMode.GearFailure?6:8};
  d.Throttle=mode==FlightMode.Crosswind||mode==FlightMode.GearFailure||mode==FlightMode.SevereWeather?.25f:mode==FlightMode.SingleEngine?.55f:mode==FlightMode.FuelEmergency?.3f:.65f;
  d.Fuel=mode==FlightMode.FuelEmergency?.02f:1;d.Wind=mode==FlightMode.Crosswind?7:mode==FlightMode.SevereWeather?12:0;d.GustStrength=mode==FlightMode.SevereWeather?10:0;return d;
 }
 static ChallengeDefinition CreateNewDefault(FlightMode mode){
  string id=DefaultRunwayFor(mode);var runway=RunwayCatalog.FindByIdent(id);
  float height=mode==FlightMode.StallRecovery?1000:mode==FlightMode.EngineRelight?700:mode==FlightMode.EmergencyPower?400:270;
  var d=new ChallengeDefinition{Id=IdForMode(mode),Mode=mode,Name=NameForNewMode(mode),Description=DescriptionFor(mode),RunwayId=id,Difficulty=3,StartAltitude=(runway!=null?runway.Elevation:0)+height,StartSpeed=85,Throttle=.35f,Fuel=1,StartPitch=-3,InitialFlaps=1,InitialGear=true,FailureDelay=8};
  switch(mode){
   case FlightMode.RightEngine:d.Throttle=.55f;break;
   case FlightMode.FlapFailure:d.StartSpeed=100;d.InitialFlaps=0;d.Throttle=.35f;d.FailureDelay=6;d.Difficulty=4;break;
   case FlightMode.GearDownLock:d.Throttle=.55f;d.FailureDelay=6;break;
   case FlightMode.ThrottleFailure:d.StartSpeed=90;d.Throttle=.3f;d.Difficulty=4;break;
   case FlightMode.GoAround:d.Throttle=.35f;break;
   case FlightMode.TouchAndGo:d.Throttle=.35f;break;
   case FlightMode.RejectedTakeoff:d.Throttle=1;d.FailureDelay=6;d.Difficulty=2;break;
   case FlightMode.StallRecovery:d.StartSpeed=85;d.StartPitch=0;d.Throttle=.55f;d.Difficulty=4;break;
   case FlightMode.EngineRelight:d.Throttle=.65f;d.Difficulty=4;break;
   case FlightMode.PrecisionLanding:d.Throttle=.3f;d.Difficulty=3;break;
   case FlightMode.FullStop:d.Throttle=.3f;d.Difficulty=2;break;
   case FlightMode.EmergencyPower:d.Throttle=.65f;d.FailureDelay=6;d.Difficulty=4;break;
   case FlightMode.Evacuation:d.InitialGear=false;d.InitialFlaps=2;d.Throttle=.25f;d.FailureDelay=6;d.Difficulty=4;break;
  }
  return d;
 }
 public static ChallengeDefinition Normalize(ChallengeDefinition input){
  var d=input==null?CreateDefault(FlightMode.Hudson):input.Copy();if(!IsSupported(d.Mode))d.Mode=FlightMode.Hudson;var defaults=CreateDefault(d.Mode);
  d.Id=CleanId(d.Id);if(string.IsNullOrEmpty(d.Id))d.Id="custom-"+Guid.NewGuid().ToString("N");d.Name=CleanText(d.Name,64,defaults.Name);d.Description=CleanText(d.Description,240,defaults.Description);
  var runway=d.Mode==FlightMode.Hudson?null:RunwayCatalog.FindByIdent(d.RunwayId);d.RunwayId=d.Mode==FlightMode.Hudson?"":runway!=null?runway.Ident:defaults.RunwayId??"";
  if(runway==null&&!string.IsNullOrEmpty(d.RunwayId))runway=RunwayCatalog.FindByIdent(d.RunwayId);
  float altitudeMinimum=runway!=null?Mathf.Max(100,runway.Elevation+100):100;
  float altitudeLimit=string.IsNullOrEmpty(d.RunwayId)?1800:6000;
  d.Difficulty=Mathf.Clamp(d.Difficulty,1,5);d.StartAltitude=Bound(d.StartAltitude,altitudeMinimum,altitudeLimit,Mathf.Clamp(defaults.StartAltitude,altitudeMinimum,altitudeLimit));d.StartSpeed=Bound(d.StartSpeed,60,125,85);d.Throttle=Bound(d.Throttle,0,1,defaults.Throttle);d.Fuel=Bound(d.Fuel,0,1,defaults.Fuel);d.Wind=Bound(d.Wind,-20,20,defaults.Wind);d.GustStrength=Bound(d.GustStrength,0,15,defaults.GustStrength);d.FailureDelay=Bound(d.FailureDelay,0,60,defaults.FailureDelay);d.ApproachOffset=Bound(d.ApproachOffset,-500,2500,0);d.LateralOffset=Bound(d.LateralOffset,-350,350,0);d.HeadingOffset=Bound(d.HeadingOffset,-12,12,0);d.StartPitch=Bound(d.StartPitch,-6,3,defaults.StartPitch);d.InitialFlaps=Mathf.Clamp(d.InitialFlaps,0,2);return d;
 }
 static float Bound(float value,float min,float max,float fallback)=>float.IsNaN(value)||float.IsInfinity(value)?fallback:Mathf.Clamp(value,min,max);
 static string CleanText(string value,int maximum,string fallback){if(string.IsNullOrWhiteSpace(value))return fallback;var clean=new System.Text.StringBuilder();foreach(char c in value)clean.Append(char.IsControl(c)?' ':c);value=clean.ToString().Trim();if(value.Length==0)return fallback;return value.Length>maximum?value.Substring(0,maximum):value;}
 static string CleanId(string value){if(string.IsNullOrEmpty(value))return "";var chars=new System.Text.StringBuilder();foreach(char c in value){if(char.IsLetterOrDigit(c)||c=='-'||c=='_')chars.Append(c);if(chars.Length>=80)break;}return chars.ToString();}
 static string DefaultRunwayFor(FlightMode mode){
  switch(mode){case FlightMode.RightEngine:return "YSSY / 16R";case FlightMode.FlapFailure:return "EHAM / 18R";case FlightMode.GearDownLock:return "CYVR / 26L";case FlightMode.ThrottleFailure:return "OMDB / 30R";case FlightMode.GoAround:return "EDDF / 25R";case FlightMode.TouchAndGo:return "CYUL / 24R";case FlightMode.RejectedTakeoff:return "KDFW / 17C";case FlightMode.StallRecovery:return "NZAA / 23L";case FlightMode.EngineRelight:return "RJTT / 22";case FlightMode.PrecisionLanding:return "LPPT / 02";case FlightMode.FullStop:return "KBOS / 22L";case FlightMode.EmergencyPower:return "RJTT / 34R";case FlightMode.Evacuation:return "LIRF / 16R";default:return "";}
 }
 static string NameForNewMode(FlightMode mode){
  switch(mode){case FlightMode.RightEngine:return "Sydney: the other engine";case FlightMode.FlapFailure:return "Amsterdam: clean-wing arrival";case FlightMode.GearDownLock:return "Vancouver: gear stuck down";case FlightMode.ThrottleFailure:return "Dubai: thrust control failure";case FlightMode.GoAround:return "Frankfurt: go around";case FlightMode.TouchAndGo:return "Montreal: touch and go";case FlightMode.RejectedTakeoff:return "Dallas: reject the takeoff";case FlightMode.StallRecovery:return "Auckland: recover the stall";case FlightMode.EngineRelight:return "Haneda: restart the engines";case FlightMode.PrecisionLanding:return "Lisbon: the touchdown box";case FlightMode.FullStop:return "Boston: stop before the end";case FlightMode.EmergencyPower:return "Haneda: emergency power";case FlightMode.Evacuation:return "Rome: land and evacuate";default:return MissionDirector.NameFor(mode);}
 }
 public static string LocationFor(ChallengeDefinition definition){
  if(definition==null)return "";if(definition.Mode==FlightMode.Hudson)return "Hudson River / New York";string id=string.IsNullOrEmpty(definition.RunwayId)?DefaultRunwayFor(definition.Mode):definition.RunwayId;var runway=RunwayCatalog.FindByIdent(id);
  if(runway!=null)return runway.Name+" / "+runway.Ident;
  return definition.Mode==FlightMode.Hudson?"Hudson River / New York":definition.Mode==FlightMode.Crosswind||definition.Mode==FlightMode.SevereWeather?"San Francisco / SFO":definition.Mode<=FlightMode.SevereWeather?"London / Heathrow":id;
 }
 public static string ProcedureFor(FlightMode mode){
  switch(mode){
   case FlightMode.Hudson:return "Glide over the Hudson after both engines fail; keep gear up and ditch gently with level wings.";
   case FlightMode.Glide:return "Manage glide energy and land gently on the marked runway with gear down.";
   case FlightMode.Crosswind:return "Correct drift and align with the runway for a controlled crosswind landing.";
   case FlightMode.SingleEngine:return "Balance the failed left engine with rudder and land with gear down.";
   case FlightMode.FuelEmergency:return "Preserve the limited fuel reserve and reach the runway even if the engines stop.";
   case FlightMode.GearFailure:return "Land on the runway with the jammed gear up, full flaps and a gentle descent.";
   case FlightMode.SevereWeather:return "Keep a stable, aligned approach through gusts and reduced visibility.";
   case FlightMode.RightEngine:return "Balance a failed right engine and land on the selected Sydney runway.";
   case FlightMode.FlapFailure:return "Keep airspeed safely above the clean-wing stall speed and land without flaps.";
   case FlightMode.GearDownLock:return "Manage extra gear drag and complete the approach with the gear locked down.";
   case FlightMode.ThrottleFailure:return "Manage a restricted thrust setting and land without relying on full power.";
   case FlightMode.GoAround:return "Go around from the low approach, climb through the recovery gate, then return to land.";
   case FlightMode.TouchAndGo:return "Make a gentle runway contact, add power and maintain a stable climb away for three seconds.";
   case FlightMode.RejectedTakeoff:return "Abort when the alert appears: close thrust, brake and stop inside the runway.";
   case FlightMode.StallRecovery:return "At the safe training altitude, idle the thrust and raise the nose until an actual stall; then lower the nose, restore power and hold controlled flight.";
   case FlightMode.EngineRelight:return "After engine shutdown, relight the engines and hold a stable powered climb for five seconds.";
   case FlightMode.PrecisionLanding:return "Touch down gently inside the highlighted touchdown zone near the centreline.";
   case FlightMode.FullStop:return "Land gently, close the thrust and brake to a full stop before the runway ends.";
   case FlightMode.EmergencyPower:return "Maintain airflow for the fitted ram-air turbine and complete the engine-out runway landing.";
   case FlightMode.Evacuation:return "Complete the gear-up landing, stop the engines and fully inflate the evacuation slides.";
   default:return "Explore the world and practise aircraft handling.";
  }
 }
 public static string DescriptionFor(FlightMode mode){
  switch(mode){
   case FlightMode.Hudson:return "Hudson River · Both engines lost · Gear-up water landing";
   case FlightMode.Glide:return "London Heathrow · No thrust · Preserve energy for the runway";
   case FlightMode.Crosswind:return "San Francisco · Crosswind · Precision runway touchdown";
   case FlightMode.SingleEngine:return "London Heathrow · Left engine failure · Balance the thrust";
   case FlightMode.FuelEmergency:return "London Heathrow · Limited fuel · Prepare to glide";
   case FlightMode.GearFailure:return "London Heathrow · Gear jammed up · Gentle belly landing";
   case FlightMode.SevereWeather:return "San Francisco · Gusts and reduced visibility · Stable approach";
   case FlightMode.RightEngine:return "Sydney · Right engine failure · Balance the asymmetric thrust";
   case FlightMode.FlapFailure:return "Amsterdam · Flaps unavailable · Clean-wing runway landing";
   case FlightMode.GearDownLock:return "Vancouver · Gear locked down · Manage the extra drag";
   case FlightMode.ThrottleFailure:return "Dubai · Restricted thrust control · Manage approach energy";
   case FlightMode.GoAround:return "Frankfurt · Abandon the low approach · Climb and return to land";
   case FlightMode.TouchAndGo:return "Montreal · Gentle runway contact · Add power and climb away again";
   case FlightMode.RejectedTakeoff:return "Dallas · Abort alert on the runway · Stop before the end";
   case FlightMode.StallRecovery:return "Auckland · Induce a stall manually at a safe altitude, then lower the nose and restore power to recover";
   case FlightMode.EngineRelight:return "Tokyo Haneda · Engine shutdown · Relight and hold a powered climb";
   case FlightMode.PrecisionLanding:return "Lisbon · Marked touchdown zone · Accurate, gentle runway contact";
   case FlightMode.FullStop:return "Boston · Runway landing and braking · Full stop inside the runway";
   case FlightMode.EmergencyPower:return "Tokyo Haneda · Both engines lost · RAT-powered emergency approach";
   case FlightMode.Evacuation:return "Rome · Controlled gear-up landing · Stop engines and deploy exit slides";
   default:return "Free flight · Explore anywhere";
  }
 }
 static List<ChallengeDefinition> Build(){
  var result=new List<ChallengeDefinition>(ExpectedCount);foreach(var mode in SupportedModes)result.Add(CreateDefault(mode));
  if(result.Count!=ExpectedCount)throw new InvalidOperationException("Challenge catalog must contain exactly "+ExpectedCount+" distinct mission definitions.");return result;
 }
}

public static class ChallengeStore {
 const string CustomKey="Skybound.CustomChallenges.v1",CompletedKey="Skybound.CompletedChallenges.v1";
 [Serializable]class Definitions {public List<ChallengeDefinition> Items=new List<ChallengeDefinition>();}
 [Serializable]class Completion {public List<string> Ids=new List<string>();}
 public static List<ChallengeDefinition> Load(){
  var result=new List<ChallengeDefinition>();if(!PlayerPrefs.HasKey(CustomKey))return result;
  try{var data=JsonUtility.FromJson<Definitions>(PlayerPrefs.GetString(CustomKey));if(data?.Items==null)return result;var ids=new HashSet<string>();foreach(var entry in data.Items){if(entry==null)continue;var d=ChallengeCatalog.Normalize(entry);if(!d.Id.StartsWith("custom-",StringComparison.Ordinal)){d.Id="custom-"+d.Id;d=ChallengeCatalog.Normalize(d);}if(ids.Add(d.Id))result.Add(d);if(result.Count>=100)break;}}catch(ArgumentException){}return result;
 }
 public static ChallengeDefinition Save(ChallengeDefinition definition){var d=ChallengeCatalog.Normalize(definition);if(!d.Id.StartsWith("custom-",StringComparison.Ordinal))d.Id="custom-"+Guid.NewGuid().ToString("N");var all=Load();int index=all.FindIndex(item=>item.Id==d.Id);if(index>=0)all[index]=d;else if(all.Count<100)all.Add(d);else throw new InvalidOperationException("You have 100 custom challenges. Delete one before saving another.");Write(all);return d.Copy();}
 public static bool Delete(string id){var all=Load();bool removed=all.RemoveAll(item=>item.Id==id)>0;if(removed)Write(all);return removed;}
 static void Write(List<ChallengeDefinition> values){PlayerPrefs.SetString(CustomKey,JsonUtility.ToJson(new Definitions{Items=values}));PlayerPrefs.Save();}
 public static bool IsCompleted(string id)=>Completed().Ids.Contains(id);
 public static void MarkCompleted(string id){if(string.IsNullOrEmpty(id))return;var data=Completed();if(data.Ids.Contains(id))return;data.Ids.Add(id);PlayerPrefs.SetString(CompletedKey,JsonUtility.ToJson(data));PlayerPrefs.Save();}
 static Completion Completed(){try{var data=JsonUtility.FromJson<Completion>(PlayerPrefs.GetString(CompletedKey,"{}"));return data?.Ids!=null?data:new Completion();}catch(ArgumentException){return new Completion();}}
}
}
