using System;
using System.Globalization;
using System.Collections.Generic;
using UnityEngine;
namespace Skybound {
public enum MenuPage { Discover, Explore, Challenges, Briefing, Flight, Pause, Controls, Credits, Fleet, MobilePrompt, Create, AircraftDesigner, ChallengeBuilder, SavedCreations }
public class FlightHUD:MonoBehaviour {
 public FlightController Aircraft;public SatelliteWorld World;public MissionDirector Mission;public FlightCamera CameraRig;public AircraftVisual Visual;
 public MenuPage Menu=MenuPage.Discover;public bool LandingAssist,MouseJoystick,MobileControls;
 public bool ResultsDismissed {get;private set;}
 int stickControl,thrustControl,brakeControl,touchStick=-1,touchThrust=-1,touchBrake=-1;bool stickDragging,thrustDragging,mouseThrustCaptured,thrustMouseWasDown,mouseBrakeCaptured,auxiliaryMouseWasDown;Vector2 stickPosition;
 FlightMode briefing=FlightMode.Hudson;string latitude="40.773",longitude="-73.998",validation="";bool sound=true;int selectedPlace;bool resume;Vector2 creditScroll,fleetScroll,challengeScroll;string fleetSearch="";MenuPage fleetReturn=MenuPage.Explore;string credits;
 FlightMode[] challengeModes=>ChallengeCatalog.SupportedModes;
 // Drafts are independent copies. Preview changes the selected airframe; Save persists it.
 AircraftDesign aircraftDraft;ChallengeDefinition challengeDraft,selectedChallenge;
 List<AircraftDesign> savedAircraft;List<ChallengeDefinition> savedChallenges;
 readonly List<ChallengeDefinition> challengeMatches=new List<ChallengeDefinition>();
 readonly HashSet<string> completedChallenges=new HashSet<string>();
 string challengeSearch="",lastChallengeSearch,creationSearch="",creatorFeedback="",deletionId="";
 bool customChallengeSource,lastCustomChallengeSource,challengeFilterDirty=true,savedChallengeTab,flyDesignWhenReady;
 int challengePage;Vector2 creationScroll,builderScroll;
 readonly Color[] designColors={Color.white,new Color(.67f,.79f,.94f),new Color(.74f,.87f,.79f),new Color(.88f,.73f,.69f),new Color(.9f,.83f,.65f),new Color(.65f,.69f,.75f)};
 readonly string[] designColorNames={"White","Blue","Green","Red","Gold","Grey"};
 readonly string[] places={"New York","San Francisco","London","Sydney","Tokyo","Swiss Alps"};
 readonly double[] lats={40.773,37.62,51.505,-33.86,35.68,46.58},lons={-73.998,-122.37,-.12,151.21,139.76,8.0};
 GUIStyle text,small,title,big,button,field,metric,eyebrow,sliderTrack,sliderThumb;Texture2D pixel;Color ink=new Color(.93f,.96f,.96f),muted=new Color(.62f,.7f,.72f),lime=new Color(.79f,.96f,.46f);
 public void DetectMobile(){if(BrowserPlatform.Mobile){Menu=MenuPage.MobilePrompt;Time.timeScale=0;}}
 void Update(){if(flyDesignWhenReady){if(Menu!=MenuPage.AircraftDesigner&&Menu!=MenuPage.SavedCreations)flyDesignWhenReady=false;else if(!Visual.Loading){flyDesignWhenReady=false;BeginFlight(FlightMode.FreeFlight,lats[selectedPlace],lons[selectedPlace],places[selectedPlace]);}}UpdateTouchStick();UpdateTouchThrust();UpdateMouseThrust();UpdateAuxiliaryControls();if(FlightInput.Down(KeyCode.V)&&Menu==MenuPage.Flight)CameraRig.ToggleView();if(FlightInput.Down(KeyCode.X)&&Menu==MenuPage.Flight)DeploySlides();if(FlightInput.Down(KeyCode.Escape)||(FlightInput.Down(KeyCode.P)&&(Menu==MenuPage.Flight||Menu==MenuPage.Pause))){if(Menu==MenuPage.Flight&&!Mission.Finished)OpenMenu(MenuPage.Pause);else if(resume)Resume();}
  if(FlightInput.Down(KeyCode.M)&&Menu==MenuPage.Flight)OpenMenu(MenuPage.Explore);
 }
 void Init(){if(pixel)return;pixel=Texture2D.whiteTexture;text=new GUIStyle(GUI.skin.label){fontSize=20,wordWrap=true,normal={textColor=ink}};small=new GUIStyle(text){fontSize=14,normal={textColor=muted}};title=new GUIStyle(text){fontSize=49,fontStyle=FontStyle.Bold};big=new GUIStyle(title){fontSize=72};metric=new GUIStyle(title){fontSize=32};eyebrow=new GUIStyle(small){fontSize=13,fontStyle=FontStyle.Bold,normal={textColor=lime}};button=new GUIStyle(GUI.skin.button){fontSize=17,fontStyle=FontStyle.Bold,alignment=TextAnchor.MiddleLeft,padding=new RectOffset(18,12,8,8),normal={textColor=ink,background=pixel},hover={textColor=Color.black,background=pixel},active={textColor=Color.black,background=pixel}};field=new GUIStyle(GUI.skin.textField){fontSize=20,padding=new RectOffset(12,12,12,12),normal={textColor=ink,background=pixel},focused={textColor=ink,background=pixel}};sliderTrack=new GUIStyle(GUI.skin.horizontalSlider){fixedHeight=8,normal={background=pixel},margin=new RectOffset(0,0,9,9)};sliderThumb=new GUIStyle(GUI.skin.horizontalSliderThumb){fixedWidth=26,fixedHeight=26,normal={background=pixel},hover={background=pixel},active={background=pixel}};}
 void Box(float x,float y,float width,float height,Color c){var old=GUI.color;GUI.color=c;GUI.DrawTexture(new Rect(x,y,width,height),pixel);GUI.color=old;}
 void Label(float x,float y,float width,float height,string value,GUIStyle style=null){GUI.Label(new Rect(x,y,width,height),value,style??text);}
 bool Button(float x,float y,float width,float height,string value,bool primary=false){var old=GUI.backgroundColor;GUI.backgroundColor=primary?lime:new Color(.17f,.24f,.27f);var oldText=button.normal.textColor;button.normal.textColor=primary?new Color(.05f,.11f,.12f):ink;bool b=GUI.Button(new Rect(x,y,width,height),value,button);button.normal.textColor=oldText;GUI.backgroundColor=old;return b;}
 string Field(float x,float y,float width,string value,int maximum=0){var old=GUI.backgroundColor;GUI.backgroundColor=new Color(.12f,.18f,.21f);var area=new Rect(x,y,width,48);var result=maximum>0?GUI.TextField(area,value,maximum,field):GUI.TextField(area,value,field);GUI.backgroundColor=old;return result;}
 void OpenMenu(MenuPage page){ReleaseFlightControls();resume=!Mission.Finished&&(Menu==MenuPage.Flight||resume);Menu=page;Time.timeScale=0;}
 void Resume(){Menu=MenuPage.Flight;Time.timeScale=1;resume=false;}
 public void BeginFlight(FlightMode mode,double lat,double lon,string name,bool startOnRunway=true){if(Visual.Loading)return;if(mode!=FlightMode.FreeFlight&&!CanLaunchChallenge(ChallengeCatalog.CreateDefault(mode)))return;flyDesignWhenReady=false;selectedChallenge=null;if(mode!=FlightMode.FreeFlight&&!ChallengeCatalog.AllowsAssist(mode))LandingAssist=false;ReleaseFlightControls();ResultsDismissed=false;Mission.StartFlight(mode,lat,lon,name,LandingAssist,startOnRunway);Menu=MenuPage.Flight;resume=false;}
 public void BeginChallenge(ChallengeDefinition definition,bool startOnRunway=true){if(Visual.Loading||definition==null)return;var normalized=ChallengeCatalog.Normalize(definition);if(!CanLaunchChallenge(normalized)){ShowChallenge(normalized);return;}flyDesignWhenReady=false;selectedChallenge=normalized;briefing=selectedChallenge.Mode;if(!ChallengeCatalog.AllowsAssist(briefing))LandingAssist=false;ReleaseFlightControls();ResultsDismissed=false;Mission.StartChallenge(selectedChallenge,LandingAssist,startOnRunway);Menu=MenuPage.Flight;resume=false;}
 bool CanLaunchChallenge(ChallengeDefinition definition){if(ChallengeCatalog.RequiresRAT(definition.Mode)&&!Aircraft.RATAvailable){creatorFeedback="This challenge needs a ram-air turbine. Choose a RAT-fitted aircraft in the fleet.";return false;}creatorFeedback="";return true;}
 void ShowChallenge(ChallengeDefinition definition){selectedChallenge=ChallengeCatalog.Normalize(definition);briefing=selectedChallenge.Mode;if(!ChallengeCatalog.AllowsAssist(briefing))LandingAssist=false;flyDesignWhenReady=false;ReleaseFlightControls();Time.timeScale=0;Menu=MenuPage.Briefing;}
 void GoTo(MenuPage page){flyDesignWhenReady=false;ReleaseFlightControls();resume=!Mission.Finished&&(Menu==MenuPage.Flight||resume);Time.timeScale=0;Menu=page;if(page==MenuPage.Challenges||page==MenuPage.Create||page==MenuPage.SavedCreations)ReloadCreations();}
 public void ReloadCreations(){savedAircraft=AircraftDesignStore.Load();savedChallenges=ChallengeStore.Load();completedChallenges.Clear();foreach(var d in ChallengeCatalog.BuiltIn)if(ChallengeStore.IsCompleted(d.Id))completedChallenges.Add(d.Id);foreach(var d in savedChallenges)if(ChallengeStore.IsCompleted(d.Id))completedChallenges.Add(d.Id);challengeFilterDirty=true;}
 void EnsureCreations(){if(savedAircraft==null||savedChallenges==null)ReloadCreations();}
 void OnGUI(){Init();Rect safe=MobileControls?Screen.safeArea:new Rect(0,0,Screen.width,Screen.height);float scale=Mathf.Min(safe.width/1440f,safe.height/900f);GUI.matrix=Matrix4x4.TRS(new Vector3(safe.x+(safe.width-1440*scale)/2,Screen.height-safe.yMax+(safe.height-900*scale)/2,0),Quaternion.identity,Vector3.one*scale);
  if(Menu==MenuPage.Flight){DrawFlight();DrawCredits();return;}
  if(Menu==MenuPage.MobilePrompt){Box(0,0,1440,900,new Color(.02f,.07f,.1f,.6f));Box(0,0,660,900,new Color(.035f,.085f,.11f,.97f));Label(42,50,550,40,"S K Y B O U N D",eyebrow);MobilePrompt();return;}
  Box(0,0,1440,900,new Color(.02f,.07f,.1f,.22f));Box(0,0,660,900,new Color(.035f,.085f,.11f,.93f));
  Label(42,30,310,44,"S K Y B O U N D",new GUIStyle(text){fontSize=22,fontStyle=FontStyle.Bold});Label(42,75,360,24,"THE WORLD IS YOUR RUNWAY",eyebrow);
  if(Button(42,125,150,44,"Discover",Menu==MenuPage.Discover))GoTo(MenuPage.Discover);
  if(Button(202,125,150,44,"Explore",Menu==MenuPage.Explore))GoTo(MenuPage.Explore);
  if(Button(362,125,230,44,"Challenges",Menu==MenuPage.Challenges))GoTo(MenuPage.Challenges);
  switch(Menu){case MenuPage.Discover:Discover();break;case MenuPage.Explore:Explore();break;case MenuPage.Challenges:Challenges();break;case MenuPage.Briefing:Briefing();break;case MenuPage.Pause:Pause();break;case MenuPage.Controls:Controls();break;case MenuPage.Credits:Credits();break;case MenuPage.Fleet:Fleet();break;case MenuPage.MobilePrompt:MobilePrompt();break;case MenuPage.Create:CreateMenu();break;case MenuPage.AircraftDesigner:AircraftDesigner();break;case MenuPage.ChallengeBuilder:ChallengeBuilder();break;case MenuPage.SavedCreations:SavedCreations();break;}
  Box(1050,40,340,80,new Color(.035f,.085f,.11f,.85f));Label(1070,53,300,22,"LIVE SATELLITE EARTH",eyebrow);Label(1070,80,300,30,World.LoadedTiles>0?World.LoadedTiles+" scenery tiles streamed":"Connecting to satellite scenery…",small);
  Label(800,708,550,40,Visual.AircraftName,metric);Label(800,755,550,24,Math.Abs(World.Latitude).ToString("F2")+"° "+(World.Latitude>=0?"N":"S")+"   "+Math.Abs(World.Longitude).ToString("F2")+"° "+(World.Longitude>=0?"E":"W")+"  /  "+Mission.Place,small);
  DrawCredits();
 }
 void Discover(){Label(42,216,560,40,"NO BORDERS. JUST SKY.",eyebrow);Label(38,257,610,185,"Go somewhere\nextraordinary.",big);Label(42,458,555,90,"Fly over real places. Find your own horizon, or take the controls when every second counts.");
  if(Button(42,570,330,58,"Start flying  →",true))BeginFlight(FlightMode.FreeFlight,lats[0],lons[0],places[0]);
  if(Button(42,644,330,52,"Choose a destination"))Menu=MenuPage.Explore;
  if(Button(42,710,330,52,"Learn the controls"))Menu=MenuPage.Controls;
  if(Button(390,644,202,52,"Create"))GoTo(MenuPage.Create);if(Button(390,710,202,52,"My creations"))GoTo(MenuPage.SavedCreations);
  AircraftPicker(790);
 }
 void Explore(){Label(42,209,560,80,"Where to?",title);Label(42,282,565,50,"Choose a place, or start at any latitude and longitude.",small);
  for(int i=0;i<6;i++){int col=i%2,row=i/2;if(Button(42+col*282,343+row*58,268,48,places[i],selectedPlace==i))selectedPlace=i;}
  Label(42,540,555,30,"CUSTOM COORDINATES",eyebrow);Label(42,574,260,24,"Latitude (−85 to 85)",small);Label(324,574,260,24,"Longitude (−180 to 180)",small);latitude=Field(42,607,267,latitude);longitude=Field(324,607,267,longitude);
  if(Button(42,670,267,52,"Fly to coordinates")){if(double.TryParse(latitude,NumberStyles.Float,CultureInfo.InvariantCulture,out double lat)&&double.TryParse(longitude,NumberStyles.Float,CultureInfo.InvariantCulture,out double lon)&&!double.IsNaN(lat)&&!double.IsNaN(lon)&&lat>=-85&&lat<=85&&lon>=-180&&lon<=180){validation="";BeginFlight(FlightMode.FreeFlight,lat,lon,"Custom location");}else validation="Enter valid decimal coordinates in the ranges above.";}
  if(Button(324,670,267,52,"Fly to "+places[selectedPlace],true))BeginFlight(FlightMode.FreeFlight,lats[selectedPlace],lons[selectedPlace],places[selectedPlace]);
  Label(42,730,560,38,validation,small);AircraftPicker(785);if(Button(42,835,550,34,"Create an aircraft or challenge  →"))GoTo(MenuPage.Create);if(resume&&Button(1050,135,340,48,"Resume current flight  →"))Resume();
 }
 void AircraftPicker(float y){Label(42,y,135,38,"AIRCRAFT",eyebrow);if(Button(178,y-7,414,44,Visual.AircraftName+"  ▾")){fleetReturn=Menu;Menu=MenuPage.Fleet;}}
 void Fleet(){
  Label(42,209,560,65,"Choose your aircraft.",new GUIStyle(title){fontSize=38});
  Label(42,279,550,32,"Detailed models · Boeing, Airbus and the MD-11",small);
  fleetSearch=Field(42,323,550,fleetSearch);
  var entries=Visual.Catalog.Aircraft;int count=0;foreach(var entry in entries)if(entry.Name.IndexOf(fleetSearch,StringComparison.OrdinalIgnoreCase)>=0)count++;
  fleetScroll=GUI.BeginScrollView(new Rect(42,393,568,332),fleetScroll,new Rect(0,0,539,Mathf.Max(332,count*57)));
  int row=0;for(int i=0;i<entries.Length;i++){if(entries[i].Name.IndexOf(fleetSearch,StringComparison.OrdinalIgnoreCase)<0)continue;if(Button(0,row*57,534,49,entries[i].Name,Visual.Selected==i))Visual.Select(i);row++;}GUI.EndScrollView();
  Label(42,739,550,34,Visual.Loading?"Loading aircraft…":Visual.AircraftName,eyebrow);
  Label(42,775,550,31,"FlightGear models · Credits include original authors",small);
  if(!Visual.Loading&&Button(42,816,550,46,"Use this aircraft  →",true))Menu=fleetReturn;
 }
 void RefreshChallengeMatches(){EnsureCreations();if(!challengeFilterDirty&&lastChallengeSearch==challengeSearch&&lastCustomChallengeSource==customChallengeSource)return;challengeMatches.Clear();IEnumerable<ChallengeDefinition> entries=customChallengeSource?(IEnumerable<ChallengeDefinition>)savedChallenges:ChallengeCatalog.BuiltIn;foreach(var d in entries)if(ChallengeMatchesSearch(d,challengeSearch))challengeMatches.Add(d);lastChallengeSearch=challengeSearch;lastCustomChallengeSource=customChallengeSource;challengeFilterDirty=false;challengePage=0;challengeScroll=Vector2.zero;}
 bool ChallengeMatchesSearch(ChallengeDefinition d,string search)=>Matches(d.Name,search)||Matches(d.Description,search)||Matches(MissionDirector.NameFor(d.Mode),search)||Matches(ChallengeCatalog.LocationFor(d),search);
 static bool Matches(string value,string search)=>string.IsNullOrWhiteSpace(search)||(!string.IsNullOrEmpty(value)&&value.IndexOf(search.Trim(),StringComparison.OrdinalIgnoreCase)>=0);
 string LocationFor(FlightMode mode)=>ChallengeCatalog.LocationFor(ChallengeCatalog.CreateDefault(mode));
 void ChallengeCard(ChallengeDefinition d,float y){Box(0,y,534,112,new Color(.09f,.15f,.18f,.97f));Label(14,y+7,448,20,"DIFFICULTY "+d.Difficulty+" / 5  ·  "+(completedChallenges.Contains(d.Id)?"COMPLETED":ChallengeCatalog.LocationFor(d)),new GUIStyle(eyebrow){fontSize=11});Label(14,y+29,438,43,d.Name,new GUIStyle(text){fontSize=20,fontStyle=FontStyle.Bold});Label(14,y+77,444,30,d.Description,new GUIStyle(small){fontSize=12});if(Button(469,y+32,51,46,"→"))ShowChallenge(d);}
 void Challenges(){EnsureCreations();Label(42,209,560,63,"Your aircraft. Your call.",new GUIStyle(title){fontSize=38});Label(42,279,550,34,ChallengeCatalog.BuiltIn.Count+" distinct flight challenges, plus your creations.",small);
  if(Button(42,323,267,38,ChallengeCatalog.BuiltIn.Count+" included",!customChallengeSource)){customChallengeSource=false;challengeFilterDirty=true;}
  if(Button(324,323,267,38,"My challenges ("+savedChallenges.Count+")",customChallengeSource)){customChallengeSource=true;challengeFilterDirty=true;}
  GUI.SetNextControlName("ChallengeSearch");challengeSearch=Field(42,376,550,challengeSearch,80);if(string.IsNullOrEmpty(challengeSearch)&&GUI.GetNameOfFocusedControl()!="ChallengeSearch")Label(55,388,514,25,"Search name, scenario or location…",small);
  RefreshChallengeMatches();const int perPage=3;int pageCount=Mathf.Max(1,(challengeMatches.Count+perPage-1)/perPage);challengePage=Mathf.Clamp(challengePage,0,pageCount-1);int first=challengePage*perPage,count=Mathf.Min(perPage,challengeMatches.Count-first);
  challengeScroll=GUI.BeginScrollView(new Rect(42,439,568,354),challengeScroll,new Rect(0,0,539,Mathf.Max(354,count*121)));for(int i=0;i<count;i++)ChallengeCard(challengeMatches[first+i],i*121);if(count==0)Label(14,35,500,90,customChallengeSource&&savedChallenges.Count==0?"No saved challenges yet. Create one in the challenge builder.":"No challenges match that search.",text);GUI.EndScrollView();
  bool enabled=GUI.enabled;GUI.enabled=enabled&&challengePage>0;if(Button(42,811,155,42,"← Previous")){challengePage--;challengeScroll=Vector2.zero;}GUI.enabled=enabled;Label(212,821,220,30,"Page "+(challengePage+1)+" / "+pageCount+" · "+challengeMatches.Count+" found",small);GUI.enabled=enabled&&challengePage<pageCount-1;if(Button(443,811,149,42,"Next →")){challengePage++;challengeScroll=Vector2.zero;}GUI.enabled=enabled;
  if(Button(1050,135,340,48,"Build your own challenge"))EditChallenge(null);Label(42,859,550,19,"Fictional training presets · simplified flight model",new GUIStyle(small){fontSize=12});
 }
 string BriefTitle=>MissionDirector.NameFor(briefing);
 string BriefDescription=>ChallengeCatalog.DescriptionFor(briefing);
 string BriefProcedure=>ChallengeCatalog.ProcedureFor(briefing);
 string BriefSummary=>selectedChallenge==null?LocationFor(briefing):ChallengeCatalog.LocationFor(selectedChallenge)+(briefing==FlightMode.RejectedTakeoff?"  ·  DEPARTURE EXERCISE":"  ·  ENTRY "+selectedChallenge.StartAltitude.ToString("F0")+" m MSL  ·  "+(selectedChallenge.StartSpeed*1.94384f).ToString("F0")+" kt");
 void Briefing(){Label(42,215,550,28,"RUNWAY START  /  FLY THE STATED OBJECTIVE",eyebrow);Label(40,259,565,117,selectedChallenge!=null?selectedChallenge.Name:BriefTitle,new GUIStyle(title){fontSize=selectedChallenge!=null?40:49});Label(42,378,550,32,BriefSummary,small);Label(42,424,550,142,selectedChallenge!=null?selectedChallenge.Description:BriefDescription);
  Label(42,579,550,70,BriefProcedure,eyebrow);
  bool allowsAssist=ChallengeCatalog.AllowsAssist(briefing),enabled=GUI.enabled;GUI.enabled=enabled&&allowsAssist;if(Button(42,659,550,49,!allowsAssist?"Manual recovery · takeoff assist available [H]":LandingAssist?"Landing assist: ON · click to disable":"Landing assist: OFF · click to enable"))LandingAssist=!LandingAssist;GUI.enabled=enabled;
  AircraftPicker(729);bool ratReady=!ChallengeCatalog.RequiresRAT(briefing)||Aircraft.RATAvailable;GUI.enabled=enabled&&!Visual.Loading&&ratReady;if(Button(42,783,350,48,"Take the controls  →",true)){if(selectedChallenge!=null)BeginChallenge(selectedChallenge);else BeginFlight(briefing,0,0,"");}GUI.enabled=enabled;if(Button(408,783,184,48,"Customize"))EditChallenge(selectedChallenge??ChallengeCatalog.CreateDefault(briefing));Label(42,840,550,40,Visual.Loading?"Loading aircraft…":!ratReady?"Choose a RAT-fitted aircraft before starting this challenge.":creatorFeedback.Length>0?creatorFeedback:briefing==FlightMode.Hudson?"A simplified challenge inspired by an aviation event.":"Fictional flight practice; simplified flight model.",small);
 }
 void Pause(){Label(42,230,550,70,"Take a breath.",title);Label(42,326,550,50,"Your flight is paused.");if(Button(42,420,420,56,"Resume flight  →",true))Resume();if(Button(42,490,420,56,"Choose another destination"))GoTo(MenuPage.Explore);if(Button(42,560,420,56,"Restart this flight"))Restart();if(Button(42,630,420,56,"Controls & settings"))GoTo(MenuPage.Controls);if(Button(42,700,420,56,"Create an aircraft or challenge"))GoTo(MenuPage.Create);if(Button(42,770,420,56,"Quit simulator"))Application.Quit();}
 void Restart(){if(Visual.Loading)return;flyDesignWhenReady=false;ReleaseFlightControls();ResultsDismissed=false;Mission.RetryChallenge(LandingAssist);selectedChallenge=Mission.CurrentChallenge!=null?ChallengeCatalog.Normalize(Mission.CurrentChallenge):null;if(selectedChallenge!=null)briefing=selectedChallenge.Mode;Menu=MenuPage.Flight;resume=false;}
 // Commands are also used by editor validation; they execute the same save/launch paths as the buttons.
 public AircraftDesign AircraftDraft=>aircraftDraft;
 public ChallengeDefinition ChallengeDraft=>challengeDraft;
 public ChallengeDefinition SelectedChallenge=>selectedChallenge;
 public void EditAircraftDesign(AircraftDesign design){EnsureCreations();aircraftDraft=design!=null?AircraftDesignStore.Sanitize(design,Visual.Catalog.Aircraft.Length):new AircraftDesign{BaseAircraftIndex=Visual.Selected,Name="My "+Visual.StockAircraftName};creatorFeedback=design!=null?"Editing a saved aircraft. Save updates this creation.":"Customize an included airframe. Preview to see your changes.";deletionId="";GoTo(MenuPage.AircraftDesigner);}
 public void EditChallenge(ChallengeDefinition definition){EnsureCreations();challengeDraft=definition!=null?ChallengeCatalog.Normalize(definition):ChallengeCatalog.CreateDefault(FlightMode.Hudson);if(definition==null||!challengeDraft.Id.StartsWith("custom-",StringComparison.Ordinal)){challengeDraft.Id="";challengeDraft.Name="My "+challengeDraft.Name;}builderScroll=Vector2.zero;creatorFeedback="Choose a scenario template, then adjust its approach-entry conditions.";deletionId="";GoTo(MenuPage.ChallengeBuilder);}
 public bool SaveAircraftCreation(bool fly=false){if(aircraftDraft==null||string.IsNullOrWhiteSpace(aircraftDraft.Name)){creatorFeedback="Give your aircraft a name before saving.";return false;}var saved=AircraftDesignStore.Save(aircraftDraft);if(saved==null){creatorFeedback="You have 20 saved aircraft. Delete one before adding another.";return false;}aircraftDraft=saved;ReloadCreations();Visual.SelectDesign(saved);creatorFeedback=fly?"Saved. Loading your aircraft; the flight starts when it is ready.":"Saved on this device. Your aircraft is selected.";flyDesignWhenReady=fly;if(fly)Menu=MenuPage.AircraftDesigner;return true;}
 public bool SaveChallengeCreation(bool briefingAfterSave=false){if(challengeDraft==null||string.IsNullOrWhiteSpace(challengeDraft.Name)){creatorFeedback="Give your challenge a name before saving.";return false;}try{challengeDraft=ChallengeStore.Save(challengeDraft);ReloadCreations();creatorFeedback="Saved on this device. Find it in My challenges or My creations.";if(briefingAfterSave)ShowChallenge(challengeDraft);return true;}catch(InvalidOperationException){creatorFeedback="You have 100 saved challenges. Delete one before adding another.";return false;}}
 void PreviewAircraftDraft(){flyDesignWhenReady=false;if(aircraftDraft==null)return;Visual.SelectDesign(aircraftDraft);creatorFeedback="Previewing your draft. Save to keep this aircraft on this device.";}
 void CreateMenu(){EnsureCreations();Label(42,209,560,65,"Make it your own.",new GUIStyle(title){fontSize=43});Label(42,282,550,43,"Create an aircraft setup or a new emergency challenge.",small);
  Box(42,346,550,135,new Color(.09f,.15f,.18f,.97f));Label(60,363,504,24,"AIRCRAFT DESIGNER",eyebrow);Label(60,395,425,65,"Customize an included airframe with a name, accent and handling settings.",text);if(Button(505,402,65,49,"→"))EditAircraftDesign(null);
  Box(42,509,550,135,new Color(.09f,.15f,.18f,.97f));Label(60,526,504,24,"CHALLENGE BUILDER",eyebrow);Label(60,558,425,65,"Use "+challengeModes.Length+" distinct templates. Set altitude, airspeed, fuel and weather.",text);if(Button(505,565,65,49,"→"))EditChallenge(null);
  if(Button(42,681,550,58,"My creations  ·  "+savedAircraft.Count+" aircraft / "+savedChallenges.Count+" challenges",true)){savedChallengeTab=false;creationSearch="";creationScroll=Vector2.zero;creatorFeedback="";GoTo(MenuPage.SavedCreations);}
  Label(42,770,550,58,"Creations are saved locally on this device. Aircraft designs use the included realistic models.",small);if(resume&&Button(1050,135,340,48,"Resume current flight  →"))Resume();
 }
 float SliderSetting(float x,float y,float width,string label,float value,float min,float max,float step,string format,string unit){Label(x,y,width*.65f,26,label,small);Label(x+width*.65f,y,width*.35f,26,value.ToString(format)+unit,eyebrow);if(Button(x,y+31,46,30,"−"))value-=step;if(Button(x+width-46,y+31,46,30,"+"))value+=step;var color=GUI.backgroundColor;GUI.backgroundColor=lime;value=GUI.HorizontalSlider(new Rect(x+58,y+31,width-116,26),value,min,max,sliderTrack,sliderThumb);GUI.backgroundColor=color;return Mathf.Clamp(value,min,max);}
 string BaseAircraftName(int index){var entries=Visual.Catalog.Aircraft;return entries.Length>0?entries[Mathf.Clamp(index,0,entries.Length-1)].Name:"Included aircraft";}
 void CycleDraftAircraft(int direction){flyDesignWhenReady=false;aircraftDraft.BaseAircraftIndex=(aircraftDraft.BaseAircraftIndex+direction+Visual.Catalog.Aircraft.Length)%Visual.Catalog.Aircraft.Length;Visual.Select(aircraftDraft.BaseAircraftIndex);creatorFeedback="Base airframe changed. Preview applies the accent and tuning.";}
 void AircraftDesigner(){if(aircraftDraft==null){EditAircraftDesign(null);return;}Label(42,209,550,62,"Aircraft workshop.",new GUIStyle(title){fontSize=41});Label(42,278,550,45,"Customize an included airframe · accent and bounded handling tuning",small);Label(42,334,550,24,"AIRCRAFT NAME",eyebrow);string oldName=aircraftDraft.Name;aircraftDraft.Name=Field(42,363,550,aircraftDraft.Name,40);if(oldName!=aircraftDraft.Name){flyDesignWhenReady=false;creatorFeedback="Name changed. Save to keep this aircraft.";}
  Label(42,431,550,24,"BASE AIRFRAME  ·  "+(aircraftDraft.BaseAircraftIndex+1)+" / "+Visual.Catalog.Aircraft.Length,eyebrow);if(Button(42,461,52,46,"←"))CycleDraftAircraft(-1);Label(110,470,416,33,BaseAircraftName(aircraftDraft.BaseAircraftIndex),text);if(Button(540,461,52,46,"→"))CycleDraftAircraft(1);
  Label(42,529,550,24,"ACCENT PALETTE",eyebrow);var paletteStyle=new GUIStyle(button){fontSize=14,alignment=TextAnchor.MiddleCenter,padding=new RectOffset(3,3,3,3)};paletteStyle.normal.textColor=new Color(.06f,.12f,.15f);for(int i=0;i<designColors.Length;i++){float x=42+i*93;Color delta=aircraftDraft.Tint-designColors[i];bool selected=delta.r*delta.r+delta.g*delta.g+delta.b*delta.b<.005f;if(selected)Box(x-3,561,86,51,lime);var old=GUI.backgroundColor;GUI.backgroundColor=designColors[i];if(GUI.Button(new Rect(x,564,80,45),designColorNames[i],paletteStyle)){flyDesignWhenReady=false;aircraftDraft.Tint=designColors[i];creatorFeedback="Accent changed. Preview to apply it to the selected model.";}GUI.backgroundColor=old;}
  float oldThrust=aircraftDraft.ThrustMultiplier,oldControl=aircraftDraft.ControlSensitivity;aircraftDraft.ThrustMultiplier=SliderSetting(42,633,550,"Engine thrust",aircraftDraft.ThrustMultiplier*100,75,125,1,"F0","%");aircraftDraft.ThrustMultiplier/=100;aircraftDraft.ControlSensitivity=SliderSetting(42,708,550,"Control response",aircraftDraft.ControlSensitivity*100,75,125,1,"F0","%");aircraftDraft.ControlSensitivity/=100;if(Mathf.Abs(oldThrust-aircraftDraft.ThrustMultiplier)>.0001f||Mathf.Abs(oldControl-aircraftDraft.ControlSensitivity)>.0001f){flyDesignWhenReady=false;creatorFeedback="Handling changed. Preview applies these settings to your aircraft.";}
  Label(42,779,550,40,Visual.Loading?"Loading aircraft preview…":creatorFeedback,small);if(Button(42,827,116,44,"Save",true))SaveAircraftCreation();if(Button(170,827,116,44,"Preview"))PreviewAircraftDraft();if(Button(298,827,178,44,"Save & fly →",true))SaveAircraftCreation(true);if(Button(488,827,104,44,"Back"))GoTo(MenuPage.Create);
 }
 void ChangeChallengeTemplate(int delta){int index=Array.IndexOf(challengeModes,challengeDraft.Mode);index=(index+delta+challengeModes.Length)%challengeModes.Length;string id=challengeDraft.Id,name=challengeDraft.Name;challengeDraft=ChallengeCatalog.CreateDefault(challengeModes[index]);challengeDraft.Id=id;challengeDraft.Name=name;builderScroll=Vector2.zero;creatorFeedback="Scenario changed; settings reset to this template's defaults.";}
 bool HasTimedFailure(FlightMode mode)=>ChallengeCatalog.HasTimedFailure(mode);
 void ChallengeBuilder(){if(challengeDraft==null){EditChallenge(null);return;}Label(42,209,550,62,"Challenge builder.",new GUIStyle(title){fontSize=40});Label(42,278,550,43,ChallengeCatalog.LocationFor(challengeDraft),small);if(Button(42,329,52,44,"←"))ChangeChallengeTemplate(-1);Label(110,335,420,38,MissionDirector.NameFor(challengeDraft.Mode),new GUIStyle(text){fontSize=22,fontStyle=FontStyle.Bold});if(Button(540,329,52,44,"→"))ChangeChallengeTemplate(1);
  bool rejectedTakeoff=challengeDraft.Mode==FlightMode.RejectedTakeoff;builderScroll=GUI.BeginScrollView(new Rect(42,393,568,377),builderScroll,new Rect(0,0,539,rejectedTakeoff?450:HasTimedFailure(challengeDraft.Mode)?1250:1202));float y=0;Label(0,y,534,24,"CHALLENGE NAME",eyebrow);challengeDraft.Name=Field(0,y+30,534,challengeDraft.Name,64);y+=99;Label(0,y,534,24,"DESCRIPTION",eyebrow);challengeDraft.Description=Field(0,y+30,534,challengeDraft.Description,240);y+=100;
  Label(0,y,534,24,"DIFFICULTY",eyebrow);for(int i=1;i<=5;i++)if(Button((i-1)*108,y+31,102,38,i+" / 5",challengeDraft.Difficulty==i))challengeDraft.Difficulty=i;y+=91;
  if(rejectedTakeoff){Label(0,y+8,534,100,"This departure exercise has a fixed fault at 35 m/s. Hold the brakes, close the thrust and stop on the runway. Approach-entry settings do not apply.",small);}else{
  var targetRunway=RunwayCatalog.FindByIdent(challengeDraft.RunwayId);float altitudeMin=targetRunway!=null?Mathf.Max(100,targetRunway.Elevation+100):100,altitudeMax=string.IsNullOrEmpty(challengeDraft.RunwayId)?1800:6000;
  challengeDraft.StartAltitude=SliderSetting(0,y,534,"Approach entry altitude (MSL)",challengeDraft.StartAltitude,altitudeMin,altitudeMax,25,"F0"," m");y+=75;
  challengeDraft.StartSpeed=SliderSetting(0,y,534,"Approach entry airspeed",challengeDraft.StartSpeed*1.94384f,60*1.94384f,125*1.94384f,1,"F0"," kt")/1.94384f;y+=75;
  challengeDraft.Throttle=SliderSetting(0,y,534,"Approach entry thrust",challengeDraft.Throttle*100,0,100,1,"F0","%")/100;y+=75;
  challengeDraft.Fuel=SliderSetting(0,y,534,"Fuel reserve",challengeDraft.Fuel*100,0,100,.1f,"F1","%")/100;y+=75;
  challengeDraft.Wind=SliderSetting(0,y,534,"Wind (+ east / − west)",challengeDraft.Wind,-20,20,.5f,"F1"," m/s");y+=75;
  challengeDraft.GustStrength=SliderSetting(0,y,534,"Gust strength",challengeDraft.GustStrength,0,15,.5f,"F1"," m/s");y+=75;
  if(HasTimedFailure(challengeDraft.Mode)){challengeDraft.FailureDelay=SliderSetting(0,y,534,"Fault delay after approach entry",challengeDraft.FailureDelay,0,60,1,"F0"," s");y+=75;}else{Label(0,y,534,62,ChallengeCatalog.ProcedureFor(challengeDraft.Mode),small);y+=70;}
  Label(0,y,265,24,"ENTRY FLAPS",eyebrow);Label(284,y,250,24,"ENTRY GEAR",eyebrow);for(int i=0;i<3;i++)if(Button(i*90,y+31,84,39,i.ToString(),challengeDraft.InitialFlaps==i))challengeDraft.InitialFlaps=i;if(Button(284,y+31,250,39,challengeDraft.InitialGear?"Gear down":"Gear up"))challengeDraft.InitialGear=!challengeDraft.InitialGear;y+=92;
  Label(0,y,534,28,"ADVANCED APPROACH SETTINGS",eyebrow);y+=41;
  challengeDraft.ApproachOffset=SliderSetting(0,y,534,"Distance behind template start",challengeDraft.ApproachOffset,-500,2500,50,"F0"," m");y+=75;
  challengeDraft.LateralOffset=SliderSetting(0,y,534,"Lateral offset",challengeDraft.LateralOffset,-350,350,10,"F0"," m");y+=75;
  challengeDraft.HeadingOffset=SliderSetting(0,y,534,"Heading offset",challengeDraft.HeadingOffset,-12,12,.5f,"F1","°");y+=75;
  }
  GUI.EndScrollView();
  Label(42,783,550,34,creatorFeedback,small);if(Button(42,827,145,44,"Save",true))SaveChallengeCreation();if(Button(199,827,244,44,"Save & test →",true))SaveChallengeCreation(true);if(Button(455,827,137,44,"Back"))GoTo(MenuPage.Create);
 }
 void UseAircraftCreation(AircraftDesign design,bool fly){Visual.SelectDesign(design);creatorFeedback=fly?"Loading your saved aircraft. The flight starts when it is ready.":"Aircraft selected. Choose a destination to fly it.";flyDesignWhenReady=fly;if(!fly)GoTo(MenuPage.Explore);}
 public bool DeleteAircraftCreation(string id){flyDesignWhenReady=false;bool deleted=AircraftDesignStore.Delete(id);ReloadCreations();deletionId="";creatorFeedback=deleted?"Aircraft creation deleted from this device.":"That aircraft is no longer saved.";return deleted;}
 public bool DeleteChallengeCreation(string id){flyDesignWhenReady=false;bool deleted=ChallengeStore.Delete(id);ReloadCreations();deletionId="";creatorFeedback=deleted?"Challenge deleted from this device.":"That challenge is no longer saved.";return deleted;}
 void DeleteCreationButton(float x,float y,float width,string id,bool aircraft){bool confirm=deletionId==id;if(Button(x,y,width,36,confirm?"Confirm":"Delete")){flyDesignWhenReady=false;if(confirm){if(aircraft)DeleteAircraftCreation(id);else DeleteChallengeCreation(id);}else{deletionId=id;creatorFeedback="Tap Confirm again to remove this saved creation.";}}}
 void SavedCreations(){EnsureCreations();Label(42,209,550,64,"Your creations.",new GUIStyle(title){fontSize=43});Label(42,281,550,38,"Saved on this device · select, edit, test or delete",small);if(Button(42,329,267,41,"Aircraft ("+savedAircraft.Count+")",!savedChallengeTab)){flyDesignWhenReady=false;savedChallengeTab=false;deletionId="";creationScroll=Vector2.zero;}if(Button(324,329,267,41,"Challenges ("+savedChallenges.Count+")",savedChallengeTab)){flyDesignWhenReady=false;savedChallengeTab=true;deletionId="";creationScroll=Vector2.zero;}
  GUI.SetNextControlName("CreationSearch");string priorSearch=creationSearch;creationSearch=Field(42,386,550,creationSearch,80);if(priorSearch!=creationSearch){flyDesignWhenReady=false;creationScroll=Vector2.zero;}if(string.IsNullOrEmpty(creationSearch)&&GUI.GetNameOfFocusedControl()!="CreationSearch")Label(55,398,514,25,"Search your saved creations…",small);
  int count=0;if(savedChallengeTab){foreach(var d in savedChallenges)if(ChallengeMatchesSearch(d,creationSearch))count++;}else foreach(var d in savedAircraft)if(Matches(d.Name,creationSearch)||Matches(BaseAircraftName(d.BaseAircraftIndex),creationSearch))count++;
  creationScroll=GUI.BeginScrollView(new Rect(42,452,568,306),creationScroll,new Rect(0,0,539,Mathf.Max(306,count*147)));int row=0;
  if(savedChallengeTab){foreach(var d in savedChallenges){if(!ChallengeMatchesSearch(d,creationSearch))continue;float y=row++*147;Box(0,y,534,136,new Color(.09f,.15f,.18f,.97f));Label(14,y+8,506,42,d.Name,new GUIStyle(text){fontSize=21,fontStyle=FontStyle.Bold});Label(14,y+56,506,25,ChallengeCatalog.LocationFor(d)+" · Difficulty "+d.Difficulty+" / 5",small);if(Button(14,y+91,155,36,"Briefing →"))ShowChallenge(d);if(Button(185,y+91,155,36,"Edit"))EditChallenge(d);DeleteCreationButton(356,y+91,164,d.Id,false);}}
  else{foreach(var d in savedAircraft){if(!Matches(d.Name,creationSearch)&&!Matches(BaseAircraftName(d.BaseAircraftIndex),creationSearch))continue;float y=row++*147;Box(0,y,534,136,new Color(.09f,.15f,.18f,.97f));Label(14,y+8,506,42,d.Name,new GUIStyle(text){fontSize=21,fontStyle=FontStyle.Bold});Label(14,y+56,506,25,BaseAircraftName(d.BaseAircraftIndex)+" · Thrust "+(d.ThrustMultiplier*100).ToString("F0")+"% · Controls "+(d.ControlSensitivity*100).ToString("F0")+"%",small);if(Button(14,y+91,119,36,"Use"))UseAircraftCreation(d,false);if(Button(143,y+91,119,36,"Fly →",true))UseAircraftCreation(d,true);if(Button(272,y+91,119,36,"Edit"))EditAircraftDesign(d);DeleteCreationButton(401,y+91,119,d.Id,true);}}
  if(count==0)Label(14,35,500,100,string.IsNullOrWhiteSpace(creationSearch)?"No saved "+(savedChallengeTab?"challenges":"aircraft")+" yet. Make your first creation in Create.":"No saved creations match that search.",text);GUI.EndScrollView();
  Label(42,778,550,39,creatorFeedback,small);if(Button(42,827,267,44,"Create something new →",true)){deletionId="";GoTo(MenuPage.Create);}if(Button(324,827,267,44,"Reload saved creations")){ReloadCreations();creatorFeedback="Saved creations reloaded from this device.";}
 }
 void Controls(){Label(42,215,555,70,"You have control.",new GUIStyle(title){fontSize=43});string[] keys={"W / S or ↓ / ↑","A / D or ← / →","Shift / Ctrl","Q / C","G / F","E / R","V / H","P or Esc / M","Space / hold BRAKE","T","X"};string[] actions={"Pitch nose up / down","Bank left / right","Increase / decrease throttle","Rudder left / right","Landing gear / cycle flaps","Fail / restart engines when permitted","Cycle view / landing assist","Pause / choose a destination","Wheel brakes on the ground","Deploy RAT / retract after landing","Exit slides after landing"};var controlText=new GUIStyle(text){fontSize=18};for(int i=0;i<keys.Length;i++){Label(42,308+i*33,220,32,keys[i],eyebrow);Label(274,308+i*33,325,32,actions[i],controlText);}
  Label(42,687,550,24,"Hold BRAKE  •  Tap RELIGHT when available  •  Drag sky to look",small);
  if(Button(42,711,550,44,sound?"Engine & wind sound: ON":"Engine & wind sound: OFF")){sound=!sound;var audio=Aircraft.GetComponent<FlightAudio>();if(audio)audio.Muted=!sound;}
  if(Button(42,762,267,40,MouseJoystick?"Joystick: ON":"Joystick: OFF")){MouseJoystick=!MouseJoystick;ReleaseStick();}
  if(Button(324,762,267,40,MobileControls?"Mobile mode: ON":"Mobile mode: OFF")){MobileControls=!MobileControls;MouseJoystick=MobileControls;ReleaseFlightControls();}
  Label(42,805,550,22,FlightInput.ControllerName,small);
  if(Button(328,835,264,40,"Model & scenery credits"))Menu=MenuPage.Credits;
  if(Button(42,835,272,40,resume?"Resume flight  →":"Back to discover  →",true)){if(resume)Resume();else Menu=MenuPage.Discover;}
 }
 void Credits(){Label(42,215,555,70,"Made for the sky.",new GUIStyle(title){fontSize=43});
  if(credits==null){var asset=Resources.Load<TextAsset>("Credits");credits=asset?asset.text:"Credits are included with the Unity project.";}
  creditScroll=GUI.BeginScrollView(new Rect(42,305,552,435),creditScroll,new Rect(0,0,523,small.CalcHeight(new GUIContent(credits),520)));GUI.Label(new Rect(0,0,520,small.CalcHeight(new GUIContent(credits),520)),credits,small);GUI.EndScrollView();
  if(Button(42,773,550,52,"Back to controls",true))Menu=MenuPage.Controls;
 }
 void DrawFlight(){Box(25,25,380,82,new Color(.035f,.085f,.11f,.87f));Label(44,39,350,24,"S K Y B O U N D",eyebrow);Label(44,67,350,32,Mission.Place);if(Button(1220,25,195,48,"Pause  [P]"))OpenMenu(MenuPage.Pause);
  var geo=Aircraft.Coordinates;Label(30,121,465,30,Math.Abs(geo.x).ToString("F3")+"° "+(geo.x>=0?"N":"S")+"   "+Math.Abs(geo.y).ToString("F3")+"° "+(geo.y>=0?"E":"W"),small);
  Label(30,157,560,28,"Drag outside the joystick to look  •  B centres view",small);
  if(Button(30,194,210,36,MouseJoystick?"Hide joystick":"Show joystick")){MouseJoystick=!MouseJoystick;ReleaseStick();}
  var slides=EmergencySlides.For(Visual);if(slides.CanDeploy&&!slides.Deployed&&Button(30,242,250,40,"Deploy exit slides [X]"))DeploySlides();
  if(Aircraft.McasInstalled&&!slides.CanDeploy&&!slides.Deployed){Box(30,242,250,79,new Color(.035f,.085f,.11f,.92f));Label(42,249,230,26,"MCAS (SIM): "+Aircraft.Mcas.Status,small);if(Button(42,280,226,33,Aircraft.Mcas.CutOut?"Enable MCAS [K]":"MCAS cutout [K]"))Aircraft.ToggleMcas();}
  if(slides.Deployed){Label(30,289,250,30,"EXIT SLIDES DEPLOYED",eyebrow);if(Mission.Finished&&ResultsDismissed&&Button(30,332,250,36,"Show landing result"))ResultsDismissed=false;}
  if(Mission.Mode!=FlightMode.FreeFlight||Mission.WaitingForTakeoff){Box(380,30,675,74,new Color(.035f,.085f,.11f,.9f));Label(400,41,635,23,Mission.MissionName,eyebrow);Label(400,66,635,37,Mission.Coaching,small);}
  if(!string.IsNullOrEmpty(Mission.GoalProgress)){Box(520,110,535,35,new Color(.035f,.085f,.11f,.9f));Label(532,117,510,25,Mission.GoalProgress,small);}
  if(!Aircraft.Active&&!Mission.Finished&&!slides.Deployed){Box(440,380,560,100,new Color(.035f,.085f,.11f,.9f));Label(465,396,510,38,"Loading your destination…",metric);Label(465,439,510,30,"Real satellite imagery and terrain are streaming.",small);}
  if(Aircraft.Stalled){Label(620,153,250,42,"STALL · LOWER NOSE",new GUIStyle(text){fontSize=21,fontStyle=FontStyle.Bold,normal={textColor=new Color(1,.43f,.25f)}});}
  if(CameraRig.Cockpit)DrawInstruments();
  Box(250,762,940,105,new Color(.035f,.085f,.11f,.92f));float[] vals={Aircraft.Speed*1.94384f,Aircraft.Altitude*3.28084f,Aircraft.Heading,Aircraft.VerticalSpeed*196.85f,Aircraft.Throttle*100};string[] units={"AIRSPEED / KT","ALTITUDE / FT","HEADING / DEG","VERTICAL / FT/M","THROTTLE / %"};for(int i=0;i<5;i++){float x=276+i*180;Label(x,777,175,25,units[i],small);Label(x,811,175,50,vals[i].ToString("F0"),metric);}
  Label(29,728,1120,24,EngineStatus+"    "+(Aircraft.GearJammedUp?"GEAR JAMMED UP":Aircraft.GearJammedDown?"GEAR LOCKED DOWN":Aircraft.Gear?"GEAR DOWN":"GEAR UP")+"    FLAPS "+(Aircraft.FlapsJammed?"JAMMED "+Aircraft.FlapPosition.ToString("F1"):Aircraft.Flaps.ToString())+"    FUEL "+(Aircraft.FuelRemaining*100).ToString("F1")+"%    "+(Aircraft.Assist?"ASSIST ON":"MANUAL"),eyebrow);
  if(Button(1195,713,220,42,"View: "+CameraRig.ViewName+" [V]"))CameraRig.ToggleView();if(Button(1195,768,220,42,"World map [M]"))OpenMenu(MenuPage.Explore);
  Label(28,842,215,23,"W/S pitch  •  A/D bank",small);
  if(Time.unscaledTime<Mission.NoticeUntil){Box(415,656,610,71,new Color(.035f,.085f,.11f,.92f));Label(431,670,578,55,Mission.Message,small);}
  if(MouseJoystick&&!Mission.Finished)DrawJoystick();
  if(!Mission.Finished)DrawSideControls();
  if(!Mission.Finished&&!slides.Deployed)DrawAuxiliaryControls();
  DrawRATControls();

  if(Mission.Finished&&!ResultsDismissed){ReleaseFlightControls();Box(0,0,1440,900,new Color(.01f,.03f,.05f,.6f));Box(360,230,720,460,new Color(.035f,.085f,.11f,1));Label(396,267,650,26,Mission.Success?"YOU MADE IT":"TRY THE EXERCISE AGAIN",eyebrow);Label(394,314,650,68,Mission.Success?Mission.LandingRecorded?"A safe landing.":"Challenge complete.":"Every flight teaches.",new GUIStyle(title){fontSize=43});Label(396,400,650,82,Mission.Result);Label(396,494,650,48,Mission.ResultDetails,small);if(Button(396,555,300,56,"Fly again →",true))Restart();if(Button(724,555,315,56,"Choose a challenge")){GoTo(MenuPage.Challenges);resume=false;}if(slides.CanDeploy&&!slides.Deployed&&Button(396,626,643,48,"Deploy exit slides and view aircraft [X]"))DeploySlides();}
 }
 void DeploySlides(){var slides=EmergencySlides.For(Visual);if(!slides.CanDeploy||slides.Deployed)return;slides.Deploy();CameraRig.Cockpit=CameraRig.Cabin=CameraRig.Discover=false;ResultsDismissed=Mission.Finished;ReleaseFlightControls();}
 public void ChooseMobileControls(bool enabled){MobileControls=MouseJoystick=enabled;ReleaseFlightControls();Menu=MenuPage.Discover;}
 void MobilePrompt(){Label(42,226,550,150,"Ready to fly\non your phone?",title);Label(42,384,550,120,"Use mobile joystick and controls? Drag the joystick to steer and swipe elsewhere to look around. Landscape gives you the best view.");if(Button(42,571,550,70,"Yes · use mobile controls",true)){ChooseMobileControls(true);}if(Button(42,669,550,64,"Use standard controls")){ChooseMobileControls(false);}Label(42,766,550,56,"You can change this later in Controls & settings.",small);}
 public Rect StickArea=>MobileControls?new Rect(32,429,230,230):new Rect(32,479,180,180);
 public Rect ThrustArea=>new Rect(1208,283,84,231);
 public Rect FlapArea(int setting)=>new Rect(1208+setting*65,574,60,42);
 public Rect BrakeArea=>new Rect(30,377,250,40);
 public Rect RelightArea=>new Rect(30,331,250,38);
 public Rect SideControlsArea=>new Rect(1195,205,220,659);
 public Vector2 GuiPoint(Vector2 pixel){Rect safe=MobileControls?Screen.safeArea:new Rect(0,0,Screen.width,Screen.height);float scale=Mathf.Min(safe.width/1440f,safe.height/900f);return new Vector2((pixel.x-safe.x-(safe.width-1440*scale)/2)/scale,(Screen.height-pixel.y-(Screen.height-safe.yMax)-(safe.height-900*scale)/2)/scale);}
 public bool PointerOverControl(Vector2 pixel){Vector2 p=GuiPoint(pixel);return Menu!=MenuPage.Flight||(Mission.Finished&&!ResultsDismissed)||(MouseJoystick&&!Mission.Finished&&StickArea.Contains(p))||new Rect(30,194,210,36).Contains(p)||new Rect(30,242,250,126).Contains(p)||BrakeArea.Contains(p)||RelightArea.Contains(p)||new Rect(1220,25,195,48).Contains(p)||SideControlsArea.Contains(p);}
 void UpdateTouchStick(){if(!MobileControls||!MouseJoystick||Menu!=MenuPage.Flight||Mission.Finished){if(touchStick>=0)ReleaseStick();return;}if(touchStick<0){for(int i=0;i<FlightInput.TouchCount;i++)if(FlightInput.Touch(i,out var pos,out var delta,out bool began)&&began&&StickArea.Contains(GuiPoint(pos))){touchStick=i;break;}}if(touchStick>=0){if(FlightInput.Touch(touchStick,out var pos,out var delta,out bool began)){stickPosition=Vector2.ClampMagnitude((GuiPoint(pos)-StickArea.center)/90,1);Aircraft.TouchRoll=stickPosition.x;Aircraft.TouchPitch=stickPosition.y;}else ReleaseStick();}}
 void SetThrust(float guiY){if(!Aircraft.ThrottleJammed)Aircraft.Throttle=Mathf.Clamp01(Mathf.InverseLerp(497,297,guiY));}
 void UpdateMouseThrust(){
  bool held=FlightInput.LeftMouseHeld,pressed=held&&!thrustMouseWasDown;thrustMouseWasDown=held;
  if(Menu!=MenuPage.Flight||Mission.Finished||Aircraft.ThrottleJammed){ReleaseThrust();return;}
  if(touchThrust>=0){mouseThrustCaptured=false;return;}
  Vector2 p=GuiPoint(FlightInput.PointerPosition);
  // Capture only a new press on the lever. A camera drag crossing the panel
  // cannot take over the throttle, and leaving the rail still clamps its value.
  if(pressed&&ThrustArea.Contains(p))mouseThrustCaptured=true;
  if(mouseThrustCaptured){if(held)SetThrust(p.y);else ReleaseThrust();}
 }
 void UpdateTouchThrust(){
  if(Menu!=MenuPage.Flight||Mission.Finished){ReleaseThrust();return;}
  if(Aircraft.ThrottleJammed&&touchThrust>=0)ReleaseThrust();
  for(int i=0;i<FlightInput.TouchCount;i++)if(FlightInput.Touch(i,out var pos,out var delta,out bool began)&&began){Vector2 p=GuiPoint(pos);if(!Aircraft.ThrottleJammed&&touchThrust<0&&ThrustArea.Contains(p))touchThrust=i;for(int flap=0;flap<3;flap++)if(!Aircraft.FlapsJammed&&FlapArea(flap).Contains(p))Aircraft.Flaps=flap;}
  if(touchThrust>=0){if(FlightInput.Touch(touchThrust,out var pos,out var delta,out bool began))SetThrust(GuiPoint(pos).y);else ReleaseThrust();}
 }
 bool AuxiliaryControlsActive=>Menu==MenuPage.Flight&&!Mission.Finished&&Aircraft.Active&&Time.timeScale>0&&!EmergencySlides.For(Visual).Deployed;
 public bool RequestEngineRelight(){if(!AuxiliaryControlsActive||!Aircraft.CanRestartEngines)return false;return Aircraft.TryRestartEngines();}
 void UpdateAuxiliaryControls(){
  bool held=FlightInput.LeftMouseHeld,pressed=held&&!auxiliaryMouseWasDown;auxiliaryMouseWasDown=held;
  if(!AuxiliaryControlsActive){ReleaseBrake();return;}
  for(int i=0;i<FlightInput.TouchCount;i++)if(FlightInput.Touch(i,out var pos,out var delta,out bool began)&&began){var p=GuiPoint(pos);if(touchBrake<0&&BrakeArea.Contains(p))touchBrake=i;if(RelightArea.Contains(p))RequestEngineRelight();}
  bool touchHeld=false;if(touchBrake>=0){touchHeld=FlightInput.Touch(touchBrake,out var pos,out var delta,out bool began);if(!touchHeld)touchBrake=-1;}
  var point=GuiPoint(FlightInput.PointerPosition);if(pressed&&BrakeArea.Contains(point))mouseBrakeCaptured=true;
  if(pressed&&RelightArea.Contains(point))RequestEngineRelight();
  if(!held)mouseBrakeCaptured=false;Aircraft.BrakeHeld=touchHeld||mouseBrakeCaptured&&held;
 }
 void ReleaseBrake(){touchBrake=-1;mouseBrakeCaptured=false;Aircraft.BrakeHeld=false;if(GUIUtility.hotControl==brakeControl)GUIUtility.hotControl=0;}
 void DrawAuxiliaryControls(){
  bool enabled=GUI.enabled;GUI.enabled=enabled&&AuxiliaryControlsActive&&Aircraft.CanRestartEngines;
  if(Button(RelightArea.x,RelightArea.y,RelightArea.width,RelightArea.height,"Relight engines [R]"))RequestEngineRelight();GUI.enabled=enabled;
  var e=Event.current;brakeControl=GUIUtility.GetControlID("WheelBrake".GetHashCode(),FocusType.Passive,BrakeArea);
  if(AuxiliaryControlsActive&&touchBrake<0&&e.type==EventType.MouseDown&&e.button==0&&BrakeArea.Contains(e.mousePosition)){mouseBrakeCaptured=true;Aircraft.BrakeHeld=true;GUIUtility.hotControl=brakeControl;e.Use();}
  if(mouseBrakeCaptured&&GUIUtility.hotControl==brakeControl&&e.rawType==EventType.MouseUp&&e.button==0){ReleaseBrake();e.Use();}
  Box(BrakeArea.x,BrakeArea.y,BrakeArea.width,BrakeArea.height,Aircraft.BrakeHeld||Aircraft.AutoBrake?lime:new Color(.17f,.24f,.27f));
  Label(BrakeArea.x+15,BrakeArea.y+8,BrakeArea.width-25,28,Aircraft.AutoBrake?"AUTO BRAKE · [SPACE]":Aircraft.BrakeHeld?"BRAKE HELD · RELEASE TO TAXI":"HOLD BRAKE  [SPACE]",new GUIStyle(eyebrow){normal={textColor=Aircraft.BrakeHeld||Aircraft.AutoBrake?new Color(.05f,.11f,.12f):ink}});
 }
 void ReleaseStick(){touchStick=-1;stickDragging=false;stickPosition=Vector2.zero;Aircraft.TouchPitch=Aircraft.TouchRoll=0;if(GUIUtility.hotControl==stickControl)GUIUtility.hotControl=0;}
 void ReleaseThrust(){touchThrust=-1;thrustDragging=mouseThrustCaptured=false;if(GUIUtility.hotControl==thrustControl)GUIUtility.hotControl=0;}
 void ReleaseFlightControls(){ReleaseStick();ReleaseThrust();ReleaseBrake();thrustMouseWasDown=auxiliaryMouseWasDown=FlightInput.LeftMouseHeld;}
 void OnApplicationFocus(bool focus){if(!focus)ReleaseFlightControls();}
 void OnDisable(){if(Aircraft)ReleaseFlightControls();}
 void DrawSideControls(){
  Box(1195,205,220,497,new Color(.035f,.085f,.11f,.92f));Label(1208,219,198,24,"ENGINE THRUST",eyebrow);
  Label(1208,248,198,26,Aircraft.Engines&&(Aircraft.LeftEngine||Aircraft.RightEngine)?(Aircraft.LeftEngine&&Aircraft.RightEngine?"ENGINE POWER  ":"ONE ENGINE · POWER ")+(Aircraft.EnginePower*100).ToString("F0")+"%":"ENGINES LOST · NO THRUST",small);
  var e=Event.current;thrustControl=GUIUtility.GetControlID("EngineThrust".GetHashCode(),FocusType.Passive,ThrustArea);
  if(!Aircraft.ThrottleJammed&&touchThrust<0&&e.type==EventType.MouseDown&&e.button==0&&ThrustArea.Contains(e.mousePosition)){GUIUtility.hotControl=thrustControl;thrustDragging=true;SetThrust(e.mousePosition.y);e.Use();}
  if(thrustDragging&&GUIUtility.hotControl==thrustControl&&e.rawType==EventType.MouseDrag){SetThrust(e.mousePosition.y);e.Use();}
  if(thrustDragging&&e.rawType==EventType.MouseUp&&e.button==0){ReleaseThrust();e.Use();}
  Box(1241,297,14,200,new Color(.16f,.24f,.27f));float y=Mathf.Lerp(497,297,Aircraft.Throttle);Box(1241,y,14,497-y,lime*.8f);
  for(int tick=0;tick<5;tick++)Box(1233,297+tick*50,30,1,muted*.75f);
  Box(1224,y-8,48,16,lime);Label(1280,287,120,26,"MAX",small);Label(1279,345,125,52,(Aircraft.Throttle*100).ToString("F0")+"%",metric);Label(1280,392,123,30,Aircraft.ThrottleJammed?"LOCKED":"Commanded",small);Label(1280,432,122,53,Aircraft.ThrottleJammed?"Thrust lever\njammed":"Drag to set\nthrust",small);Label(1280,486,123,26,"IDLE",small);
  Label(1208,541,198,24,"FLAPS",eyebrow);
  bool oldEnabled=GUI.enabled;GUI.enabled=oldEnabled&&!Aircraft.FlapsJammed;for(int setting=0;setting<3;setting++){Rect area=FlapArea(setting);if(Button(area.x,area.y,area.width,area.height,setting==0?"0":setting.ToString(),Aircraft.Flaps==setting))Aircraft.Flaps=setting;}GUI.enabled=oldEnabled;
  bool moving=Mathf.Abs(Aircraft.FlapPosition-Aircraft.Flaps)>.025f;Label(1208,623,198,25,Aircraft.FlapsJammed?"JAMMED AT "+Aircraft.FlapPosition.ToString("F1")+" / 2":moving?"Moving to "+Aircraft.Flaps+" · "+(Aircraft.FlapPosition/2*100).ToString("F0")+"%":Aircraft.Flaps==0?"Retracted":Aircraft.Flaps==1?"Half deployed":"Fully deployed",small);
  int oldSize=button.fontSize;bool gearLocked=Aircraft.GearJammedUp||Aircraft.GearJammedDown;GUI.enabled=oldEnabled&&!gearLocked;if(gearLocked)button.fontSize=13;
  if(Button(1208,656,94,34,Aircraft.GearJammedUp?"Locked ↑":Aircraft.GearJammedDown?"Locked ↓":Aircraft.Gear?"Gear ↓":"Gear ↑"))Aircraft.Gear=!Aircraft.Gear;GUI.enabled=oldEnabled;button.fontSize=oldSize;
  GUI.enabled=oldEnabled&&Aircraft.CatalogAllowsAssist;if(Button(1310,656,92,34,Aircraft.CatalogAllowsAssist?"Assist":"Manual",Aircraft.Assist))Aircraft.Assist=!Aircraft.Assist;GUI.enabled=oldEnabled;
 }
 void DrawRATControls(){bool oldEnabled=GUI.enabled;GUI.enabled=oldEnabled&&Aircraft.Active&&Time.timeScale>0&&Aircraft.RATAvailable&&(!Aircraft.RATDeployed||Aircraft.Grounded);if(Button(1195,823,220,38,Aircraft.RATAvailable?Aircraft.RATDeployed?Aircraft.Grounded?"Retract RAT [T]":"RAT extended":"Deploy RAT [T]":"No RAT fitted"))Aircraft.ToggleRAT();GUI.enabled=oldEnabled;Label(1195,867,220,23,RATStatus,small);}
 string EngineStatus=>!Aircraft.Engines||(!Aircraft.LeftEngine&&!Aircraft.RightEngine)?"ENGINES LOST":Aircraft.LeftEngine&&Aircraft.RightEngine?"ENGINES ON":"ONE ENGINE";
 string RATStatus=>!Aircraft.RATAvailable?"RAT NOT FITTED":Aircraft.RATDeployed&&Aircraft.RATPosition<.98f?"RAT DEPLOYING · "+(Aircraft.RATPosition*100).ToString("F0")+"%":Aircraft.EmergencyPower>.001f?"RAT · EMERGENCY POWER "+(Aircraft.EmergencyPower*100).ToString("F0")+"%":Aircraft.RATPosition>.98f?"RAT DEPLOYED · 0% POWER":Aircraft.RATPosition>.01f?"RAT RETRACTING":"RAT RETRACTED";
 void DrawJoystick(){
  var area=StickArea;var center=area.center;var e=Event.current;stickControl=GUIUtility.GetControlID("FlightStick".GetHashCode(),FocusType.Passive,area);
  if(touchStick<0&&e.type==EventType.MouseDown&&e.button==0&&area.Contains(e.mousePosition)){GUIUtility.hotControl=stickControl;stickDragging=true;e.Use();}
  if(stickDragging&&GUIUtility.hotControl==stickControl&&(e.rawType==EventType.MouseDrag||e.rawType==EventType.MouseDown)){stickPosition=Vector2.ClampMagnitude((e.mousePosition-center)/70,1);Aircraft.TouchRoll=stickPosition.x;Aircraft.TouchPitch=stickPosition.y;e.Use();}
  if(stickDragging&&e.rawType==EventType.MouseUp&&e.button==0){ReleaseStick();e.Use();}
  Box(area.x,area.y,area.width,area.height,new Color(.035f,.085f,.11f,.8f));Box(center.x-1,area.y+15,2,150,muted*.6f);Box(area.x+15,center.y-1,150,2,muted*.6f);
  Vector2 knob=center+stickPosition*70;Box(knob.x-14,knob.y-14,28,28,lime);Label(32,667,230,22,"JOYSTICK · PULL BACK TO CLIMB",new GUIStyle(eyebrow){fontSize=10});
 }
 void DrawInstruments(){float cx=720,cy=450;var old=GUI.matrix;GUIUtility.RotateAroundPivot(-Aircraft.Roll,new Vector2(cx,cy));float horizon=cy+Aircraft.Pitch*6;Box(cx-135,horizon-1,270,2,lime);for(int i=-3;i<=3;i++){if(i==0)continue;float y=horizon+i*60;Box(cx-55,y,110,1,new Color(.8f,.96f,.7f,.8f));Label(cx+65,y-13,52,26,(-i*10).ToString(),small);}GUI.matrix=old;Box(cx-65,cy,45,3,lime);Box(cx+20,cy,45,3,lime);Box(cx-3,cy-3,6,6,lime);}
 void DrawCredits(){Label(20,877,1400,23,"Imagery © Esri, Maxar, Earthstar Geographics, GIS User Community  •  Elevation: Mapzen / AWS Open Data  •  Internet required for scenery",new GUIStyle(small){fontSize=11});}
}
}
