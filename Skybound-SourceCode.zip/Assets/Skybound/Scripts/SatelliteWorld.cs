using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
namespace Skybound {
public class SatelliteWorld:MonoBehaviour {
 [Header("Real world imagery and terrain")]
 public string ImageryEndpoint="https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}";
 public string ElevationEndpoint="https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png";
 public int DetailZoom=14,DetailRadius=3;public bool ElevationEnabled=true;
 public FlightController Aircraft;
 public double Latitude=40.773,Longitude=-73.998;
 public Vector2d Origin;public double Scale=1;
 public int LoadedTiles,FailedTiles,ElevationTiles;
 public string Status=>LoadedTiles==0?(FailedTiles>0?"Imagery unavailable · check connection":"Loading satellite imagery…"):$"SATELLITE LIVE · {LoadedTiles} tiles · terrain {(ElevationTiles>0?"online":"loading")}";
 class Tile{public GameObject go;public Texture2D texture;public Mesh mesh;public bool done,disposed;public double west,north,size;public bool detail;}
 class Dem{public Texture2D tex;public bool done;public float lastUsed;}
 Dictionary<string,Tile> tiles=new Dictionary<string,Tile>();Dictionary<string,Dem> dems=new Dictionary<string,Dem>();
 Queue<Tile> terrainQueue=new Queue<Tile>();HashSet<Tile> terrainPending=new HashSet<Tile>();
 Queue<Tile> readyTiles=new Queue<Tile>();
 Queue<Action> queue=new Queue<Action>();HashSet<string> wanted=new HashSet<string>();int active,epoch;float nextUpdate;
 Material baseMaterial;int centerX=int.MinValue,centerY=int.MinValue;
 void Awake(){baseMaterial=new Material(Shader.Find("Skybound/Satellite")??Shader.Find("Unlit/Texture"));}
 public void SetLocation(double lat,double lon){epoch++;StopAllCoroutines();queue.Clear();terrainQueue.Clear();terrainPending.Clear();readyTiles.Clear();active=0;foreach(var t in tiles.Values)DisposeTile(t);tiles.Clear();foreach(var d in dems.Values)if(d.tex)Destroy(d.tex);dems.Clear();LoadedTiles=FailedTiles=ElevationTiles=0;Latitude=Math.Max(-85,Math.Min(85,lat));Longitude=((lon+180)%360+360)%360-180;Origin=GeoMath.Project(Latitude,Longitude);Scale=Math.Cos(Latitude*Math.PI/180);centerX=centerY=int.MinValue;RefreshTiles();}
 public Vector2d Coordinates(Vector3 local)=>GeoMath.Unproject(Origin.x+local.x/Scale,Origin.y+local.z/Scale);
 public Vector3 Local(double lat,double lon,float altitude=0){var p=GeoMath.Project(lat,lon);double dx=p.x-Origin.x;if(dx>GeoMath.HalfWorld)dx-=2*GeoMath.HalfWorld;if(dx<-GeoMath.HalfWorld)dx+=2*GeoMath.HalfWorld;return new Vector3((float)(dx*Scale),altitude,(float)((p.y-Origin.y)*Scale));}
 void Update(){if(Time.unscaledTime>nextUpdate){nextUpdate=Time.unscaledTime+1.5f;RefreshTiles();}while(active<6&&queue.Count>0){active++;queue.Dequeue()();}
  // Network completions can arrive together. Construct at most one scenery mesh in a frame.
  while(readyTiles.Count>0&&readyTiles.Peek().disposed)readyTiles.Dequeue();
  if(readyTiles.Count>0)CreateTile(readyTiles.Dequeue());
  else if(terrainQueue.Count>0){var tile=terrainQueue.Dequeue();terrainPending.Remove(tile);if(!tile.disposed&&tile.go){var mesh=BuildMesh(tile.west,tile.north,tile.size,true);tile.go.GetComponent<MeshFilter>().sharedMesh=mesh;if(tile.mesh)Destroy(tile.mesh);tile.mesh=mesh;}}}
 void RefreshTiles(){Vector3 pos=Aircraft?Aircraft.transform.position:Vector3.zero;double east=Origin.x+pos.x/Scale,north=Origin.y+pos.z/Scale;var fraction=GeoMath.TileFraction(east,north,DetailZoom);int cx=(int)Math.Floor(fraction.x),cy=(int)Math.Floor(fraction.y);if(cx==centerX&&cy==centerY)return;centerX=cx;centerY=cy;wanted.Clear();
  // Low-resolution distant coverage plus high-resolution terrain near the aircraft.
  var far=GeoMath.TileFraction(east,north,11);int fx=(int)Math.Floor(far.x),fy=(int)Math.Floor(far.y);
  EnsureTile(DetailZoom,cx,cy,true);
  for(int r=0;r<=2;r++)for(int y=-r;y<=r;y++)for(int x=-r;x<=r;x++)if(Math.Max(Math.Abs(x),Math.Abs(y))==r)EnsureTile(11,fx+x,fy+y,false);
  for(int r=1;r<=DetailRadius;r++)for(int y=-r;y<=r;y++)for(int x=-r;x<=r;x++)if(Math.Max(Math.Abs(x),Math.Abs(y))==r)EnsureTile(DetailZoom,cx+x,cy+y,true);
  List<string> remove=new List<string>();foreach(var kv in tiles)if(!wanted.Contains(kv.Key))remove.Add(kv.Key);foreach(string k in remove){DisposeTile(tiles[k]);tiles.Remove(k);}
  List<string> old=new List<string>();foreach(var kv in dems)if(kv.Value.done&&Time.unscaledTime-kv.Value.lastUsed>50)old.Add(kv.Key);foreach(var k in old){if(dems[k].tex)Destroy(dems[k].tex);dems.Remove(k);}
 }
 void EnsureTile(int zoom,int tx,int ty,bool detail){if(ty<0||ty>=(1<<zoom))return;string key=$"{zoom}/{tx}/{ty}";wanted.Add(key);if(tiles.ContainsKey(key))return;Tile tile=new Tile();tiles[key]=tile;int version=epoch;queue.Enqueue(()=>StartCoroutine(LoadTile(key,tile,zoom,tx,ty,detail,version)));}
 bool CurrentTile(string key,Tile tile,int version)=>version==epoch&&!tile.disposed&&tiles.TryGetValue(key,out var current)&&ReferenceEquals(current,tile);
 IEnumerator LoadTile(string key,Tile tile,int zoom,int tx,int ty,bool detail,int version){
  if(!CurrentTile(key,tile,version)){active--;yield break;}
  Texture2D texture=null;string url=Url(ImageryEndpoint,zoom,GeoMath.WrapTile(tx,zoom),ty);
  using(var req=UnityWebRequestTexture.GetTexture(url)){req.timeout=15;yield return req.SendWebRequest();if(version!=epoch)yield break;if(req.result==UnityWebRequest.Result.Success)texture=DownloadHandlerTexture.GetContent(req);else FailedTiles++;}
  if(!CurrentTile(key,tile,version)){if(texture)Destroy(texture);active--;yield break;}
  // Own the downloaded image immediately, including while waiting for shared elevation data.
  tile.texture=texture;
  if(detail&&ElevationEnabled){int parentZoom=Math.Min(12,zoom),shift=zoom-parentZoom;int px=tx>>shift,py=ty>>shift;string dk=$"{parentZoom}/{px}/{py}";if(!dems.ContainsKey(dk)){var dem=new Dem();dems[dk]=dem;using(var req=UnityWebRequestTexture.GetTexture(Url(ElevationEndpoint,parentZoom,GeoMath.WrapTile(px,parentZoom),py))){req.timeout=12;yield return req.SendWebRequest();if(version!=epoch)yield break;if(req.result==UnityWebRequest.Result.Success){dem.tex=DownloadHandlerTexture.GetContent(req);dem.tex.wrapMode=TextureWrapMode.Clamp;ElevationTiles++;}dem.done=true;dem.lastUsed=Time.unscaledTime;RebuildTerrain();}}
   else while(!dems[dk].done&&version==epoch)yield return null;
  }
  if(!CurrentTile(key,tile,version)){if(texture)Destroy(texture);active--;yield break;}
  tile.size=GeoMath.TileSize(zoom);tile.west=tx*tile.size-GeoMath.HalfWorld;tile.north=GeoMath.HalfWorld-ty*tile.size;tile.detail=detail;tile.texture=texture;readyTiles.Enqueue(tile);active--;
 }
 void CreateTile(Tile tile){
  var go=new GameObject("Satellite tile");go.transform.SetParent(transform,false);go.transform.position=new Vector3((float)((tile.west-Origin.x)*Scale),tile.detail?0:-25,(float)((tile.north-Origin.y)*Scale));
  var mesh=BuildMesh(tile.west,tile.north,tile.size,tile.detail);var mf=go.AddComponent<MeshFilter>();mf.sharedMesh=mesh;var mat=new Material(baseMaterial);if(tile.texture){tile.texture.wrapMode=TextureWrapMode.Clamp;tile.texture.anisoLevel=4;mat.mainTexture=tile.texture;mat.color=Color.white;LoadedTiles++;}else{mat.color=new Color(.2f,.29f,.25f);}
  var mr=go.AddComponent<MeshRenderer>();mr.sharedMaterial=mat;mr.shadowCastingMode=UnityEngine.Rendering.ShadowCastingMode.Off;tile.go=go;tile.mesh=mesh;tile.done=true;
 }
 // Spread terrain updates over frames when new elevation arrives to avoid rebuilding the whole view at once.
 void RebuildTerrain(){foreach(var tile in tiles.Values)if(tile.done&&tile.go&&tile.detail&&terrainPending.Add(tile))terrainQueue.Enqueue(tile);}
 Mesh BuildMesh(double west,double north,double size,bool detail){int steps=detail?20:1,n=steps+1;Vector3[] v=new Vector3[n*n];Vector2[] uv=new Vector2[n*n];int[] tri=new int[steps*steps*6];float width=(float)(size*Scale);int index=0;
  for(int y=0;y<n;y++)for(int x=0;x<n;x++){float u=x/(float)steps,t=y/(float)steps;float h=detail?Elevation(west+u*size,north-t*size):0;v[y*n+x]=new Vector3(u*width,h,-t*width);uv[y*n+x]=new Vector2(u,1-t);}
  for(int y=0;y<steps;y++)for(int x=0;x<steps;x++){int a=y*n+x;tri[index++]=a;tri[index++]=a+1;tri[index++]=a+n;tri[index++]=a+1;tri[index++]=a+n+1;tri[index++]=a+n;}
  Mesh mesh=new Mesh();mesh.name="Real world terrain";mesh.vertices=v;mesh.uv=uv;mesh.triangles=tri;mesh.RecalculateNormals();mesh.RecalculateBounds();return mesh;
 }
 float Elevation(double east,double north){if(!ElevationEnabled)return 0;var f=GeoMath.TileFraction(east,north,12);int x=(int)Math.Floor(f.x),y=(int)Math.Floor(f.y);if(!dems.TryGetValue($"12/{x}/{y}",out var dem)||!dem.tex)return 0;dem.lastUsed=Time.unscaledTime;Color c=dem.tex.GetPixelBilinear((float)(f.x-x),1-(float)(f.y-y));return Mathf.Max(0,c.r*255*256+c.g*255+c.b*255/256-32768);}
 public float HeightAt(Vector3 local)=>Elevation(Origin.x+local.x/Scale,Origin.y+local.z/Scale);
 public bool ElevationLoadedAt(Vector3 local){if(!ElevationEnabled)return true;var f=GeoMath.TileFraction(Origin.x+local.x/Scale,Origin.y+local.z/Scale,12);return dems.TryGetValue($"12/{(int)Math.Floor(f.x)}/{(int)Math.Floor(f.y)}",out var dem)&&dem.done&&dem.tex;}
 public bool SurfaceLoaded(Vector3 local){var f=GeoMath.TileFraction(Origin.x+local.x/Scale,Origin.y+local.z/Scale,DetailZoom);string key=$"{DetailZoom}/{(int)Math.Floor(f.x)}/{(int)Math.Floor(f.y)}";return tiles.TryGetValue(key,out var t)&&t.done&&t.texture;}
 public bool LooksLikeWater(Vector3 local){var f=GeoMath.TileFraction(Origin.x+local.x/Scale,Origin.y+local.z/Scale,DetailZoom);int tx=(int)Math.Floor(f.x),ty=(int)Math.Floor(f.y);if(!tiles.TryGetValue($"{DetailZoom}/{tx}/{ty}",out var tile)||!tile.texture)return false;Color c=tile.texture.GetPixelBilinear((float)(f.x-tx),1-(float)(f.y-ty));return c.b>c.r*1.12f&&c.g>c.r*1.05f&&c.r<.45f;}
 public void Rebase(Vector3 shift){Origin.x+=shift.x/Scale;Origin.y+=shift.z/Scale;foreach(var t in tiles.Values)if(t.go)t.go.transform.position-=shift;centerX=int.MinValue;}
 string Url(string pattern,int z,int x,int y)=>pattern.Replace("{z}",z.ToString()).Replace("{x}",x.ToString()).Replace("{y}",y.ToString());
 void DisposeTile(Tile t){t.disposed=true;if(t.go){Destroy(t.go.GetComponent<MeshRenderer>().sharedMaterial);Destroy(t.go);}if(t.mesh)Destroy(t.mesh);if(t.texture)Destroy(t.texture);}
 void OnDestroy(){foreach(var t in tiles.Values)DisposeTile(t);foreach(var d in dems.Values)if(d.tex)Destroy(d.tex);if(baseMaterial)Destroy(baseMaterial);}
}
}
