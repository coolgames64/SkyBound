using System;
using System.Collections.Generic;
using UnityEngine;
namespace Skybound {
[Serializable] public class RunwayDefinition {
 public string Name,Ident;
 public double Latitude,Longitude,EndLatitude,EndLongitude;
 public float Elevation,Heading,Length,Width;
}
// A local snapshot permits runway selection before imagery finishes downloading.
public static class RunwayCatalog {
 [Serializable]class Data{public RunwayDefinition[] Runways;}
 static RunwayDefinition[] runways;
 static Dictionary<string,RunwayDefinition> byIdent;
 public static int Count {get{Load();return runways.Length;}}
 static void Load(){if(runways!=null)return;var file=Resources.Load<TextAsset>("Runways");var data=file?JsonUtility.FromJson<Data>(file.text):null;runways=data?.Runways??Array.Empty<RunwayDefinition>();byIdent=new Dictionary<string,RunwayDefinition>(StringComparer.OrdinalIgnoreCase);foreach(var runway in runways)if(runway!=null&&!string.IsNullOrWhiteSpace(runway.Ident)&&!byIdent.ContainsKey(runway.Ident))byIdent.Add(runway.Ident,runway);if(runways.Length==0)Debug.LogError("The runway catalog is missing or empty.");}
 // Exact directions are stable keys in the bundled snapshot, e.g. "YSSY / 16R".
 public static RunwayDefinition FindByIdent(string ident){if(string.IsNullOrWhiteSpace(ident))return null;Load();return byIdent.TryGetValue(ident.Trim(),out var runway)?runway:null;}
 public static RunwayDefinition Nearest(double latitude,double longitude){Load();RunwayDefinition best=null;double score=double.MaxValue;foreach(var runway in runways){double distance=Distance(latitude,longitude,runway.Latitude,runway.Longitude);if(distance<score){score=distance;best=runway;}}return best;}
 public static double Distance(double lat1,double lon1,double lat2,double lon2){double a=lat1*Math.PI/180,b=lat2*Math.PI/180,dy=(lat2-lat1)*Math.PI/180,dx=(lon2-lon1)*Math.PI/180;double s=Math.Sin(dy/2),t=Math.Sin(dx/2),h=s*s+Math.Cos(a)*Math.Cos(b)*t*t;return 6371000*2*Math.Atan2(Math.Sqrt(Math.Max(0,Math.Min(1,h))),Math.Sqrt(Math.Max(0,1-h)));}
}
}
