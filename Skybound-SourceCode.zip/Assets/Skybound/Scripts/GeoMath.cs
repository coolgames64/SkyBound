using System;
using UnityEngine;
namespace Skybound {
public static class GeoMath {
 public const double HalfWorld=20037508.342789244;
 public static Vector2d Project(double latitude,double longitude) {latitude=Math.Max(-85,Math.Min(85,latitude)); return new Vector2d(longitude*HalfWorld/180,Math.Log(Math.Tan(Math.PI/4+latitude*Math.PI/360))*HalfWorld/Math.PI);}
 public static Vector2d Unproject(double east,double north) {return new Vector2d((2*Math.Atan(Math.Exp(north*Math.PI/HalfWorld))-Math.PI/2)*180/Math.PI,((east*180/HalfWorld+180)%360+360)%360-180);}
 public static int WrapTile(int x,int zoom) {int n=1<<zoom;return ((x%n)+n)%n;}
 public static Vector2d TileFraction(double east,double north,int zoom) {double size=2*HalfWorld/(1<<zoom);return new Vector2d((east+HalfWorld)/size,(HalfWorld-north)/size);}
 public static double TileSize(int zoom) =>2*HalfWorld/(1<<zoom);
 public static float DistanceToSegment(Vector2 p,Vector2 a,Vector2 b) {Vector2 ab=b-a;float t=ab.sqrMagnitude>0?Mathf.Clamp01(Vector2.Dot(p-a,ab)/ab.sqrMagnitude):0;return Vector2.Distance(p,a+t*ab);}
}
[Serializable] public struct Vector2d {public double x,y;public Vector2d(double x,double y){this.x=x;this.y=y;}}
}
