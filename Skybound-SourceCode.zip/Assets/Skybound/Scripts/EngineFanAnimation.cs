using System;
using System.Collections.Generic;
using UnityEngine;

namespace Skybound {
public class EngineFanAnimation:MonoBehaviour {
 [Serializable]class FanLocation {public float x,y,z,radius;}
 [Serializable]class AircraftLocations {public string id;public FanLocation[] fans;}
 [Serializable]class LocationLibrary {public AircraftLocations[] aircraft;}
 class Rotor {public Transform transform;public Vector3 position;public Quaternion original;public float angle,speed;public bool propeller;}
 FlightController aircraft;readonly List<Rotor> rotors=new List<Rotor>();readonly List<Mesh> meshes=new List<Mesh>();readonly List<Material> materials=new List<Material>();
 public int RotorCount=>rotors.Count;public int OriginalRotorCount {get;private set;}public int GeneratedRotorCount=>RotorCount-OriginalRotorCount;
 public float RotationFor(int index)=>rotors[index].angle;public float VisualSpeedFor(int index)=>rotors[index].speed;public Vector3 LocalPositionFor(int index)=>rotors[index].position;
 public static EngineFanAnimation Create(Transform visual,GameObject model,FlightController aircraft,string resourcePath,string aircraftName,float length){var go=new GameObject("Animated engine rotors");go.transform.SetParent(visual,false);var animation=go.AddComponent<EngineFanAnimation>();animation.Initialize(visual,model,aircraft,resourcePath,aircraftName,length);return animation;}
 void Initialize(Transform visual,GameObject model,FlightController controller,string resourcePath,string aircraftName,float length){
  aircraft=controller;var steel=SkyboundBootstrap.MakeMaterial(new Color(.4f,.44f,.46f));if(steel.HasProperty("_Metallic"))steel.SetFloat("_Metallic",.75f);if(steel.HasProperty("_Smoothness"))steel.SetFloat("_Smoothness",.48f);if(steel.HasProperty("_Cull"))steel.SetFloat("_Cull",0);materials.Add(steel);
  var spinner=SkyboundBootstrap.MakeMaterial(new Color(.78f,.82f,.8f),true);if(spinner.HasProperty("_Cull"))spinner.SetFloat("_Cull",0);materials.Add(spinner);
  foreach(var renderer in model.GetComponentsInChildren<Renderer>(true)){
   string n=renderer.name.ToLowerInvariant();if(n.Contains("fan")&&(n.Contains("spinning")||n.Contains("blur"))){renderer.enabled=false;continue;}
   bool propeller=n.StartsWith("propeller_"),actual=n.StartsWith("enginefan_")||n.StartsWith("fanlcfm56")||propeller;
   if(!actual)continue;
   Vector3 center=visual.InverseTransformPoint(renderer.bounds.center);var pivot=new GameObject(propeller?"Propeller shaft":"Engine fan shaft").transform;pivot.SetParent(transform,false);pivot.localPosition=center;renderer.transform.SetParent(pivot,true);
   rotors.Add(new Rotor{transform=pivot,position=center,original=Quaternion.identity,propeller=propeller});OriginalRotorCount++;
   if(!propeller){float radius=Mathf.Max(renderer.bounds.size.x,renderer.bounds.size.y)*.12f;AddSpinnerMark(pivot,Mathf.Clamp(radius,.10f,.35f),spinner);}
  }
  if(rotors.Count>0)return;
  var asset=Resources.Load<TextAsset>("Aircraft/EngineFanLocations");var library=asset?JsonUtility.FromJson<LocationLibrary>(asset.text):null;string id=resourcePath.Substring(resourcePath.LastIndexOf('/')+1);
  FanLocation[] locations=null;if(library!=null&&library.aircraft!=null)foreach(var entry in library.aircraft)if(entry.id==id){locations=entry.fans;break;}
  if(locations==null&&aircraftName.ToUpperInvariant().Contains("CONCORDE"))locations=new[]{Location(-4.70f,-2.79f,-11.25f,.45f),Location(-5.81f,-2.79f,-11.25f,.45f),Location(4.70f,-2.79f,-11.25f,.45f),Location(5.81f,-2.79f,-11.25f,.45f)};
  if(locations==null)locations=new[]{Location(-2.05f,-1.25f,-length*.24f,.46f),Location(2.05f,-1.25f,-length*.24f,.46f)};
  var dark=SkyboundBootstrap.MakeMaterial(new Color(.022f,.029f,.033f));if(dark.HasProperty("_Cull"))dark.SetFloat("_Cull",0);materials.Add(dark);
  foreach(var location in locations){
   // Merged source meshes retain stationary fan/blur plates ahead of the measured blade centre.
   // Keep the animated face just forward of those plates, within the original intake.
   var rotor=new GameObject("Source-positioned engine fan").transform;rotor.SetParent(transform,false);rotor.localPosition=new Vector3(location.x,location.y,location.z+.15f);
   float r=location.radius*.96f;var blades=new AirlinerMeshBatch();var hub=new AirlinerMeshBatch();var backing=new AirlinerMeshBatch();
   for(int i=0;i<28;i++){
    float a=i*Mathf.PI*2/28,b=a+.108f;Vector3 P(float angle,float radius,float z)=>new Vector3(Mathf.Sin(angle)*radius,Mathf.Cos(angle)*radius,z);
    blades.Quad(P(a,r*.23f,.018f),P(b,r*.23f,.018f),P(b+.22f,r,.025f),P(a+.14f,r,.025f));
   }
   for(int i=0;i<32;i++){float a=i*Mathf.PI*2/32,b=(i+1)*Mathf.PI*2/32;Vector3 p0=new Vector3(Mathf.Sin(a)*r*.21f,Mathf.Cos(a)*r*.21f,.03f),p1=new Vector3(Mathf.Sin(b)*r*.21f,Mathf.Cos(b)*r*.21f,.03f);hub.Triangle(p0,p1,new Vector3(0,0,r*.32f));backing.Triangle(new Vector3(0,0,-.012f),new Vector3(Mathf.Sin(a)*r,Mathf.Cos(a)*r,-.012f),new Vector3(Mathf.Sin(b)*r,Mathf.Cos(b)*r,-.012f));}
   meshes.Add(backing.Create(rotor,"Dark fan inlet",dark));meshes.Add(blades.Create(rotor,"Swept rotating fan blades",steel));meshes.Add(hub.Create(rotor,"Spinner cone",steel));AddSpinnerMark(rotor,r*.15f,spinner,r*.33f);
   rotors.Add(new Rotor{transform=rotor,position=rotor.localPosition,original=Quaternion.identity});
  }
 }
 static FanLocation Location(float x,float y,float z,float radius)=>new FanLocation{x=x,y=y,z=z,radius=radius};
 void AddSpinnerMark(Transform parent,float radius,Material material,float z=.025f){var stripe=new AirlinerMeshBatch();for(int i=0;i<18;i++){float a=i*.24f,b=(i+1)*.24f,r0=radius*(.16f+i/24f),r1=radius*(.16f+(i+1)/24f);Vector3 P(float angle,float r)=>new Vector3(Mathf.Sin(angle)*r,Mathf.Cos(angle)*r,z);stripe.Quad(P(a,r0),P(a,r0+radius*.11f),P(b,r1+radius*.11f),P(b,r1));}meshes.Add(stripe.Create(parent,"Spinner spiral",material));}
 void Update(){if(!aircraft||Time.timeScale<=0||Time.deltaTime<=0)return;float dt=Mathf.Min(Time.deltaTime,.1f);foreach(var rotor in rotors){float power=rotor.position.x<-.1f?aircraft.LeftEnginePower:rotor.position.x>.1f?aircraft.RightEnginePower:aircraft.EnginePower;float windmill=Mathf.Min(60,aircraft.Speed*.55f);float target=rotor.propeller?power*520+windmill:power*190+windmill;rotor.speed=Mathf.Lerp(rotor.speed,target,1-Mathf.Exp(-dt*3));
   // Presentation rotation is intentionally limited per frame to keep fan blades from strobing backwards.
   float delta=Mathf.Min(rotor.speed*dt,rotor.propeller?24:3);rotor.angle=Mathf.Repeat(rotor.angle+delta,360);rotor.transform.localRotation=rotor.original*Quaternion.AngleAxis(rotor.angle,Vector3.forward);
  }}
 void OnDestroy(){foreach(var mesh in meshes)if(mesh)Destroy(mesh);foreach(var material in materials)if(material)Destroy(material);}
}
}
