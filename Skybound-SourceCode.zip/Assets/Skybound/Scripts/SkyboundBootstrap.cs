using UnityEngine;
using UnityEngine.Rendering;
namespace Skybound {
public class SkyboundBootstrap:MonoBehaviour {
 public AircraftCatalog Catalog;
 public FlightController Aircraft;public SatelliteWorld World;public MissionDirector Mission;public FlightCamera CameraRig;public FlightHUD HUD;
 void Awake(){Application.targetFrameRate=60;Application.runInBackground=true;QualitySettings.vSyncCount=BrowserPlatform.Mobile?0:1;if(BrowserPlatform.Mobile){QualitySettings.shadows=ShadowQuality.Disable;Screen.orientation=ScreenOrientation.LandscapeLeft;}Time.fixedDeltaTime=.02f;
  gameObject.AddComponent<FlightPerformance>();
  World=new GameObject("Satellite Earth").AddComponent<SatelliteWorld>();
  Aircraft=new GameObject("Player aircraft").AddComponent<FlightController>();var visual=new GameObject("Aircraft visual");visual.transform.SetParent(Aircraft.transform,false);Aircraft.Visual=visual.transform;var model=visual.AddComponent<AircraftVisual>();model.Aircraft=Aircraft;model.Catalog=Catalog;model.Select(0);
  var cam=new GameObject("Flight camera");var c=cam.AddComponent<Camera>();c.nearClipPlane=.5f;c.farClipPlane=65000;c.clearFlags=CameraClearFlags.Skybox;c.fieldOfView=58;cam.AddComponent<AudioListener>();CameraRig=cam.AddComponent<FlightCamera>();CameraRig.Aircraft=Aircraft;
  Mission=new GameObject("Mission director").AddComponent<MissionDirector>();Mission.Aircraft=Aircraft;Mission.World=World;Mission.CameraRig=CameraRig;Aircraft.World=World;Aircraft.Mission=Mission;World.Aircraft=Aircraft;
  HUD=new GameObject("Flight interface").AddComponent<FlightHUD>();HUD.Aircraft=Aircraft;HUD.World=World;HUD.Mission=Mission;HUD.CameraRig=CameraRig;HUD.Visual=model;
  var sun=new GameObject("Sun").AddComponent<Light>();sun.type=LightType.Directional;sun.color=new Color(1,.94f,.84f);sun.intensity=2;sun.shadows=LightShadows.Soft;sun.transform.rotation=Quaternion.Euler(29,-45,0);RenderSettings.sun=sun;
  var sky=new Material(Shader.Find("Skybound/Atmosphere"));RenderSettings.skybox=sky;RenderSettings.ambientMode=AmbientMode.Trilight;RenderSettings.ambientSkyColor=new Color(.58f,.72f,.88f);RenderSettings.ambientEquatorColor=new Color(.4f,.48f,.52f);RenderSettings.ambientGroundColor=new Color(.23f,.29f,.31f);RenderSettings.fog=true;RenderSettings.fogColor=new Color(.62f,.74f,.81f);RenderSettings.fogMode=FogMode.Linear;RenderSettings.fogStartDistance=4500;RenderSettings.fogEndDistance=23000;
  Mission.StartFlight(FlightMode.FreeFlight,40.773,-73.998,"New York",false,true);Time.timeScale=0;CameraRig.Discover=true;HUD.Menu=MenuPage.Discover;HUD.DetectMobile();
  var audio=Aircraft.gameObject.AddComponent<FlightAudio>();audio.Aircraft=Aircraft;
 }
 public static Material MakeMaterial(Color color,bool unlit=false){var m=new Material(Shader.Find(unlit?"Universal Render Pipeline/Unlit":"Universal Render Pipeline/Lit")??Shader.Find("Standard"));m.color=color;if(m.HasProperty("_BaseColor"))m.SetColor("_BaseColor",color);return m;}
}
}
