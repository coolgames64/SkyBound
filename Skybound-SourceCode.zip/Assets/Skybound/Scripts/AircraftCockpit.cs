using System.Collections.Generic;
using UnityEngine;

namespace Skybound {
// Shared instrumented flight deck for types without a supplied cockpit mesh.
public class AircraftCockpit:MonoBehaviour {
 public Vector3 EyeOffset=>new Vector3(-.43f,1.38f,.02f);
 FlightController aircraft;Transform horizon;TextMesh speedText,altitudeText,headingText,engineText;
 float nextDisplay;readonly List<Mesh> meshes=new List<Mesh>();readonly List<Material> materials=new List<Material>();
 public static AircraftCockpit Create(Transform parent,FlightController aircraft,string name){var go=new GameObject("Shared instrumented flight deck");go.transform.SetParent(parent,false);var cockpit=go.AddComponent<AircraftCockpit>();cockpit.aircraft=aircraft;cockpit.Build(name);return cockpit;}
 void Build(string name){
  float width=Mathf.Clamp(AircraftCabin.WidthFor(name)*.72f,2.15f,3.5f);var shell=new AirlinerMeshBatch();var panel=new AirlinerMeshBatch();var black=new AirlinerMeshBatch();var metal=new AirlinerMeshBatch();var fabric=new AirlinerMeshBatch();var lights=new AirlinerMeshBatch();
  black.Box(new Vector3(0,-.06f,.2f),new Vector3(width,.12f,3.25f));
  shell.Box(new Vector3(0,.43f,1.45f),new Vector3(width,.86f,.18f));
  panel.Box(new Vector3(0,.87f,1.08f),new Vector3(width*.96f,.39f,.5f),Quaternion.Euler(9,0,0));
  black.Box(new Vector3(0,1.115f,1.17f),new Vector3(width*.97f,.1f,.69f));
  for(int side=-1;side<=1;side+=2){
   float x=side*width*.5f;shell.Box(new Vector3(x,.56f,.3f),new Vector3(.12f,1.12f,3.25f));
   shell.Box(new Vector3(x,2.05f,.32f),new Vector3(.16f,.18f,3.3f));
   shell.Box(new Vector3(x,1.55f,-1.15f),new Vector3(.16f,.92f,.19f));
   shell.Box(new Vector3(x,1.62f,1.48f),new Vector3(.12f,1.05f,.1f),Quaternion.Euler(0,0,-side*9));
   panel.Box(new Vector3(side*width*.4f,.67f,.04f),new Vector3(.27f,.14f,1.48f));
   float seatX=side*.52f;fabric.Box(new Vector3(seatX,.46f,-.44f),new Vector3(.55f,.14f,.58f));fabric.Box(new Vector3(seatX,.83f,-.71f),new Vector3(.55f,.78f,.13f),Quaternion.Euler(-7,0,0));fabric.Box(new Vector3(seatX,1.25f,-.66f),new Vector3(.33f,.27f,.16f));
   metal.Box(new Vector3(seatX,.22f,-.4f),new Vector3(.15f,.38f,.18f));
   panel.Box(new Vector3(seatX,.68f,.24f),new Vector3(.1f,.18f,.12f));black.Box(new Vector3(seatX,.85f,.23f),new Vector3(.24f,.04f,.05f));
  }
  // Pillars frame open front and side windscreens; scenery is rendered directly through them.
  shell.Box(new Vector3(0,1.71f,1.5f),new Vector3(.095f,1.03f,.1f));shell.Box(new Vector3(0,2.16f,.33f),new Vector3(width,.13f,3.3f));
  panel.Box(new Vector3(0,.55f,.22f),new Vector3(.36f,.64f,.96f));
  for(int side=-1;side<=1;side+=2){metal.Box(new Vector3(side*.07f,.93f,.46f),new Vector3(.035f,.21f,.055f),Quaternion.Euler(-14,0,0));black.Box(new Vector3(side*.07f,1.025f,.435f),new Vector3(.1f,.035f,.095f));}
  var centres=new[]{-.58f,-.18f,.24f,.64f};foreach(float x in centres){black.Box(new Vector3(x,.947f,.802f),new Vector3(.35f,.31f,.036f));metal.Box(new Vector3(x,.947f,.792f),new Vector3(.372f,.335f,.022f));black.Box(new Vector3(x,.947f,.776f),new Vector3(.33f,.294f,.015f));}
  for(int i=0;i<9;i++){float x=-.55f+i*.135f;metal.Box(new Vector3(x,1.14f,1.01f),new Vector3(.052f,.028f,.05f));lights.Box(new Vector3(x,1.14f,.966f),new Vector3(.028f,.007f,.005f));}
  Add(shell,"Flight deck structure",new Color(.37f,.41f,.43f));Add(panel,"Instrument panel and consoles",new Color(.115f,.16f,.185f));Add(metal,"Flight deck fittings",new Color(.35f,.39f,.41f));Add(black,"Display bezels and controls",new Color(.018f,.027f,.035f));Add(fabric,"Pilot seats",new Color(.19f,.25f,.27f));Add(lights,"Illuminated switches",new Color(.53f,.91f,.81f),true);
  var instrument=new GameObject("Artificial horizon");instrument.transform.SetParent(transform,false);instrument.transform.localPosition=new Vector3(-.58f,.972f,.762f);horizon=instrument.transform;
  var sky=new AirlinerMeshBatch();var earth=new AirlinerMeshBatch();for(int i=0;i<32;i++){float a=i*Mathf.PI*2/32,b=(i+1)*Mathf.PI*2/32;var batch=i<16?sky:earth;batch.Triangle(Vector3.zero,new Vector3(Mathf.Cos(a)*.105f,Mathf.Sin(a)*.105f,0),new Vector3(Mathf.Cos(b)*.105f,Mathf.Sin(b)*.105f,0));}
  Add(sky,"Horizon sky",new Color(.11f,.43f,.66f),true,horizon);Add(earth,"Horizon ground",new Color(.51f,.31f,.16f),true,horizon);
  var reticle=new AirlinerMeshBatch();reticle.Box(new Vector3(-.58f,.974f,.751f),new Vector3(.13f,.005f,.002f));reticle.Box(new Vector3(-.58f,.962f,.751f),new Vector3(.005f,.026f,.002f));Add(reticle,"Horizon aircraft symbol",new Color(1,.88f,.34f),true);
  speedText=Label("SPEED",new Vector3(-.58f,.839f,.750f),.008f);altitudeText=Label("ALTITUDE",new Vector3(-.18f,.945f,.750f),.01f);headingText=Label("HEADING",new Vector3(.24f,.945f,.750f),.01f);engineText=Label("ENGINES",new Vector3(.64f,.945f,.750f),.0072f);
  Label("FLIGHT DECK",new Vector3(0,1.202f,.942f),.0065f);RefreshDisplays();
 }
 TextMesh Label(string text,Vector3 position,float size){var go=new GameObject(text);go.transform.SetParent(transform,false);go.transform.localPosition=position;var label=go.AddComponent<TextMesh>();label.font=Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");label.fontSize=48;label.characterSize=size;label.anchor=TextAnchor.MiddleCenter;label.alignment=TextAlignment.Center;label.color=new Color(.73f,.95f,.9f);label.text=text;go.GetComponent<MeshRenderer>().sharedMaterial=label.font.material;return label;}
 void Add(AirlinerMeshBatch batch,string name,Color color,bool unlit=false,Transform parent=null){var material=SkyboundBootstrap.MakeMaterial(color,unlit);if(material.HasProperty("_Cull"))material.SetFloat("_Cull",0);materials.Add(material);meshes.Add(batch.Create(parent?parent:transform,name,material));}
 void LateUpdate(){if(!aircraft)return;horizon.localRotation=Quaternion.Euler(0,0,aircraft.Roll);horizon.localPosition=new Vector3(-.58f,.972f-Mathf.Clamp(aircraft.Pitch*.0017f,-.024f,.024f),.762f);if(Time.unscaledTime>=nextDisplay){nextDisplay=Time.unscaledTime+.12f;RefreshDisplays();}}
 void RefreshDisplays(){if(!aircraft||!speedText)return;speedText.text="IAS "+(aircraft.Speed*1.94384f).ToString("F0")+" KT";altitudeText.text="ALT\n"+(aircraft.Altitude*3.28084f).ToString("F0")+" FT\nVS "+(aircraft.VerticalSpeed*196.8504f).ToString("F0");headingText.text="HDG\n"+Mathf.Repeat(aircraft.Heading,360).ToString("000")+"°\nFLAP "+aircraft.FlapPosition.ToString("F1");engineText.text="N1 L  "+(aircraft.LeftEnginePower*100).ToString("F0")+"%\nN1 R  "+(aircraft.RightEnginePower*100).ToString("F0")+"%\nFUEL "+(aircraft.FuelRemaining*100).ToString("F0")+"%";}
 void OnDestroy(){foreach(var mesh in meshes)if(mesh)Destroy(mesh);foreach(var material in materials)if(material)Destroy(material);}
}
}
