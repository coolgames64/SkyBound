using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Skybound {
public class AircraftVisual:MonoBehaviour {
 public FlightController Aircraft;public AircraftCatalog Catalog;public int Selected;
 public string AircraftName="Passenger airliner";public string Source;
 public string StockAircraftName {get;private set;}="Passenger airliner";
 public AircraftDesign SelectedDesign {get;private set;}
 public Vector3 CockpitOffset,CabinOffset; public GameObject CockpitModel;
 public GameObject CabinModel {get;private set;}
 public GameObject ExteriorModel=>model;
 public float AircraftLength {get;private set;}=37.6f;
 public float InteriorFloorHeight=>CabinFloorHeight();
 public bool HasCockpit=>CockpitModel!=null;public bool HasCabin=>model!=null;
 public bool UsesSharedCockpit {get;private set;}
 public EngineFanAnimation Fans {get;private set;}public bool HasEngineFans=>Fans&&Fans.RotorCount>0;
 public bool Loading {get;private set;}
 public float GearUpClearance {get;private set;}=3;
 public float GearDownClearance {get;private set;}=3;
 // Contact points are cached in the normalized visual frame, independent of its rendered position.
 Vector3[] bodyContactPoints=new Vector3[0],gearContactPoints=new Vector3[0];
 public float GroundClearance {
  get {
   bool down=Aircraft&&Aircraft.Gear;float pitch=Aircraft?Aircraft.Pitch:0,roll=Aircraft?Aircraft.Roll:0;
   if(Mathf.Abs(pitch)<.001f&&Mathf.Abs(roll)<.001f)return down?GearDownClearance:GearUpClearance;
   Quaternion attitude=Quaternion.Euler(-pitch,0,-roll);float minimum=0;bool found=false;
   foreach(var point in bodyContactPoints){float y=(attitude*point).y;if(!found||y<minimum)minimum=y;found=true;}
   if(down)foreach(var point in gearContactPoints){float y=(attitude*point).y;if(!found||y<minimum)minimum=y;found=true;}
   return found?Mathf.Max(.5f,-minimum+.15f):down?GearDownClearance:GearUpClearance;
  }
 }
 Coroutine selection;RamAirTurbine rat;Vector3 cockpitModelOffset;Quaternion cockpitModelRotation=Quaternion.identity;
 // Validated normalized A320 floor reference; refreshed whenever its exterior is selected.
 float a320CabinFloorReference=-5.326f+AircraftCabin.WidthFor("Airbus A320")*.7f;
 bool exteriorVisible=true,cabinVisible,cockpitVisible;Renderer[] exteriorRenderers=new Renderer[0];bool[] exteriorDefaults=new bool[0];
 List<GameObject> gears=new List<GameObject>();GameObject model;Transform gearRoot;
 public void Select(int index)=>BeginSelection(index,null);
 public void SelectDesign(AircraftDesign design){if(design==null)return;var safe=AircraftDesignStore.Sanitize(design,Catalog&&Catalog.Aircraft!=null?Catalog.Aircraft.Length:AircraftDesignStore.StockAircraftCount);BeginSelection(safe.BaseAircraftIndex,safe);}
 void BeginSelection(int index,AircraftDesign design){
  if(!Catalog||Catalog.Aircraft==null||Catalog.Aircraft.Length==0||!Aircraft){Debug.LogError("Aircraft selection requires a catalog and flight controller.");return;}
  // View modes hide renderers rather than disabling the owner of asynchronous loading.
  if(!gameObject.activeSelf)gameObject.SetActive(true);
  if(selection!=null)StopCoroutine(selection);
  SelectedDesign=design;Aircraft.ThrustMultiplier=design!=null?design.ThrustMultiplier:1;Aircraft.ControlSensitivity=design!=null?design.ControlSensitivity:1;
  selection=StartCoroutine(LoadSelection(index));
 }
 IEnumerator LoadSelection(int index){
  Selected=Mathf.Clamp(index,0,Catalog.Aircraft.Length-1);Loading=true;
  var entry=Catalog.Aircraft[Selected];
  Aircraft.ConfigureAircraft(entry.Name);
  StockAircraftName=entry.Name;AircraftName=SelectedDesign!=null?SelectedDesign.Name:entry.Name;Source=entry.Source;
  GameObject asset=entry.Prefab;
  if(!asset){var request=Resources.LoadAsync<GameObject>(entry.ResourcePath);yield return request;asset=request.asset as GameObject;}
  if(!asset){Loading=false;Debug.LogError("Missing aircraft model: "+entry.Name);yield break;}
  var cockpitEntry=Catalog.Aircraft[0];GameObject cockpit=cockpitEntry.CockpitPrefab;
  if(!cockpit&&!string.IsNullOrEmpty(cockpitEntry.CockpitResourcePath)){var request=Resources.LoadAsync<GameObject>(cockpitEntry.CockpitResourcePath);yield return request;cockpit=request.asset as GameObject;}
  var slides=GetComponent<EmergencySlides>();if(slides)slides.SetVisible(false);
  gears.Clear();if(model)Destroy(model);if(CockpitModel)Destroy(CockpitModel);if(CabinModel)Destroy(CabinModel);if(Fans)Destroy(Fans.gameObject);if(rat)Destroy(rat.gameObject);if(gearRoot)Destroy(gearRoot.gameObject);
  model=null;CockpitModel=null;CabinModel=null;Fans=null;gearRoot=null;
  model=Instantiate(asset,transform);model.name="Aircraft model";model.transform.localPosition=Vector3.zero;model.transform.localRotation=Quaternion.Euler(entry?.PitchOffset??0,entry?.YawOffset??0,entry?.RollOffset??0);model.transform.localScale=Vector3.one;
  Bounds b=new Bounds();bool found=false;
  foreach(var r in model.GetComponentsInChildren<Renderer>(true)){var bounds=r.localBounds;for(int x=-1;x<=1;x+=2)for(int y=-1;y<=1;y+=2)for(int z=-1;z<=1;z+=2){var point=transform.InverseTransformPoint(r.transform.TransformPoint(bounds.center+Vector3.Scale(bounds.extents,new Vector3(x,y,z))));if(!found){b=new Bounds(point,Vector3.zero);found=true;}else b.Encapsulate(point);}}
  float length=entry.Length;AircraftLength=length;float current=b.size.z;if(current>.001f){float scale=length/current;model.transform.localScale*=scale;model.transform.localPosition=-b.center*scale;}
  foreach(var t in model.GetComponentsInChildren<Transform>(true)){string n=t.name.ToLowerInvariant();if(n.Contains("wheel")||n.Contains("landinggear")||n.Contains("landing_gear")||n.StartsWith("mlg")||n.StartsWith("nlg")||n.StartsWith("landing-")){if(t==model.transform)continue;gears.Add(t.gameObject);}}
  CockpitOffset=entry?.CockpitOffset??new Vector3(0,2,14);
  AircraftName=SelectedDesign!=null?SelectedDesign.Name:StockAircraftName;Source=entry?.Source??"FlightGear";
  UsesSharedCockpit=!cockpit;
  // A simple retractable gear supplement is used only if the imported model has no gear parts.
  if(gears.Count==0){gearRoot=new GameObject("Retractable landing gear").transform;gearRoot.SetParent(model.transform.parent,false);foreach(var p in new[]{new Vector3(0,-3,length*.27f),new Vector3(-3,-3,-2),new Vector3(3,-3,-2)}){var wheel=GameObject.CreatePrimitive(PrimitiveType.Cylinder);wheel.name="Landing wheel";Destroy(wheel.GetComponent<Collider>());wheel.transform.SetParent(gearRoot,false);wheel.transform.localPosition=p;wheel.transform.localRotation=Quaternion.Euler(0,0,90);wheel.transform.localScale=new Vector3(1.2f,.45f,1.2f);wheel.GetComponent<Renderer>().material=SkyboundBootstrap.MakeMaterial(new Color(.04f,.05f,.06f));}gears.Add(gearRoot.gameObject);}
  CacheGroundClearance();
  if(Selected==0)a320CabinFloorReference=CabinFloorHeight();
  if(cockpit){CockpitModel=Instantiate(cockpit,Aircraft.transform);CockpitModel.name="A320 flight deck";Vector3 originalOffset=new Vector3(0,0,14);cockpitModelOffset=Selected==0?originalOffset:new Vector3(0,CabinFloorHeight()-a320CabinFloorReference,length*.36f);cockpitModelRotation=Quaternion.Euler(0,180,0);CockpitOffset=cockpitModelOffset+(cockpitEntry.CockpitOffset-originalOffset);CockpitModel.transform.localPosition=cockpitModelOffset;CockpitModel.transform.localRotation=cockpitModelRotation;CockpitModel.transform.localScale=Vector3.one;CockpitModel.SetActive(false);}
  if(!cockpit){var deck=AircraftCockpit.Create(Aircraft.transform,Aircraft,StockAircraftName);CockpitModel=deck.gameObject;cockpitModelOffset=new Vector3(0,CabinFloorHeight(),length*.36f);cockpitModelRotation=Quaternion.identity;CockpitOffset=cockpitModelOffset+deck.EyeOffset;CockpitModel.SetActive(false);}
  Fans=EngineFanAnimation.Create(transform,model,Aircraft,entry.ResourcePath,StockAircraftName,length);
  rat=RamAirTurbine.Create(transform,Aircraft,length,-GearUpClearance+.4f);
  if(SelectedDesign!=null)ApplyDesignTint(SelectedDesign.Tint);
  CacheExteriorRenderers();SetExteriorVisible(exteriorVisible);SetCockpitVisible(cockpitVisible);
  if(cabinVisible)EnsureCabin();if(CabinModel)CabinModel.SetActive(cabinVisible);
  Loading=false;selection=null;Resources.UnloadUnusedAssets();
 }
 float CabinFloorHeight()=>-GearUpClearance+AircraftCabin.WidthFor(StockAircraftName)*.7f;
 void EnsureCabin(){if(CabinModel||!model)return;var cabin=AircraftCabin.Create(transform,AircraftLength,StockAircraftName,CabinFloorHeight());CabinModel=cabin.gameObject;CabinOffset=CabinModel.transform.localPosition+cabin.EyeOffset;CabinModel.SetActive(cabinVisible);}
 void ApplyDesignTint(Color tint){
  int baseColor=Shader.PropertyToID("_BaseColor"),legacyColor=Shader.PropertyToID("_Color");var block=new MaterialPropertyBlock();
  foreach(var renderer in model.GetComponentsInChildren<Renderer>(true)){
   if(IsGear(renderer.transform))continue;var materials=renderer.sharedMaterials;
   for(int i=0;i<materials.Length;i++){var material=materials[i];if(!material)continue;block.Clear();renderer.GetPropertyBlock(block,i);
    if(material.HasProperty(baseColor)){Color original=material.GetColor(baseColor);block.SetColor(baseColor,new Color(original.r*tint.r,original.g*tint.g,original.b*tint.b,original.a));}
    if(material.HasProperty(legacyColor)){Color original=material.GetColor(legacyColor);block.SetColor(legacyColor,new Color(original.r*tint.r,original.g*tint.g,original.b*tint.b,original.a));}
    renderer.SetPropertyBlock(block,i);
   }
  }
 }
 public void SetCabinVisible(bool visible){cabinVisible=visible;if(visible&&!Loading)EnsureCabin();if(CabinModel)CabinModel.SetActive(visible);}
 public void SetCockpitVisible(bool visible){cockpitVisible=visible;if(CockpitModel)CockpitModel.SetActive(visible);}
 public void PlaceInteriors(Vector3 position,Quaternion rotation){if(CockpitModel)CockpitModel.transform.SetPositionAndRotation(position+rotation*cockpitModelOffset,rotation*cockpitModelRotation);}
 public void SetExteriorVisible(bool visible){exteriorVisible=visible;for(int i=0;i<exteriorRenderers.Length;i++)if(exteriorRenderers[i])exteriorRenderers[i].enabled=visible&&exteriorDefaults[i];if(rat)rat.SetExteriorVisible(visible);}
 public void SetEvacuationVisible(bool visible){EmergencySlides.For(this).SetVisible(visible);}
 void CacheExteriorRenderers(){var renderers=new List<Renderer>();renderers.AddRange(model.GetComponentsInChildren<Renderer>(true));if(Fans)renderers.AddRange(Fans.GetComponentsInChildren<Renderer>(true));if(gearRoot)renderers.AddRange(gearRoot.GetComponentsInChildren<Renderer>(true));exteriorRenderers=renderers.ToArray();exteriorDefaults=new bool[exteriorRenderers.Length];for(int i=0;i<exteriorRenderers.Length;i++)exteriorDefaults[i]=exteriorRenderers[i].enabled;}
 void CacheGroundClearance(){
  var body=new List<Vector3>();var gear=new List<Vector3>();
  foreach(var renderer in model.GetComponentsInChildren<Renderer>(true))CacheContactPoints(renderer,IsGear(renderer.transform)?gear:body);
  if(gearRoot)foreach(var renderer in gearRoot.GetComponentsInChildren<Renderer>(true))CacheContactPoints(renderer,gear);
  if(body.Count==0)body.AddRange(gear);
  bodyContactPoints=body.ToArray();gearContactPoints=gear.ToArray();
  float minimum=0;foreach(var point in bodyContactPoints)minimum=Mathf.Min(minimum,point.y);
  GearUpClearance=Mathf.Max(.5f,-minimum+.15f);
  foreach(var point in gearContactPoints)minimum=Mathf.Min(minimum,point.y);
  GearDownClearance=Mathf.Max(GearUpClearance,-minimum+.15f);
 }
 bool IsGear(Transform part){foreach(var go in gears)if(go&&part.IsChildOf(go.transform))return true;return false;}
 void CacheContactPoints(Renderer renderer,List<Vector3> points){var bounds=renderer.localBounds;for(int x=-1;x<=1;x+=2)for(int y=-1;y<=1;y+=2)for(int z=-1;z<=1;z+=2)points.Add(transform.InverseTransformPoint(renderer.transform.TransformPoint(bounds.center+Vector3.Scale(bounds.extents,new Vector3(x,y,z)))));}
 void LateUpdate(){foreach(var g in gears)if(g)g.SetActive(Aircraft.Gear);}
}
}
