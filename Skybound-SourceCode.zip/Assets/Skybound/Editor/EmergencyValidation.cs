#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using UnityEngine;

namespace Skybound.Editor {
public static class EmergencyValidation {
 // Checks failure timing, controller enforcement and clean retries in Play Mode.
 // It leaves a fresh paused New York free flight; landing outcomes are separate tests.
 public static string Run(SkyboundBootstrap b){
  if(!b||!b.Mission||!b.Aircraft||!b.HUD)throw new InvalidOperationException("A running Skybound scene is required.");
  foreach(var key in new[]{KeyCode.LeftShift,KeyCode.RightShift,KeyCode.LeftControl,KeyCode.RightControl,KeyCode.Q,KeyCode.C,KeyCode.Space})if(FlightInput.Hold(key))throw new InvalidOperationException("Release "+key+" before emergency validation.");
  var m=b.Mission;var a=b.Aircraft;var checks=new List<string>();CheckIsolatedController(checks);Time.timeScale=0;
  try {
   m.StartFlight(FlightMode.FreeFlight,40.773,-73.998,"New York",false);
   float clearStart=RenderSettings.fogStartDistance,clearEnd=RenderSettings.fogEndDistance;
   m.StartFlight(FlightMode.SingleEngine,0,0,"",false);a.Elapsed=7.99f;m.SendMessage("Update");
   Require(a.LeftEngine&&a.RightEngine,"Single-engine failure happened before eight seconds.");
   a.Elapsed=8.01f;m.SendMessage("Update");Require(!a.LeftEngine&&a.RightEngine&&a.Engines,"Single-engine trigger did not leave the right engine available.");
   Require(m.Message.Contains("LEFT ENGINE FAILURE"),"Single-engine trigger notice is missing.");m.Message="";m.SendMessage("Update");Require(m.Message=="","Single-engine notice repeated after activation.");
   m.StartFlight(FlightMode.SingleEngine,0,0,"",false);Require(a.LeftEngine&&a.RightEngine&&a.Engines,"Single-engine retry retained an engine failure.");
   checks.Add("Single-engine failure activates once at eight seconds, retains one engine, and resets on retry.");

   m.StartFlight(FlightMode.FuelEmergency,0,0,"",false);Require(Mathf.Abs(a.FuelRemaining-.02f)<.0001f,"Low-fuel reserve was not configured.");
   a.FuelRemaining=.00002f;for(int i=0;i<20;i++)a.Step(.02f,0,0);m.SendMessage("Update");
   Require(a.FuelRemaining==0&&!a.Engines,"Fuel exhaustion did not shut down engine thrust.");Require(m.Message.Contains("FUEL EXHAUSTED"),"Fuel exhaustion notice is missing.");
   checks.Add("Low-fuel scenario configures its reserve; actual controller steps exhaust it, shut down engines and announce the glide.");

   m.StartFlight(FlightMode.GearFailure,0,0,"",false);a.Elapsed=5.99f;m.SendMessage("Update");Require(!a.GearJammedUp,"Gear jam activated before six seconds.");
   a.Elapsed=6.01f;m.SendMessage("Update");Require(a.GearJammedUp&&!a.Gear&&a.Flaps==2,"Gear jam did not retract the gear and command full flaps.");
   a.Gear=true;a.Step(.02f,0,0);Require(!a.Gear,"Controller allowed jammed gear to be lowered.");
   checks.Add("Gear fault activates at six seconds, selects full flaps, and the controller prevents lowering the jammed gear.");

   m.StartFlight(FlightMode.SevereWeather,0,0,"",false);Require(a.Wind==12&&a.GustStrength==10,"Severe-weather wind and gusts were not configured.");
   Require(RenderSettings.fogEndDistance<clearEnd&&RenderSettings.fogStartDistance<clearStart,"Severe-weather visibility was not reduced.");
   a.Elapsed=1.1f;float firstWind=a.GustWind;a.Elapsed=2.6f;Require(Mathf.Abs(a.GustWind-firstWind)>.01f,"Severe-weather crosswind is not varying.");
   Require(!float.IsNaN(m.AssistedHeading()),"Gust-corrected approach heading is invalid.");
   checks.Add("Severe-weather approach has a varying crosswind, reduced visibility and a valid gust-corrected heading.");

   m.StartFlight(FlightMode.FreeFlight,40.773,-73.998,"New York",false);
   Require(a.Engines&&a.LeftEngine&&a.RightEngine&&a.FuelRemaining==1&&!a.GearJammedUp&&a.GustStrength==0&&a.Wind==0,"Free flight retained an emergency state.");
   Require(Mathf.Abs(RenderSettings.fogStartDistance-clearStart)<.01f&&Mathf.Abs(RenderSettings.fogEndDistance-clearEnd)<.01f,"Clear visibility was not restored after severe weather.");
   Require(!m.Finished&&!m.Success&&m.Mode==FlightMode.FreeFlight,"The next flight retained a finished scenario.");
   checks.Add("The next free flight resets engines, fuel, gear jam, wind, gusts, scenario results and clear visibility.");
   string result="SKYBOUND_EMERGENCY_STATES_PASSED\n"+string.Join("\n",checks)+"\nFailure/reset logic tested; these checks do not claim successful landings or native-device UI validation.";Debug.Log(result);return result;
  } finally {
   m.StartFlight(FlightMode.FreeFlight,40.773,-73.998,"New York",false);a.Active=false;Time.timeScale=0;b.HUD.Menu=MenuPage.Discover;b.CameraRig.Discover=true;
  }
 }
 static void CheckIsolatedController(List<string> checks){
  var go=new GameObject("Isolated emergency controller validation"){hideFlags=HideFlags.HideAndDontSave};
  try {
   var f=go.AddComponent<FlightController>();f.enabled=false;f.ResetFlight(2000,85,0,false);f.Assist=false;f.LeftEngine=false;
   f.Step(.02f,0,0);Require(f.LeftEnginePower>0&&f.LeftEnginePower<.65f&&f.RightEnginePower>.64f,"Failed engine power did not spool down independently.");
   for(int i=0;i<60;i++)f.Step(.02f,0,0);
   Require(f.LeftEnginePower==0&&f.RightEnginePower>.64f&&Mathf.Abs(f.EnginePower-.325f)<.002f,"Single-engine thrust contribution is not half of the healthy pair.");
   Require(Mathf.DeltaAngle(0,f.Heading)<-.1f,"Unequal engine thrust did not produce asymmetric yaw.");
   checks.Add("Isolated failed engine spools down independently, halves pair thrust and produces asymmetric yaw.");

   f.ResetFlight(2000,85,0,false);f.FuelRemaining=.00002f;for(int i=0;i<20;i++)f.Step(.02f,0,0);
   Require(f.FuelRemaining==0&&!f.Engines,"Isolated fuel exhaustion did not shut down engines.");for(int i=0;i<100;i++)f.Step(.02f,0,0);
   Require(f.LeftEnginePower==0&&f.RightEnginePower==0&&f.EnginePower==0,"Engine spool did not decay after fuel exhaustion.");
   checks.Add("Isolated fuel exhaustion shuts down both engines and their residual spool decays to zero.");

   f.ResetFlight(2000,85,0,false);f.GearJammedUp=true;f.Gear=true;f.Step(.02f,0,0);Require(!f.Gear,"Isolated controller did not enforce jammed-up gear.");
   f.LeftEngine=f.RightEngine=f.Engines=false;f.FuelRemaining=0;f.Wind=12;f.GustStrength=10;f.ResetFlight(2000,85,0,false);
   Require(f.Engines&&f.LeftEngine&&f.RightEngine&&f.FuelRemaining==1&&!f.GearJammedUp&&!f.Gear&&f.Wind==0&&f.GustStrength==0,"Controller reset retained an emergency state.");
   checks.Add("Isolated jam enforcement and reset clear engine failures, empty fuel, gear jam, wind and gusts.");
  } finally {UnityEngine.Object.DestroyImmediate(go);}
 }
 static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
}
}
#endif
