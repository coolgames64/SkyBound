#if UNITY_EDITOR
using System;
using System.Collections;
using System.Globalization;
using System.IO;
using System.Text;
using UnityEngine;

namespace Skybound.Editor {
// Advances the real controller/mission. Position, attitude and velocity are never reset after the initial spawn.
public static class RunwayApproachValidation {
 const float Dt=.02f;
 const string CompletionKey="Skybound.CompletedChallenges.v1";
 static readonly KeyCode[] Keys={KeyCode.LeftShift,KeyCode.RightShift,KeyCode.LeftControl,KeyCode.RightControl,KeyCode.Q,KeyCode.C,KeyCode.Space};
 public static IEnumerator Run(SkyboundBootstrap b){
  foreach(var key in Keys)Require(!FlightInput.Hold(key),"Release "+key+" before the actual takeoff/entry validation.");
  var report=new StringBuilder("Actual runway takeoff and approach-entry trajectory\n");var trace=new StringBuilder("mode,seconds,phase,x,y,z,airspeed,heading,pitch,roll,AGL,entryDistance,entryHeightError,entryHeadingError,emergencySeconds\n");
  var m=b.Mission;var a=b.Aircraft;var previous=m.CurrentChallenge?.Copy();var oldMode=m.Mode;bool oldRunway=m.RunwayStartMode,oldAssist=a.Assist;double oldLat=b.World.Latitude,oldLon=b.World.Longitude;string oldPlace=m.Place;
  bool hadCompleted=PlayerPrefs.HasKey(CompletionKey);string oldCompleted=PlayerPrefs.GetString(CompletionKey,"");bool passed=false;
  b.HUD.Visual.Select(0);while(b.HUD.Visual.Loading)yield return null;b.CameraRig.Cockpit=b.CameraRig.Cabin=false;
  try{
   m.StartFlight(FlightMode.FreeFlight,51.4647,-.4085,"London Heathrow",true,true);b.HUD.Menu=MenuPage.Flight;a.Active=false;Time.timeScale=0;
   yield return WaitForGround(b);float departureSeconds=0;
   for(int i=0;i<9000&&m.WaitingForTakeoff&&!m.Finished;i++){
    Advance(b);departureSeconds=a.Elapsed;
    if(i%200==0){Trace(trace,m,a);yield return Stream(b);}
   }
   Require(!m.Finished&&!m.WaitingForTakeoff&&!a.Grounded&&a.HeightAboveGround>a.GroundClearance+15,"FreeFlight did not actually take off: "+State(m,a));
   report.AppendLine($"PASS free-flight takeoff from {m.DepartureRunway}: {departureSeconds:F2}s, speed={a.Speed:F2}m/s, altitudeAGL={a.HeightAboveGround:F2}m, pitch={a.Pitch:F2}deg.");
   var challenge=ChallengeCatalog.CreateDefault(FlightMode.Glide);m.StartChallenge(challenge,true,true);a.Active=false;Time.timeScale=0;yield return WaitForGround(b);
   float liftoff=-1,armed=-1,closest=float.PositiveInfinity,closestHeading=0,closestHeight=0;bool everAirborne=false;
   for(int i=0;i<40000&&!m.Finished;i++){
    Advance(b);if(!a.Grounded)everAirborne=true;if(liftoff<0&&!m.WaitingForTakeoff)liftoff=a.Elapsed;
    float distance=Horizontal(m.ChallengeEntry-a.transform.position);if(m.PreparingChallenge&&distance<closest){closest=distance;closestHeading=Mathf.Abs(Mathf.DeltaAngle(a.Heading,m.EntryHeading));closestHeight=Mathf.Abs(a.Altitude-m.ChallengeEntry.y);}
    if(armed<0&&!m.PreparingChallenge&&!m.WaitingForTakeoff){armed=a.Elapsed;report.AppendLine($"Entry armed at {armed:F2}s: speed={a.Speed:F2}m/s, height={a.Altitude:F2}m, pitch={a.Pitch:F2}deg, heading error={Mathf.Abs(Mathf.DeltaAngle(a.Heading,m.EntryHeading)):F2}deg.");}
    if(i%200==0){Trace(trace,m,a);yield return Stream(b);}
   }
   Trace(trace,m,a);report.AppendLine($"Glide: liftoff={liftoff:F2}s, armed={armed:F2}s, finished={m.Finished}, success={m.Success}, seconds={a.Elapsed:F2}, closest entry={closest:F2}m / height error={closestHeight:F2}m / heading error={closestHeading:F2}deg, sink={m.LandingSink:F3}m/s, landing speed={m.LandingSpeed:F2}kt, bank={m.LandingBank:F3}deg, result={m.Result}");
   Require(everAirborne&&liftoff>0,"Challenge never took off: "+State(m,a));Require(armed>liftoff,"Aircraft did not reach an aligned approach entry: "+State(m,a));Require(m.Finished&&m.Success,"Actual runway-to-entry glide did not finish successfully: "+State(m,a));
   report.AppendLine("PASS actual ground takeoff, streamed preparation route, approach-entry activation and completed glide landing without position/velocity teleports.");passed=true;
  }finally{
   if(hadCompleted)PlayerPrefs.SetString(CompletionKey,oldCompleted);else PlayerPrefs.DeleteKey(CompletionKey);PlayerPrefs.Save();
   File.WriteAllText(Path.Combine(Application.dataPath,"../../runway-approach-validation.txt"),report.ToString());File.WriteAllText(Path.Combine(Application.dataPath,"../../runway-approach-trace.csv"),trace.ToString());
   if(previous!=null)m.StartChallenge(previous,oldAssist,oldRunway);else m.StartFlight(oldMode,oldLat,oldLon,oldPlace,oldAssist,oldRunway);a.Active=false;Time.timeScale=0;b.HUD.Menu=MenuPage.Discover;b.CameraRig.Discover=true;
   Debug.Log("SKYBOUND_RUNWAY_APPROACH_COMPLETE passed="+passed+" "+report);
  }
 }
 public static IEnumerator RunRemainingChallenges(SkyboundBootstrap b){
  foreach(var key in Keys)Require(!FlightInput.Hold(key),"Release "+key+" before the remaining actual runway approaches.");
  var report=new StringBuilder("Actual runway-to-entry approaches: remaining six default challenges\n");var trace=new StringBuilder("mode,seconds,phase,x,y,z,airspeed,heading,pitch,roll,AGL,entryDistance,entryHeightError,entryHeadingError,emergencySeconds\n");
  var m=b.Mission;var a=b.Aircraft;var previous=m.CurrentChallenge?.Copy();var oldMode=m.Mode;bool oldRunway=m.RunwayStartMode,oldAssist=a.Assist;double oldLat=b.World.Latitude,oldLon=b.World.Longitude;string oldPlace=m.Place;
  bool hadCompleted=PlayerPrefs.HasKey(CompletionKey);string oldCompleted=PlayerPrefs.GetString(CompletionKey,"");int failures=0,completed=0;
  b.HUD.Visual.Select(0);while(b.HUD.Visual.Loading)yield return null;b.CameraRig.Cockpit=b.CameraRig.Cabin=false;
  try{
   foreach(var mode in new[]{FlightMode.Hudson,FlightMode.Crosswind,FlightMode.SingleEngine,FlightMode.FuelEmergency,FlightMode.GearFailure,FlightMode.SevereWeather}){
    m.StartChallenge(ChallengeCatalog.CreateDefault(mode),true,true);b.HUD.Menu=MenuPage.Flight;a.Active=false;Time.timeScale=0;yield return WaitForGround(b);
    float liftoff=-1,armed=-1,closest=float.PositiveInfinity;bool failedSurface=false;
    for(int i=0;i<60000&&!m.Finished;i++){
     Advance(b);if(liftoff<0&&!m.WaitingForTakeoff)liftoff=a.Elapsed;
     if(m.PreparingChallenge)closest=Mathf.Min(closest,Horizontal(m.ChallengeEntry-a.transform.position));
     if(armed<0&&!m.PreparingChallenge&&!m.WaitingForTakeoff){armed=a.Elapsed;report.AppendLine($"{mode} entry at {armed:F2}s: speed={a.Speed:F2}m/s, altitude={a.Altitude:F2}m, pitch={a.Pitch:F2}deg, heading error={Mathf.Abs(Mathf.DeltaAngle(a.Heading,m.EntryHeading)):F2}deg.");}
     if(i%200==0){Trace(trace,m,a);a.SendMessage("LateUpdate");b.World.SendMessage("RefreshTiles");yield return null;float deadline=Time.realtimeSinceStartup+30;
      while((!b.World.SurfaceLoaded(a.transform.position)||!b.World.ElevationLoadedAt(a.transform.position))&&Time.realtimeSinceStartup<deadline)yield return null;
      if(!b.World.SurfaceLoaded(a.transform.position)||!b.World.ElevationLoadedAt(a.transform.position)){failedSurface=true;report.AppendLine(mode+" scenery timeout: "+State(m,a));break;}
     }
    }
    Trace(trace,m,a);bool success=!failedSurface&&liftoff>0&&armed>liftoff&&m.Finished&&m.Success;completed++;if(!success)failures++;
    string line=$"{mode}: passed={success}, takeoff={liftoff:F2}s, entry={armed:F2}s, finished={m.Finished}, success={m.Success}, seconds={a.Elapsed:F2}, closest entry={closest:F2}m, landing speed={m.LandingSpeed:F2}kt, sink={m.LandingSink:F3}m/s, bank={m.LandingBank:F3}deg, pitch={a.Pitch:F3}deg, result={m.Result}";
    report.AppendLine(line);Debug.Log("SKYBOUND_GROUND_APPROACH "+line);a.Active=false;Time.timeScale=0;
    File.WriteAllText(Path.Combine(Application.dataPath,"../../runway-remaining-validation.txt"),report.ToString());
   }
   report.AppendLine("Completed trajectories: "+completed+"; failed trajectories: "+failures+". All flights used actual controller/mission steps after their initial runway spawn.");
  }finally{
   if(hadCompleted)PlayerPrefs.SetString(CompletionKey,oldCompleted);else PlayerPrefs.DeleteKey(CompletionKey);PlayerPrefs.Save();
   File.WriteAllText(Path.Combine(Application.dataPath,"../../runway-remaining-validation.txt"),report.ToString());File.WriteAllText(Path.Combine(Application.dataPath,"../../runway-remaining-trace.csv"),trace.ToString());
   if(previous!=null)m.StartChallenge(previous,oldAssist,oldRunway);else m.StartFlight(oldMode,oldLat,oldLon,oldPlace,oldAssist,oldRunway);a.Active=false;Time.timeScale=0;b.HUD.Menu=MenuPage.Discover;b.CameraRig.Discover=true;
   Debug.Log("SKYBOUND_REMAINING_RUNWAY_APPROACHES_COMPLETE completed="+completed+" failures="+failures+" "+report);
  }
  Require(completed==6&&failures==0,"Remaining runway approaches failed: "+failures+" of "+completed+". See runway-remaining-validation.txt and runway-remaining-trace.csv.");
 }
 static void Advance(SkyboundBootstrap b){b.Aircraft.Active=true;b.Aircraft.Step(Dt,0,0);b.Mission.SendMessage("Update");b.Aircraft.Active=false;Time.timeScale=0;}
 static IEnumerator WaitForGround(SkyboundBootstrap b){float deadline=Time.realtimeSinceStartup+42;while(!b.Mission.GroundStartReady&&Time.realtimeSinceStartup<deadline){b.Aircraft.Active=false;yield return null;}b.Aircraft.Active=false;Require(b.Mission.GroundStartReady&&b.World.SurfaceLoaded(b.Aircraft.transform.position)&&b.World.ElevationLoadedAt(b.Aircraft.transform.position),"Runway surface did not load.");}
 static IEnumerator Stream(SkyboundBootstrap b){b.Aircraft.Active=false;b.Aircraft.SendMessage("LateUpdate");b.World.SendMessage("RefreshTiles");yield return null;float deadline=Time.realtimeSinceStartup+30;while((!b.World.SurfaceLoaded(b.Aircraft.transform.position)||!b.World.ElevationLoadedAt(b.Aircraft.transform.position))&&Time.realtimeSinceStartup<deadline)yield return null;Require(b.World.SurfaceLoaded(b.Aircraft.transform.position)&&b.World.ElevationLoadedAt(b.Aircraft.transform.position),"Scenery timeout along the actual flight route: "+State(b.Mission,b.Aircraft));}
 static float Horizontal(Vector3 v){v.y=0;return v.magnitude;}
 static string State(MissionDirector m,FlightController a)=>$"phase={Phase(m)}, seconds={a.Elapsed:F2}, position={a.transform.position}, speed={a.Speed:F2}, pitch={a.Pitch:F2}, bank={a.Roll:F2}, AGL={a.HeightAboveGround:F2}, entry distance={Horizontal(m.ChallengeEntry-a.transform.position):F2}, entry altitude error={Mathf.Abs(a.Altitude-m.ChallengeEntry.y):F2}, entry heading error={Mathf.Abs(Mathf.DeltaAngle(a.Heading,m.EntryHeading)):F2}, result={m.Result}";
 static string Phase(MissionDirector m)=>m.Finished?"finished":m.WaitingForTakeoff?"takeoff":m.PreparingChallenge?"entry":"armed";
 static void Trace(StringBuilder trace,MissionDirector m,FlightController a){var p=a.transform.position;string F(float f)=>f.ToString("F3",CultureInfo.InvariantCulture);trace.Append(m.Mode).Append(',').Append(F(a.Elapsed)).Append(',').Append(Phase(m)).Append(',').Append(F(p.x)).Append(',').Append(F(p.y)).Append(',').Append(F(p.z)).Append(',').Append(F(a.Speed)).Append(',').Append(F(a.Heading)).Append(',').Append(F(a.Pitch)).Append(',').Append(F(a.Roll)).Append(',').Append(F(a.HeightAboveGround)).Append(',').Append(F(Horizontal(m.ChallengeEntry-p))).Append(',').Append(F(p.y-m.ChallengeEntry.y)).Append(',').Append(F(Mathf.DeltaAngle(a.Heading,m.EntryHeading))).Append(',').Append(F(m.EmergencyElapsed)).AppendLine();}
 static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
}
}
#endif
