#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace Skybound.Editor {
public static class InteriorsValidation {
 public static IEnumerator Run(SkyboundBootstrap b){
  var a=b.Aircraft;var visual=b.HUD.Visual;var savedMission=a.Mission;var lines=new List<string>{"Skybound cockpit, passenger cabin and rotating engine validation"};bool complete=false;string stage="initialization";
  string output=Path.GetFullPath(Path.Combine(Application.dataPath,"../../interiors-validation.txt"));
  Time.timeScale=0;a.Active=false;a.Mission=null;b.HUD.Menu=MenuPage.Flight;b.CameraRig.Discover=false;b.CameraRig.Cockpit=true;b.CameraRig.Cabin=false;
  try {
   var includedDeck=b.Catalog.Aircraft[0].CockpitPrefab;if(!includedDeck)includedDeck=Resources.Load<GameObject>(b.Catalog.Aircraft[0].CockpitResourcePath);
   Require(includedDeck,"Included A320 cockpit resource is missing.");int deckComponents=includedDeck.GetComponentsInChildren<Component>(true).Length,deckRootComponents=includedDeck.GetComponents<Component>().Length;
   for(int i=0;i<b.Catalog.Aircraft.Length;i++){
    stage=b.Catalog.Aircraft[i].Name;visual.Select(i);float deadline=Time.realtimeSinceStartup+25;
    do{yield return null;}while(visual.Loading&&Time.realtimeSinceStartup<deadline);
    Require(!visual.Loading,"Selection timeout while cockpit view was active: "+stage);yield return null;
    Require(visual.gameObject.activeInHierarchy,"Cockpit view disabled the aircraft visual/loading owner.");
    Require(visual.HasCockpit&&visual.CockpitModel,"No pilot interior: "+stage);visual.SetCockpitVisible(true);visual.SetExteriorVisible(false);visual.PlaceInteriors(a.RenderPosition,a.RenderRotation);
    Require(!visual.UsesSharedCockpit&&visual.CockpitModel.name=="A320 flight deck","Included A320 cockpit was not used for "+stage);
    Require(visual.CockpitModel.GetComponents<Component>().Length==deckRootComponents&&visual.CockpitModel.GetComponentsInChildren<Component>(true).Length==deckComponents,"Imported A320 cockpit component counts changed for "+stage);
    Require((visual.CockpitModel.transform.localScale-Vector3.one).sqrMagnitude<.000001f,"A320 cockpit was stretched for "+stage);
    Require(visual.CockpitModel.activeInHierarchy&&VisibleRendererCount(visual.CockpitModel)>0,"Pilot interior is not rendered: "+stage);
    Require(VisibleRendererCount(visual.ExteriorModel)==0,"Exterior renderer did not hide in cockpit view: "+stage);
    visual.SetCabinVisible(true);Require(visual.HasCabin&&visual.CabinModel&&visual.CabinModel.activeInHierarchy,"Passenger cabin did not create lazily: "+stage);
    var cabin=visual.CabinModel.GetComponent<AircraftCabin>();Require(cabin&&cabin.SeatCount>=32,"Passenger seats are missing: "+stage);
    Require(VisibleRendererCount(visual.CabinModel)<=8,"Cabin material batching exceeded eight renderers: "+stage);
    Require(visual.CabinModel.GetComponentsInChildren<Collider>(true).Length==0,"Procedural cabin unexpectedly has collision components.");
    Require(visual.HasEngineFans&&visual.Fans.RotorCount>=2,"Rotating engine geometry missing: "+stage);
    float angle=visual.Fans.RotationFor(0);visual.Fans.SendMessage("Update");Require(Mathf.Abs(Mathf.DeltaAngle(angle,visual.Fans.RotationFor(0)))<.0001f,"Paused fan moved: "+stage);
    lines.Add($"PASS {stage}: cockpit=imported A320 flight deck at unscaled nose-relative position, cabin seats={cabin.SeatCount}, cabin renderers={VisibleRendererCount(visual.CabinModel)}, original/generated engine rotors={visual.Fans.OriginalRotorCount}/{visual.Fans.GeneratedRotorCount}; cockpit selection stays active and paused fans freeze");
    visual.SetCabinVisible(false);visual.SetCockpitVisible(false);visual.SetExteriorVisible(true);Require(VisibleRendererCount(visual.ExteriorModel)>0,"Exterior did not restore: "+stage);
   }
   visual.Select(0);while(visual.Loading)yield return null;yield return null;
   stage="Independent engine spool and visible rotation";b.CameraRig.Cockpit=false;b.CameraRig.Cabin=false;visual.SetCockpitVisible(false);visual.SetCabinVisible(false);visual.SetExteriorVisible(true);
   a.ResetFlight(2000,80,0,false);a.LeftEngine=true;a.RightEngine=false;a.Engines=true;a.Throttle=1;Time.timeScale=1;
   var fans=visual.Fans;int left=-1,right=-1;for(int i=0;i<fans.RotorCount;i++){if(fans.LocalPositionFor(i).x<-.1f)left=i;if(fans.LocalPositionFor(i).x>.1f)right=i;}
   Require(left>=0&&right>=0,"A320 engine-side binding is missing.");float before=fans.RotationFor(left);
   for(int i=0;i<160;i++){a.Step(.02f,0,0);yield return null;}
   Require(Mathf.Abs(Mathf.DeltaAngle(before,fans.RotationFor(left)))>.05f,"Powered fan did not visibly rotate in running time.");
   Require(a.LeftEnginePower>.8f&&a.RightEnginePower<.05f&&fans.VisualSpeedFor(left)>fans.VisualSpeedFor(right)+20,"Engine fans did not follow their individual engine spool.");
   lines.Add($"PASS separate-engine fan response: left/right N1={a.LeftEnginePower:F3}/{a.RightEnginePower:F3}, presentation speeds={fans.VisualSpeedFor(left):F2}/{fans.VisualSpeedFor(right):F2} degrees/s");
   a.Engines=false;a.LeftEngine=a.RightEngine=false;for(int i=0;i<120;i++)a.Step(.02f,0,0);a.Speed=0;a.Grounded=true;
   float windDownUntil=Time.realtimeSinceStartup+2;while(Time.realtimeSinceStartup<windDownUntil){a.Speed=0;a.Step(.02f,0,0);yield return null;}
   Require(fans.VisualSpeedFor(left)<15&&fans.VisualSpeedFor(right)<15,"Stopped aircraft's failed engines did not wind down.");
   Time.timeScale=0;float stopped=fans.RotationFor(left);fans.SendMessage("Update");Require(Mathf.Abs(Mathf.DeltaAngle(stopped,fans.RotationFor(left)))<.0001f,"Pause did not freeze the engine rotors.");
   lines.Add($"PASS engine wind-down at zero airspeed: left/right fan speeds={fans.VisualSpeedFor(left):F2}/{fans.VisualSpeedFor(right):F2} degrees/s; pause freezes rotation");
   complete=true;Debug.Log("SKYBOUND_INTERIORS_PASSED "+string.Join("; ",lines));
  }finally {
   if(!complete)lines.Add("FAIL during "+stage+"; see the Editor exception for the exact assertion.");File.WriteAllLines(output,lines);
   Time.timeScale=0;a.Mission=savedMission;a.ResetFlight(650,85,208,false);b.CameraRig.Cockpit=b.CameraRig.Cabin=false;b.CameraRig.Discover=true;b.HUD.Menu=MenuPage.Discover;visual.SetCabinVisible(false);visual.SetCockpitVisible(false);visual.SetExteriorVisible(true);if(visual.Selected!=0)visual.Select(0);
  }
 }
 static int VisibleRendererCount(GameObject root){if(!root)return 0;int count=0;foreach(var r in root.GetComponentsInChildren<Renderer>(false))if(r.enabled&&r.gameObject.activeInHierarchy)count++;return count;}
 static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
}
}
#endif
