#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

namespace Skybound.Editor {
// Runs the existing validators through a single owner. Nested iterators are
// advanced here so assertions cannot disappear in child Unity coroutines.
[InitializeOnLoad]
public static class FullRegressionValidation {
 public static bool Running {get;private set;}
 public static string CurrentStage {get;private set;}="";
 public static string ReportPath=>Path.GetFullPath(Path.Combine(Application.dataPath,"../../full-regression-validation.txt"));
 static string BackupPath=>Path.GetFullPath(Path.Combine(Application.dataPath,"../Temp/SkyboundRegressionPreferences.json"));
 static readonly string[] PreferenceKeys={AircraftDesignStore.PreferenceKey,"Skybound.CustomChallenges.v1","Skybound.CompletedChallenges.v1"};
 static bool cancelRequested;
 static PreferenceBackup activeBackup;
 [Serializable]class PreferenceValue {public string Key,Value;public bool Existed;}
 [Serializable]class PreferenceBackup {public List<PreferenceValue> Items=new List<PreferenceValue>();}
 class Stage {
  public string Name;public Func<IEnumerator> Execute;public bool NeedsDryLand;public float Timeout;
  public Stage(string name,Func<IEnumerator> execute,bool dry=true,float timeout=300){Name=name;Execute=execute;NeedsDryLand=dry;Timeout=timeout;}
 }
 class Result {public string Name,Status="NOT RUN",Error="";public float Seconds;public StringBuilder Details=new StringBuilder();}
 class Session {
  public int AircraftIndex;public AircraftDesign Design;public ChallengeDefinition Challenge;public FlightMode Mode;public double Latitude,Longitude;public string Place;public bool Runway,Assist,Elevation;
  public Dictionary<FieldInfo,object> HUD,Camera;
 }
 static FullRegressionValidation(){
  EditorApplication.playModeStateChanged+=state=>{if(state==PlayModeStateChange.ExitingPlayMode||state==PlayModeStateChange.EnteredEditMode)InterruptedRecovery();};
  AssemblyReloadEvents.beforeAssemblyReload+=InterruptedRecovery;
  InterruptedRecovery();
 }
 public static void Cancel(){cancelRequested=true;}
 public static IEnumerator Run(SkyboundBootstrap b){
  Require(Application.isPlaying&&b&&b.Aircraft&&b.Mission&&b.HUD&&b.HUD.Visual&&b.World,"Open the Skybound scene in Play Mode before running the full regression.");
  Require(!Running,"The full regression is already running.");
  var session=Capture(b);var results=new List<Result>();var console=new List<string>();var devices=DeviceIds();
  var report=new StringBuilder("Skybound comprehensive regression\n");DateTime started=DateTime.UtcNow;bool restored=false;int warningCount=0;
  report.AppendLine("Started UTC: "+started.ToString("O"));report.AppendLine("Unity: "+Application.unityVersion+"; target: "+EditorUserBuildSettings.activeBuildTarget+"; scene: "+SceneManager.GetActiveScene().path);
  report.AppendLine("Captured selection: "+SelectionDetails(b.HUD.Visual,session));
  report.AppendLine("Scope: managed input/commands, fleet geometry, creator persistence, phase/rule checks, actual airborne approaches and actual runway-to-entry flights. Rendering and native phone/hardware input need separate capture/device evidence.");
  report.AppendLine("Each stage gets a fresh paused flight. Persistent creation/completion JSON is restored exactly, including on Play Mode exit or assembly reload. Simulation progress is replaced by a clean paused start at the original mission/location; it is not a live-flight resume.");
  activeBackup=CapturePreferences();Directory.CreateDirectory(Path.GetDirectoryName(BackupPath));File.WriteAllText(BackupPath,JsonUtility.ToJson(activeBackup));
  Running=true;cancelRequested=false;
  Application.LogCallback logs=(message,stack,type)=>{if(type==LogType.Warning)warningCount++;if(type==LogType.Error||type==LogType.Exception||type==LogType.Assert)console.Add(CurrentStage+" | "+type+" | "+message+"\n"+Trim(stack,1800));};
  Application.logMessageReceived+=logs;
  var stages=new List<Stage>{
   new Stage("Departure contact phase acceptance/rejection",()=>DepartureContactValidation.Run(b),true,600),
   new Stage("Fleet, managed controller/camera and interpolation samples",()=>RuntimeValidation.Audit(b),true,600),
   new Stage("Managed mobile/left-drag camera and joystick",()=>Sync(()=>RuntimeValidation.ValidateMobile(b),report)),
   new Stage("Independent mouse/touch thrust, flaps and camera exclusion",()=>Sync(()=>SideControlsValidation.Run(b),report)),
   new Stage("Managed brake, relight and jammed-control input",()=>Sync(()=>AuxiliaryControlsValidation.Run(b),report)),
   new Stage("Bounded aerodynamic handling and timestep consistency",()=>Sync(()=>Skybound.EditorTools.HandlingValidation.Run(),report),false),
   new Stage("Engine/fuel/jam/reset emergency state",()=>Sync(()=>EmergencyValidation.Run(b),report)),
   new Stage("Landing-rule acceptance and rejection on streamed dry land",()=>Sync(()=>LandingRuleValidation.Run(b),report)),
   new Stage("Curated challenge definitions, persistence and custom event timing",()=>Sync(()=>ChallengeValidation.Run(b),report)),
   new Stage("All included stopped runway configurations and synthetic entry rules",()=>AllGroundDefinitions(b,report),false,300),
   new Stage("Distinct new mechanic triggers, locks, goal boundaries and retry",()=>DistinctChallengeValidation.Run(b),true,600),
   new Stage("Aircraft design store, tuning, base capabilities and async selection",()=>AircraftDesignValidation.Run(b),true,600),
   new Stage("Creator form command save/reload/edit/delete/launch/retry",()=>CreatorFlowValidation.Run(b),true,600),
   new Stage("All23 cockpits/cabins, engine fans and presentation cleanup",()=>InteriorsValidation.Run(b),true,600),
   new Stage("Detailed cabin anatomy, model placement and material/lighting state",()=>CabinVisualValidation.Run(b),true,600),
   new Stage("RAT availability/output and slide deployment/reset",()=>SafetySystemsValidation.Run(b)),
   new Stage("All23 airframe ground contact plus free-flight landing",()=>GroundContactValidation.Run(b),true,600),
   new Stage("Global runway selection, surface seating and staged fault timing",()=>RunwayStartValidation.Run(b),true,300),
   new Stage("Normal FixedUpdate Hudson departures with live terrain streaming",()=>DepartureContactValidation.RunRealtime(b),true,600),
   new Stage("All7 actual airborne assisted approach trajectories",()=>AirborneApproaches(b,report),true,900),
   new Stage("Actual free-flight takeoff and complete ground-to-entry Glide",()=>RunwayApproachValidation.Run(b),true,1500),
   new Stage("Actual ground-to-entry Hudson and remaining five emergency landings",()=>RunwayApproachValidation.RunRemainingChallenges(b),true,3000),
   new Stage("All13 actual new challenge runway routes and objective completion",()=>DistinctChallengeValidation.RunActual(b),true,3600)
  };
  try {
   for(int i=0;i<stages.Count;i++){
    if(cancelRequested)break;
    var stage=stages[i];var result=new Result{Name=stage.Name};results.Add(result);CurrentStage=stage.Name;
    report.AppendLine("\nSTART "+(i+1)+" / "+stages.Count+": "+stage.Name);Save(report,results,console,warningCount,false);
    int errorsBefore=console.Count;yield return ExecuteIsolated(b,stage,result,report);
    if(console.Count>errorsBefore&&result.Status=="PASS"){result.Status="FAIL";result.Error="New Console error/assert/exception messages occurred during this stage; see the Console section.";}
    Save(report,results,console,warningCount,false);Debug.Log("SKYBOUND_REGRESSION_STAGE "+result.Status+" "+result.Name+" realSeconds="+result.Seconds.ToString("F2")+(result.Error.Length>0?" "+result.Error:""));
   }
   for(int i=results.Count;i<stages.Count;i++)results.Add(new Result{Name=stages[i].Name,Status="NOT RUN",Error="Run cancelled before this stage."});
   CurrentStage="Restore original preferences and paused session";
   var restore=new Result{Name=CurrentStage};results.Add(restore);
   // Cancellation must still permit the model/surface restoration to finish.
   bool cancelled=cancelRequested;cancelRequested=false;
   var restoreStage=new Stage(CurrentStage,()=>RestoreSession(b,session),false,120);
   yield return ExecuteIterator(restoreStage,restore,report);restored=restore.Status=="PASS";cancelRequested=cancelled;
  } finally {
   Application.logMessageReceived-=logs;
   for(int i=results.Count;i<stages.Count;i++)results.Add(new Result{Name=stages[i].Name,Status="NOT RUN",Error="Run interrupted before this stage completed."});
   try{RecoverPreferences();RequirePreferencesRestored();activeBackup=null;}catch(Exception ex){results.Add(new Result{Name="Final preference recovery",Status="FAIL",Error=ex.ToString()});}
   RemoveAddedDevices(devices);PauseAndRelease(b);
   if(!restored)RestoreImmediate(b,session);
   Running=false;CurrentStage="";
   report.AppendLine("\nFinished UTC: "+DateTime.UtcNow.ToString("O"));report.AppendLine("Limitations: physical joystick/mobile devices, player-build launch, frame-rate budgets and visual cabin/GUI quality are not certified by this runner. All "+ChallengeCatalog.BuiltIn.Count+" included configurations receive synthetic phase checks; seven legacy and13 distinct new challenges receive complete ground-route/objective trajectories in separate stages. Managed command/input checks do not certify rendered GUI clicks or native hardware.");
   Save(report,results,console,warningCount,true);
  }
  int failed=0;foreach(var result in results)if(result.Status!="PASS")failed++;
  if(failed>0||console.Count>0)Debug.LogError("SKYBOUND_FULL_REGRESSION_FAILED stages="+results.Count+" failedOrNotRun="+failed+" newConsoleErrors="+console.Count+" report="+ReportPath);
  else Debug.Log("SKYBOUND_FULL_REGRESSION_PASSED stages="+results.Count+" report="+ReportPath);
 }
 static IEnumerator ExecuteIsolated(SkyboundBootstrap b,Stage stage,Result result,StringBuilder report){
  var devices=DeviceIds();
  try{yield return ExecuteIterator(new Stage(stage.Name,()=>PreparedStage(b,stage),stage.NeedsDryLand,stage.Timeout),result,report);}
  finally{RemoveAddedDevices(devices);PauseAndRelease(b);b.Aircraft.Mission=b.Mission;b.Aircraft.World=b.World;b.HUD.Visual.Aircraft=b.Aircraft;}
 }
 static IEnumerator PreparedStage(SkyboundBootstrap b,Stage stage){yield return FreshFlight(b,stage.NeedsDryLand);yield return stage.Execute();}
 static IEnumerator ExecuteIterator(Stage stage,Result result,StringBuilder report){
  var stack=new Stack<IEnumerator>();float started=Time.realtimeSinceStartup,nextProgress=started+20;Exception failure=null;
  try{stack.Push(stage.Execute());}catch(Exception ex){failure=ex;}
  try {
   while(failure==null&&stack.Count>0){
    if(cancelRequested){failure=new OperationCanceledException("Regression cancelled; preferences and synthetic devices will be restored.");break;}
    if(Time.realtimeSinceStartup-started>stage.Timeout){failure=new TimeoutException("Stage exceeded its "+stage.Timeout+" second wall-time budget.");break;}
    bool moved=false;object current=null;
    try{moved=stack.Peek().MoveNext();if(moved)current=stack.Peek().Current;}
    catch(Exception ex){failure=ex;}
    if(failure!=null)break;
    if(!moved){var done=stack.Pop();try{(done as IDisposable)?.Dispose();}catch(Exception ex){failure=ex;}continue;}
    if(current is IEnumerator nested){stack.Push(nested);continue;}
    if(Time.realtimeSinceStartup>=nextProgress){nextProgress=Time.realtimeSinceStartup+20;Debug.Log("SKYBOUND_REGRESSION_RUNNING "+stage.Name+" realSeconds="+(Time.realtimeSinceStartup-started).ToString("F1"));File.WriteAllText(ReportPath,report.ToString()+"\nCURRENT: "+stage.Name+" (still running)\n");}
    yield return current;
   }
  } finally {
   while(stack.Count>0){try{(stack.Pop() as IDisposable)?.Dispose();}catch(Exception ex){if(failure==null)failure=ex;else result.Details.AppendLine("Additional cleanup exception: "+ex);}}
   result.Seconds=Time.realtimeSinceStartup-started;result.Status=failure==null?"PASS":cancelRequested?"CANCELLED":"FAIL";result.Error=failure==null?"":failure.ToString();
  }
 }
 static IEnumerator FreshFlight(SkyboundBootstrap b,bool dry){
  PauseAndRelease(b);b.Mission.StopAllCoroutines();b.Aircraft.Mission=b.Mission;b.Aircraft.World=b.World;b.HUD.Visual.Aircraft=b.Aircraft;b.World.Aircraft=b.Aircraft;
  b.HUD.Menu=MenuPage.Discover;b.HUD.MobileControls=b.HUD.MouseJoystick=b.HUD.LandingAssist=false;b.CameraRig.Discover=true;b.CameraRig.Cockpit=b.CameraRig.Cabin=false;b.HUD.Visual.gameObject.SetActive(true);
  b.HUD.Visual.Select(0);yield return WaitForModel(b.HUD.Visual);b.World.ElevationEnabled=true;
  // This explicitly clears all runway/entry/failure state before synthetic rules.
  b.HUD.BeginFlight(FlightMode.FreeFlight,51.4647,-.4340,"London Heathrow",false);b.Aircraft.Active=false;Time.timeScale=0;b.HUD.Menu=MenuPage.Discover;b.CameraRig.Discover=true;
  if(dry){float deadline=Time.realtimeSinceStartup+45;while((!b.World.SurfaceLoaded(Vector3.zero)||!b.World.ElevationLoadedAt(Vector3.zero))&&Time.realtimeSinceStartup<deadline)yield return null;Require(b.World.SurfaceLoaded(Vector3.zero)&&b.World.ElevationLoadedAt(Vector3.zero)&&!b.World.LooksLikeWater(Vector3.zero),$"Fresh Heathrow imagery/elevation did not provide a loaded dry-land origin: surface={b.World.SurfaceLoaded(Vector3.zero)}, elevation={b.World.ElevationLoadedAt(Vector3.zero)}, water={b.World.LooksLikeWater(Vector3.zero)}, imagery={b.World.LoadedTiles}, failedImagery={b.World.FailedTiles}, elevationTiles={b.World.ElevationTiles}, origin={b.World.Latitude},{b.World.Longitude}.");}
  Require(!b.Mission.WaitingForTakeoff&&!b.Mission.PreparingChallenge&&!b.Mission.Finished&&!b.Mission.RunwayStartMode,"Fresh airborne-free-flight setup retained a previous preparation/result state.");
  yield return null;
 }
 static IEnumerator Sync(Func<string> check,StringBuilder report){report.AppendLine(check());yield break;}
 static IEnumerator AllGroundDefinitions(SkyboundBootstrap b,StringBuilder report){
  int checkedCount=0;var m=b.Mission;var a=b.Aircraft;
  foreach(var d in ChallengeCatalog.BuiltIn){
   m.StartChallenge(d,false,true);a.Active=false;Time.timeScale=0;
   bool rejectedTakeoff=d.Mode==FlightMode.RejectedTakeoff;
   Require(m.RunwayStartMode&&m.WaitingForTakeoff&&m.PreparingChallenge==!rejectedTakeoff&&m.CurrentChallenge.Id==d.Id,"Runway definition did not preserve its identity/staging: "+d.Name);
   Require(a.Grounded&&a.Gear&&a.Flaps==1&&a.Speed==0&&a.Throttle==0&&a.EnginePower==0&&a.Engines&&a.LeftEngine&&a.RightEngine&&a.FuelRemaining==1&&!a.GearJammedUp,"Definition did not start stopped and healthy: "+d.Name);
   Require(!EmergencySlides.For(b.HUD.Visual).CanDeploy,"Definition allowed evacuation before departure: "+d.Name);
   a.Active=true;a.Elapsed=180;m.SendMessage("Update");a.Active=false;
   Require(m.WaitingForTakeoff&&m.EmergencyElapsed==0&&!m.FaultTriggered&&a.Engines&&a.LeftEngine&&a.RightEngine&&a.FuelRemaining==1,"Stopped taxi time started a fault/reserve loss: "+d.Name);
   if(rejectedTakeoff){Require(!m.PreparingChallenge&&!m.Finished,"Rejected takeoff invented an airborne approach phase.");m.StopAllCoroutines();checkedCount++;continue;}
   // Explicitly synthetic branch coverage; this is not a flown approach.
   a.Grounded=false;a.Speed=d.StartSpeed;a.Pitch=6;a.Heading=m.EntryHeading;a.transform.position=m.ChallengeEntry;a.Elapsed=181;a.Active=true;m.SendMessage("Update");a.Active=false;
   Require(!m.WaitingForTakeoff&&!m.PreparingChallenge&&m.EmergencyElapsed==0&&a.Pitch==6,"Aligned entry did not arm without an attitude snap: "+d.Name);
   Require(a.Throttle==d.Throttle&&a.FuelRemaining==d.Fuel&&a.Wind==d.Wind&&a.GustStrength==d.GustStrength&&a.Gear==d.InitialGear&&a.Flaps==d.InitialFlaps,"Saved entry conditions were lost: "+d.Name);
   Require(a.Engines==(d.Mode!=FlightMode.Glide)&&a.LeftEngine&&a.RightEngine&&!a.GearJammedUp&&!a.GearJammedDown&&!a.FlapsJammed&&!a.ThrottleJammed&&!m.FaultTriggered,"Entry began with an unintended failure: "+d.Name);
   m.StopAllCoroutines();checkedCount++;if(checkedCount%5==0)yield return null;
  }
  Require(checkedCount==ChallengeCatalog.BuiltIn.Count&&checkedCount==ChallengeCatalog.ExpectedCount,"Ground-phase coverage missed an included definition.");report.AppendLine("PASS all "+checkedCount+" included definitions: stopped healthy runway spawn, fault-free stopped taxi time, blocked slides, synthetic aligned entry applies saved conditions and preserves attitude. Rejected takeoff stays in its ground-only departure phase. These phase checks deliberately reposition the aircraft; flown routes and new objective-specific tests are separate evidence.");
 }
 static IEnumerator AirborneApproaches(SkyboundBootstrap b,StringBuilder report){
  DateTime before=DateTime.UtcNow;yield return ScenarioValidation.Run(b);string path=RecentReport("scenario-validation.txt",before);Require(path!=null&&File.ReadAllText(path).Contains("Failed approaches: 0"),"Airborne trajectory validator recorded a failed approach or did not write a fresh report.");report.AppendLine("PASS seven actual legacy airborne routes; detailed evidence: "+path);
 }
 static string RecentReport(string name,DateTime since){foreach(string directory in new[]{Directory.GetCurrentDirectory(),Path.GetFullPath(Path.Combine(Application.dataPath,"..")),Path.GetFullPath(Path.Combine(Application.dataPath,"../.."))}){string path=Path.Combine(directory,name);if(File.Exists(path)&&File.GetLastWriteTimeUtc(path)>=since.AddSeconds(-1))return path;}return null;}
 static IEnumerator WaitForModel(AircraftVisual visual){float deadline=Time.realtimeSinceStartup+35;do{yield return null;}while(visual.Loading&&Time.realtimeSinceStartup<deadline);Require(!visual.Loading&&visual.ExteriorModel,"Aircraft model was not ready after35 seconds.");yield return null;}
 static Session Capture(SkyboundBootstrap b)=>new Session{AircraftIndex=b.HUD.Visual.Selected,Design=Copy(b.HUD.Visual.SelectedDesign),Challenge=b.Mission.CurrentChallenge?.Copy(),Mode=b.Mission.Mode,Latitude=b.World.Latitude,Longitude=b.World.Longitude,Place=b.Mission.Place,Runway=b.Mission.RunwayStartMode,Assist=b.Aircraft.Assist,Elevation=b.World.ElevationEnabled,HUD=SimpleFields(b.HUD),Camera=SimpleFields(b.CameraRig)};
 static AircraftDesign Copy(AircraftDesign value)=>value==null?null:JsonUtility.FromJson<AircraftDesign>(JsonUtility.ToJson(value));
 static Dictionary<FieldInfo,object> SimpleFields(object owner){var state=new Dictionary<FieldInfo,object>();foreach(var f in owner.GetType().GetFields(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic)){if(f.IsInitOnly)continue;var t=f.FieldType;if(t.IsPrimitive||t.IsEnum||t==typeof(string)||t==typeof(Vector2)||t==typeof(Vector3)||t==typeof(Quaternion)){if(f.Name.Contains("touch")||f.Name=="stickControl"||f.Name=="thrustControl"||f.Name=="brakeControl"||f.Name.Contains("Captured")||f.Name.Contains("Dragging")||f.Name.Contains("Looking")||f.Name.Contains("WasDown")||f.Name=="flyDesignWhenReady"||f.Name=="looking"||f.Name=="stickPosition")continue;state[f]=f.GetValue(owner);}else if(t==typeof(AircraftDesign))state[f]=Copy((AircraftDesign)f.GetValue(owner));else if(t==typeof(ChallengeDefinition))state[f]=((ChallengeDefinition)f.GetValue(owner))?.Copy();}return state;}
 static void ApplyFields(object owner,Dictionary<FieldInfo,object> state){foreach(var item in state)item.Key.SetValue(owner,item.Value);}
 static IEnumerator RestoreSession(SkyboundBootstrap b,Session session){
  RecoverPreferences();PauseAndRelease(b);b.Mission.StopAllCoroutines();b.Aircraft.Mission=b.Mission;b.Aircraft.World=b.World;b.HUD.Visual.Aircraft=b.Aircraft;
  if(session.Design!=null)b.HUD.Visual.SelectDesign(session.Design);else b.HUD.Visual.Select(session.AircraftIndex);yield return WaitForModel(b.HUD.Visual);b.World.ElevationEnabled=session.Elevation;
  if(session.Challenge!=null)b.Mission.StartChallenge(session.Challenge,session.Assist,session.Runway);else b.Mission.StartFlight(session.Mode,session.Latitude,session.Longitude,session.Place,session.Assist,session.Runway);
  b.Aircraft.Active=false;Time.timeScale=0;
  if(session.Runway){float deadline=Time.realtimeSinceStartup+45;while(!b.Mission.GroundStartReady&&Time.realtimeSinceStartup<deadline){b.Aircraft.Active=false;yield return null;}Require(b.Mission.GroundStartReady,"Original runway session did not become ready during restoration.");}
  PauseAndRelease(b);ApplyFields(b.HUD,session.HUD);ApplyFields(b.CameraRig,session.Camera);b.HUD.ReloadCreations();if(b.HUD.Menu==MenuPage.Flight)b.HUD.Menu=MenuPage.Pause;Cursor.lockState=CursorLockMode.None;Cursor.visible=true;
  RequirePreferencesRestored();Require(session.Design!=null?b.HUD.Visual.SelectedDesign!=null&&b.HUD.Visual.SelectedDesign.Id==session.Design.Id:b.HUD.Visual.SelectedDesign==null&&b.HUD.Visual.Selected==session.AircraftIndex,"Session restoration selected the wrong airframe. "+SelectionDetails(b.HUD.Visual,session));
 }
 static string SelectionDetails(AircraftVisual visual,Session session)=>"expected index="+session.AircraftIndex+"; expected design="+(session.Design==null?"null":JsonUtility.ToJson(session.Design))+"; actual index="+visual.Selected+"; actual design="+(visual.SelectedDesign==null?"null":JsonUtility.ToJson(visual.SelectedDesign))+"; actual stock="+visual.StockAircraftName+"; loading="+visual.Loading;
 static void RestoreImmediate(SkyboundBootstrap b,Session session){if(!b)return;b.Mission.StopAllCoroutines();b.Aircraft.Mission=b.Mission;b.Aircraft.World=b.World;b.HUD.Visual.Aircraft=b.Aircraft;b.World.ElevationEnabled=session.Elevation;if(session.Design!=null)b.HUD.Visual.SelectDesign(session.Design);else b.HUD.Visual.Select(session.AircraftIndex);b.Mission.StartFlight(FlightMode.FreeFlight,session.Latitude,session.Longitude,session.Place,false,false);b.Aircraft.Active=false;Time.timeScale=0;ApplyFields(b.HUD,session.HUD);ApplyFields(b.CameraRig,session.Camera);b.HUD.Menu=MenuPage.Discover;b.HUD.ReloadCreations();Cursor.lockState=CursorLockMode.None;Cursor.visible=true;}
 static void PauseAndRelease(SkyboundBootstrap b){if(!b)return;Time.timeScale=0;if(b.Aircraft)b.Aircraft.Active=false;if(b.HUD)b.HUD.SendMessage("OnApplicationFocus",false);if(b.CameraRig)b.CameraRig.SendMessage("OnApplicationFocus",false);Cursor.lockState=CursorLockMode.None;Cursor.visible=true;}
 static HashSet<int> DeviceIds(){var ids=new HashSet<int>();foreach(var device in InputSystem.devices)ids.Add(device.deviceId);return ids;}
 static void RemoveAddedDevices(HashSet<int> original){var remove=new List<InputDevice>();foreach(var device in InputSystem.devices)if(!device.native&&!original.Contains(device.deviceId))remove.Add(device);foreach(var device in remove)InputSystem.RemoveDevice(device);}
 static PreferenceBackup CapturePreferences(){var backup=new PreferenceBackup();foreach(var key in PreferenceKeys)backup.Items.Add(new PreferenceValue{Key=key,Existed=PlayerPrefs.HasKey(key),Value=PlayerPrefs.GetString(key,"")});return backup;}
 static void InterruptedRecovery(){RecoverPreferences();activeBackup=null;cancelRequested=true;Running=false;}
 static void RecoverPreferences(){
  if(activeBackup==null&&File.Exists(BackupPath)){try{activeBackup=JsonUtility.FromJson<PreferenceBackup>(File.ReadAllText(BackupPath));}catch(Exception ex){Debug.LogError("Could not recover regression preferences: "+ex.Message);return;}}
  if(activeBackup==null)return;
  foreach(var value in activeBackup.Items)if(Array.IndexOf(PreferenceKeys,value.Key)>=0){if(value.Existed)PlayerPrefs.SetString(value.Key,value.Value);else PlayerPrefs.DeleteKey(value.Key);}PlayerPrefs.Save();if(File.Exists(BackupPath))File.Delete(BackupPath);
 }
 static void RequirePreferencesRestored(){if(activeBackup==null)return;foreach(var value in activeBackup.Items)Require(PlayerPrefs.HasKey(value.Key)==value.Existed&&(!value.Existed||PlayerPrefs.GetString(value.Key)==value.Value),"User preference JSON was not restored exactly: "+value.Key);}
 static void Save(StringBuilder evidence,List<Result> results,List<string> console,int warnings,bool complete){var text=new StringBuilder(evidence.ToString());int failures=0;foreach(var result in results)if(result.Status!="PASS")failures++;text.AppendLine("\nStage results:");foreach(var result in results){text.AppendLine(result.Status+" | "+result.Name+" | wall seconds="+result.Seconds.ToString("F2"));if(result.Error.Length>0)text.AppendLine(result.Error);if(result.Details.Length>0)text.Append(result.Details);}text.AppendLine("\nNew Console errors/asserts/exceptions: "+console.Count+"; warning messages: "+warnings);foreach(var issue in console)text.AppendLine(issue);text.AppendLine("\nSTATUS: "+(complete?(failures==0&&console.Count==0?"PASSED":"FAILED"):"RUNNING"));File.WriteAllText(ReportPath,text.ToString());}
 static string Trim(string value,int maximum)=>value==null?"":value.Length<=maximum?value:value.Substring(0,maximum);
 static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
}
}
#endif
