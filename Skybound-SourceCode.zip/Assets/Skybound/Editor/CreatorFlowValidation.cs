#if UNITY_EDITOR
using System;
using System.Collections;
using System.IO;
using System.Text;
using UnityEngine;
namespace Skybound.Editor {
public static class CreatorFlowValidation {
 public static IEnumerator Run(SkyboundBootstrap b){
  string[] keys={AircraftDesignStore.PreferenceKey,"Skybound.CustomChallenges.v1"};var existed=new bool[keys.Length];var values=new string[keys.Length];for(int i=0;i<keys.Length;i++){existed[i]=PlayerPrefs.HasKey(keys[i]);values[i]=PlayerPrefs.GetString(keys[i],"");}
  var h=b.HUD;var report=new StringBuilder("Creator menu command-path checks (not synthetic GUI clicks)\n");bool complete=false;
  try{
   foreach(var key in keys)PlayerPrefs.DeleteKey(key);h.ReloadCreations();Time.timeScale=0;b.Aircraft.Active=false;
   h.EditAircraftDesign(new AircraftDesign{Id=Guid.NewGuid().ToString("N"),Name="Validation airliner",BaseAircraftIndex=16,Tint=new Color(.67f,.79f,.94f),ThrustMultiplier=1.1f,ControlSensitivity=.9f});Require(h.Menu==MenuPage.AircraftDesigner,"Aircraft form did not open.");Require(h.SaveAircraftCreation(),"Aircraft form did not save.");yield return WaitForModel(h.Visual);string id=h.AircraftDraft.Id;Require(AircraftDesignStore.Load().Count==1&&h.Visual.SelectedDesign.Id==id,"Aircraft form save did not select the saved design.");
   h.EditAircraftDesign(AircraftDesignStore.Load()[0]);h.AircraftDraft.Name="Updated validation airliner";Require(h.SaveAircraftCreation(),"Aircraft edit did not save.");yield return WaitForModel(h.Visual);Require(AircraftDesignStore.Load().Count==1&&AircraftDesignStore.Load()[0].Id==id&&AircraftDesignStore.Load()[0].Name==h.AircraftDraft.Name,"Aircraft edit duplicated identity.");
   h.AircraftDraft.Name=" ";Require(!h.SaveAircraftCreation()&&AircraftDesignStore.Load().Count==1,"Empty aircraft name was accepted.");h.AircraftDraft.Name="Updated validation airliner";Require(h.SaveAircraftCreation(true),"Save & fly failed.");yield return WaitForModel(h.Visual);h.SendMessage("Update");Require(h.Menu==MenuPage.Flight&&b.Mission.Mode==FlightMode.FreeFlight&&h.Visual.SelectedDesign.Id==id,"Save & fly did not launch the intended selected airframe.");b.Aircraft.Active=false;Time.timeScale=0;
   report.AppendLine("PASS aircraft form opens, saves, edits without duplicates, rejects empty name, reloads and launches its saved design after async loading.");
   var draft=ChallengeCatalog.CreateDefault(FlightMode.SingleEngine);draft.Name="Validation creator challenge";draft.StartAltitude=380;draft.StartSpeed=90;draft.FailureDelay=12;h.EditChallenge(draft);Require(h.Menu==MenuPage.ChallengeBuilder,"Challenge form did not open.");Require(h.SaveChallengeCreation(true)&&h.Menu==MenuPage.Briefing,"Save & test did not open briefing.");string challengeId=h.ChallengeDraft.Id;Require(ChallengeStore.Load().Count==1&&h.SelectedChallenge.Id==challengeId,"Saved challenge identity lost in briefing.");
   h.BeginChallenge(h.SelectedChallenge);Require(h.Menu==MenuPage.Flight&&b.Mission.CurrentChallenge.Id==challengeId&&b.Mission.CurrentChallenge.StartAltitude==380&&b.Mission.FailureDelay==12,"Briefing launch lost creator settings.");b.Aircraft.Active=false;Time.timeScale=0;h.SendMessage("Restart");Require(h.Menu==MenuPage.Flight&&b.Mission.CurrentChallenge.Id==challengeId&&b.Mission.CurrentChallenge.StartAltitude==380&&b.Mission.FailureDelay==12,"HUD retry lost custom settings.");b.Aircraft.Active=false;Time.timeScale=0;
   h.EditChallenge(ChallengeStore.Load()[0]);h.ChallengeDraft.Name="Updated creator challenge";Require(h.SaveChallengeCreation()&&ChallengeStore.Load().Count==1&&ChallengeStore.Load()[0].Id==challengeId,"Challenge edit duplicated identity.");h.ChallengeDraft.Name=" ";Require(!h.SaveChallengeCreation(),"Empty challenge name was accepted.");h.ReloadCreations();Require(h.DeleteAircraftCreation(id)&&h.DeleteChallengeCreation(challengeId)&&AircraftDesignStore.Load().Count==0&&ChallengeStore.Load().Count==0,"Creator delete/reload failed.");
   report.AppendLine("PASS challenge form saves to briefing, launches configured settings, preserves them on HUD retry, edits without duplicates, rejects empty name and deletes/reloads both creation types.");complete=true;Debug.Log("SKYBOUND_CREATOR_FLOWS_PASSED "+report);
  }finally{for(int i=0;i<keys.Length;i++){if(existed[i])PlayerPrefs.SetString(keys[i],values[i]);else PlayerPrefs.DeleteKey(keys[i]);}PlayerPrefs.Save();h.ReloadCreations();h.Visual.Select(0);b.Mission.StartFlight(FlightMode.FreeFlight);b.Aircraft.Active=false;Time.timeScale=0;h.Menu=MenuPage.Discover;b.CameraRig.Discover=true;if(!complete)report.AppendLine("FAIL: see Editor assertion.");File.WriteAllText("creator-flow-validation.txt",report.ToString());}
 }
 static IEnumerator WaitForModel(AircraftVisual visual){float deadline=Time.realtimeSinceStartup+25;while(visual.Loading&&Time.realtimeSinceStartup<deadline)yield return null;Require(!visual.Loading,"Aircraft loading timeout.");yield return null;}
 static void Require(bool value,string message){if(!value)throw new InvalidOperationException(message);}
}
}
#endif
