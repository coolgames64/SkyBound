#if UNITY_EDITOR
using System;
using System.Collections;
using System.IO;
using System.Text;
using UnityEngine;

namespace Skybound.Editor {
public static class RunwayStartValidation {
 public static IEnumerator Run(SkyboundBootstrap b){
  var report=new StringBuilder("Real-runway starts and approach-entry timing checks\n");var m=b.Mission;var a=b.Aircraft;var visual=b.HUD.Visual;
  var previous=m.CurrentChallenge?.Copy();var previousMode=m.Mode;bool previousRunway=m.RunwayStartMode,previousAssist=a.Assist;double oldLat=b.World.Latitude,oldLon=b.World.Longitude;string oldPlace=m.Place;
  try{
   Require(RunwayCatalog.Count>=9000,"Global runway data is incomplete.");double[] latitudes={40.773,37.62,51.505,-33.86,35.68,46.58},longitudes={-73.998,-122.37,-.12,151.21,139.76,8};
   for(int i=0;i<latitudes.Length;i++){var r=RunwayCatalog.Nearest(latitudes[i],longitudes[i]);Require(r!=null&&r.Length>=1800&&r.Width>=20&&r.Heading>=0&&r.Heading<360&&RunwayCatalog.Distance(r.Latitude,r.Longitude,r.EndLatitude,r.EndLongitude)>1500,"Destination did not select a usable real runway.");}
   report.AppendLine("PASS global catalog selects usable paved runway directions for all six featured destinations.");
   m.StartFlight(FlightMode.FreeFlight);a.ResetFlight(0,0,0,false);a.Gear=a.Grounded=true;a.transform.position=new Vector3(0,b.World.HeightAt(Vector3.zero)+a.GroundClearance,0);a.SendMessage("LateUpdate");visual.SendMessage("LateUpdate");var slides=EmergencySlides.For(visual);slides.Deploy();Require(slides.Deployed,"Could not establish the prior evacuation state for reset validation.");
   var definition=ChallengeCatalog.CreateDefault(FlightMode.SingleEngine);definition.Id="custom-runway-validation";definition.FailureDelay=12;definition.Fuel=.005f;definition.InitialGear=false;definition.InitialFlaps=2;definition.Wind=9;
   m.StartChallenge(definition,false,true);Require(!slides.Deployed&&slides.Inflation==0,"Starting another flight retained evacuation slides.");
   Require(!slides.CanDeploy,"Evacuation could restart during runway loading/preparation.");
   Require(m.RunwayStartMode&&m.WaitingForTakeoff&&m.PreparingChallenge&&!m.GroundStartReady,"Runway phase did not initialize.");Require(a.Speed==0&&a.Throttle==0&&a.EnginePower==0&&a.LeftEnginePower==0&&a.RightEnginePower==0&&a.Grounded&&a.Gear&&a.Flaps==1&&a.Engines&&a.LeftEngine&&a.RightEngine&&a.FuelRemaining==1,"Runway spawn retained airborne speed, thrust or failure state.");
   float deadline=Time.realtimeSinceStartup+42;while(!m.GroundStartReady&&Time.realtimeSinceStartup<deadline)yield return null;Require(m.GroundStartReady&&b.World.SurfaceLoaded(Vector3.zero)&&b.World.ElevationLoadedAt(Vector3.zero),"Runway imagery/terrain did not become ready.");
   a.Active=false;Time.timeScale=0;Require(Mathf.Abs(a.Altitude-b.World.HeightAt(Vector3.zero)-a.GroundClearance)<.08f,"Spawn was not seated on the visible terrain.");var departure=RunwayCatalog.Nearest(b.World.Latitude,b.World.Longitude);double padding=RunwayCatalog.Distance(b.World.Latitude,b.World.Longitude,departure.Latitude,departure.Longitude);Require(padding>70&&padding<90,"Runway spawn is not80m inside the selected threshold.");
   a.Active=true;a.Elapsed=120;m.SendMessage("Update");Require(m.WaitingForTakeoff&&m.EmergencyElapsed==0&&a.LeftEngine&&a.RightEngine&&a.FuelRemaining==1&&!a.GearJammedUp,"Taxi time consumed emergency time or reserve.");
   report.AppendLine("PASS stopped zero-power runway spawn, terrain seating,80m threshold padding, explicit slide reset and no emergency/fuel loss while taxiing.");
   a.Grounded=false;a.Speed=85;a.transform.position=new Vector3(0,b.World.HeightAt(Vector3.zero)+a.GroundClearance+25,0);a.Elapsed=121;m.SendMessage("Update");Require(!m.WaitingForTakeoff&&m.PreparingChallenge&&m.EmergencyElapsed==0&&a.LeftEngine&&a.RightEngine,"Liftoff skipped the healthy approach preparation phase.");Require(!slides.CanDeploy,"Slides could deploy during approach preparation.");
   a.Elapsed=200;m.SendMessage("Update");Require(m.PreparingChallenge&&m.EmergencyElapsed==0&&a.FuelRemaining==1,"Flight to the approach entry consumed failure time or fuel reserve.");
   a.transform.position=m.ChallengeEntry;a.Heading=m.EntryHeading;a.Pitch=6;a.Elapsed=250;m.SendMessage("Update");Require(!m.PreparingChallenge&&m.EmergencyElapsed==0&&a.FuelRemaining==definition.Fuel&&a.Wind==definition.Wind&&!a.Gear&&a.Flaps==2&&a.Pitch==6,"Reaching the aligned entry did not apply the saved settings with continuous attitude.");
   a.Elapsed=261.99f;m.SendMessage("Update");Require(a.LeftEngine,"Entry-relative failure fired too early.");a.Elapsed=262.01f;m.SendMessage("Update");Require(!a.LeftEngine&&a.RightEngine,"Entry-relative failure did not fire after12s.");
   report.AppendLine("PASS liftoff preparation, healthy transit, entry-applied reserve/weather/gear/flaps with continuous attitude, blocked evacuation and failure timing measured from the entry.");
   m.RetryChallenge(false);Require(m.RunwayStartMode&&m.WaitingForTakeoff&&m.PreparingChallenge&&m.CurrentChallenge.Id==definition.Id&&m.CurrentChallenge.FailureDelay==12&&a.LeftEngine&&a.RightEngine&&a.FuelRemaining==1,"Retry lost the runway setting or custom definition.");
   foreach(var mode in new[]{FlightMode.Hudson,FlightMode.Glide,FlightMode.FuelEmergency,FlightMode.GearFailure}){m.StartChallenge(ChallengeCatalog.CreateDefault(mode),false,true);a.Active=true;a.Elapsed=300;m.SendMessage("Update");Require(m.WaitingForTakeoff&&m.EmergencyElapsed==0&&a.Engines&&a.LeftEngine&&a.RightEngine&&!a.GearJammedUp&&a.FuelRemaining==1,"A failure/low reserve occurred during runway preparation: "+mode);}
   m.StartFlight(FlightMode.FreeFlight,51.4647,-.434,"London Heathrow",false,true);a.Active=true;a.Elapsed=.05f;m.SendMessage("Update");Require(a.Altitude<150&&m.WaitingForTakeoff&&!m.PreparingChallenge,"Free flight raised the runway spawn into the air.");
   m.StartFlight(FlightMode.Glide);Require(!m.RunwayStartMode&&!m.WaitingForTakeoff&&!m.PreparingChallenge&&!a.Engines&&a.Altitude==270,"Existing airborne API changed its default glide start.");
   report.AppendLine("PASS retry preserves runway/custom configuration; all emergency templates remain healthy on runway; FreeFlight stays on runway; default airborne Glide remains compatible.");
  }finally{
   if(previous!=null)m.StartChallenge(previous,previousAssist,previousRunway);else m.StartFlight(previousMode,oldLat,oldLon,oldPlace,previousAssist,previousRunway);a.Active=false;Time.timeScale=0;b.HUD.Menu=MenuPage.Discover;b.CameraRig.Discover=true;
  }
  File.WriteAllText(Path.Combine(Application.dataPath,"../../runway-start-validation.txt"),report.ToString());Debug.Log("SKYBOUND_RUNWAY_STARTS_PASSED "+report);
 }
 static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
}
}
#endif
