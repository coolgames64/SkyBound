#if UNITY_EDITOR
using System;
using System.Collections;
using System.IO;
using System.Text;
using UnityEngine;
namespace Skybound.Editor {
public static class SafetySystemsValidation {
 public static IEnumerator Run(SkyboundBootstrap b){
  var report=new StringBuilder("Ram-air turbine and exit-slide checks\n");var go=new GameObject("Isolated RAT validation");var f=go.AddComponent<FlightController>();f.enabled=false;
  try {
   int fitted=0;foreach(var entry in b.Catalog.Aircraft)if(AircraftSystems.SupportsRAT(entry.Name))fitted++;
   Require(fitted==16,"Unexpected RAT fleet availability: "+fitted);report.AppendLine("PASS16 fitted family entries;7 entries without an implemented RAT.");
   f.ResetFlight(2000,85,0,false);f.Throttle=0;for(int i=0;i<300;i++)f.Step(.02f,0,0);Require(!f.RATDeployed,"Idle engines incorrectly deployed RAT.");
   f.ResetFlight(2000,85,0,false);f.LeftEngine=false;for(int i=0;i<200;i++)f.Step(.02f,0,0);Require(!f.RATDeployed,"One healthy engine incorrectly deployed RAT.");
   f.Engines=false;for(int i=0;i<200;i++)f.Step(.02f,0,0);Require(f.RATDeployed&&f.RATPosition>.98f&&f.EmergencyPower>.9f,"Total failure did not deploy and drive RAT.");report.AppendLine("PASS total failure deploys automatically; idle and single-engine operation do not.");
   f.Speed=0;Require(f.EmergencyPower==0,"RAT generated power without airflow.");f.Speed=20;float slow=f.EmergencyPower;f.Speed=85;Require(f.EmergencyPower>slow+.4f,"RAT output did not depend on airspeed.");
   f.ToggleRAT();Require(f.RATDeployed,"RAT retracted in flight.");f.Grounded=true;f.ToggleRAT();for(int i=0;i<150;i++)f.Step(.02f,0,0);Require(f.RATPosition<.01f,"Ground retraction did not complete.");
   f.ResetFlight(2000,85,0,false);Require(!f.RATDeployed&&f.RATPosition==0,"Flight reset retained deployed RAT.");f.ToggleRAT();Require(f.RATDeployed,"Manual deployment failed.");f.ConfigureAircraft("Boeing737-800");Require(!f.RATAvailable&&!f.RATDeployed,"Unfitted aircraft retained RAT.");report.AppendLine("PASS airspeed-based output, manual deployment, ground-only retraction and fleet/reset state.");
  }finally{UnityEngine.Object.Destroy(go);}
  b.HUD.Visual.Select(0);while(b.HUD.Visual.Loading)yield return null;
  b.Mission.StartFlight(FlightMode.FreeFlight);var a=b.Aircraft;var visual=b.HUD.Visual;var slides=EmergencySlides.For(visual);slides.ResetSlides();Time.timeScale=0;a.Active=false;b.CameraRig.Discover=false;b.CameraRig.Cockpit=b.CameraRig.Cabin=false;b.HUD.Menu=MenuPage.Flight;b.Mission.Finished=false;
  a.ResetFlight(650,85,0,false);Require(!slides.CanDeploy,"Slides could deploy airborne.");
  a.Gear=true;a.Grounded=true;a.Speed=10;a.transform.position=new Vector3(0,b.World.HeightAt(Vector3.zero)+a.GroundClearance,0);Require(!slides.CanDeploy,"Slides could deploy while taxiing at speed.");
  a.Speed=0;a.SendMessage("LateUpdate");visual.SendMessage("LateUpdate");b.CameraRig.SendMessage("LateUpdate");Require(slides.CanDeploy,"Stopped aircraft cannot evacuate.");slides.Deploy();
  float deadline=Time.realtimeSinceStartup+4;while(slides.Inflation<.99f&&Time.realtimeSinceStartup<deadline)yield return null;
  Require(slides.Deployed&&slides.Inflation>.99f&&!a.Active&&a.Speed==0&&a.EnginePower==0,"Evacuation failed to stop engines or fully inflate while paused.");
  var renderers=slides.GetComponentsInChildren<Renderer>();int slideParts=0;float bottom=float.PositiveInfinity;
  foreach(var renderer in renderers)if(renderer.name.Contains("Inflated rails")||renderer.name.Contains("Slide surface")){slideParts++;bottom=Mathf.Min(bottom,renderer.bounds.min.y);}
  Require(slideParts>=8,"Exit-slide geometry missing.");Require(bottom>=b.World.HeightAt(Vector3.zero)-.1f,"Slide endpoint penetrates level runway.");report.AppendLine($"PASS stopped-aircraft evacuation: inflation={slides.Inflation:F2}, slide parts={slideParts}, lowest endpoint clearance={bottom-b.World.HeightAt(Vector3.zero):F3}m; engines stopped.");
  a.transform.position+=Vector3.up*100;a.Grounded=true;slides.SendMessage("Update");Require(!slides.Deployed,"Stale ground state retained exit slides in the air.");Require(!slides.CanDeploy,"Stale ground state allowed airborne evacuation.");
  a.transform.position=new Vector3(0,b.World.HeightAt(Vector3.zero)+a.GroundClearance,0);a.SendMessage("LateUpdate");visual.SendMessage("LateUpdate");slides.Deploy();Require(slides.Deployed,"Stopped-aircraft re-deployment failed.");a.ResetFlight(650,85,208,false);slides.SendMessage("Update");Require(!slides.Deployed,"New flight retained exit slides.");report.AppendLine("PASS height guard clears slides with a stale grounded flag; airborne deployment is blocked; reset clears slides before moving.");
  File.WriteAllText("safety-systems-validation.txt",report.ToString());Debug.Log("SKYBOUND_SAFETY_SYSTEMS_PASSED "+report);b.HUD.Menu=MenuPage.Discover;b.CameraRig.Discover=true;
 }
 static void Require(bool condition,string text){if(!condition)throw new Exception(text);}
}
}
#endif
