#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
namespace Skybound.Editor {
public static class RuntimeValidation {
 public static IEnumerator Audit(SkyboundBootstrap b){
  var checks=new List<string>();b.HUD.Menu=MenuPage.Flight;b.CameraRig.Discover=false;b.CameraRig.Cockpit=b.CameraRig.Cabin=false;Time.timeScale=0;b.Aircraft.ResetFlight(650,85,0,false);
  for(int i=0;i<b.Catalog.Aircraft.Length;i++){
   b.HUD.Visual.Select(i);float deadline=Time.realtimeSinceStartup+20;do{yield return null;}while(b.HUD.Visual.Loading&&Time.realtimeSinceStartup<deadline);
   if(b.HUD.Visual.Loading)throw new Exception("Loading timeout: "+b.Catalog.Aircraft[i].Name);
   var renderers=b.HUD.Visual.GetComponentsInChildren<Renderer>(true);if(renderers.Length==0)throw new Exception("No model: "+b.Catalog.Aircraft[i].Name);
   foreach(var renderer in renderers)foreach(var mat in renderer.sharedMaterials)if(!mat||!mat.shader||!mat.shader.name.StartsWith("Universal Render Pipeline/"))throw new Exception("Invalid material: "+b.Catalog.Aircraft[i].Name);
   checks.Add(b.Catalog.Aircraft[i].Name+": loaded, URP materials valid, yaw "+b.Catalog.Aircraft[i].YawOffset);
  }
  b.HUD.Visual.Select(0);while(b.HUD.Visual.Loading)yield return null;
  var nose=Array.Find(b.HUD.Visual.GetComponentsInChildren<Transform>(true),t=>t.name=="NLGWheels");if(!nose||b.HUD.Visual.transform.InverseTransformPoint(nose.GetComponent<Renderer>().bounds.center).z<0)throw new Exception("A320 nose points backwards");checks.Add("A320 nose gear ahead along +Z flight direction");
  var pad=InputSystem.AddDevice<Gamepad>();InputState.Change(pad,new GamepadState{leftStick=new Vector2(.7f,-.7f)});
  if(FlightInput.FlightStick.x<.1f||FlightInput.FlightStick.y>-.1f)throw new Exception("Controller axes failed");b.Aircraft.ResetFlight(650,85,0,true);for(int i=0;i<20;i++)b.Aircraft.SendMessage("FixedUpdate");if(b.Aircraft.Pitch<=0||b.Aircraft.Roll<=0)throw new Exception("Controller flight response failed");InputSystem.RemoveDevice(pad);checks.Add("Injected gamepad input banks right and pitches up when pulled back");
  b.Aircraft.ResetFlight(650,85,0,true);b.HUD.MouseJoystick=true;b.Aircraft.TouchPitch=.7f;b.Aircraft.TouchRoll=-.7f;for(int i=0;i<20;i++)b.Aircraft.SendMessage("FixedUpdate");if(b.Aircraft.Pitch<=0||b.Aircraft.Roll>=0)throw new Exception("Screen joystick flight response failed");b.Aircraft.ResetFlight(650,85,0,true);checks.Add("On-screen joystick commands bank left and pitch up");
  var mouse=InputSystem.AddDevice<Mouse>();var state=new MouseState{delta=new Vector2(90,-20)}.WithButton(MouseButton.Right);InputState.Change(mouse,state);float orbit=b.CameraRig.Orbit;b.CameraRig.SendMessage("LateUpdate");if(b.CameraRig.Orbit<=orbit)throw new Exception("Mouse look failed");InputState.Change(mouse,new MouseState());b.CameraRig.SendMessage("LateUpdate");if(Cursor.lockState!=CursorLockMode.None)throw new Exception("Cursor did not release");InputSystem.RemoveDevice(mouse);checks.Add("Right mouse rotates camera and releases cursor");
  b.Aircraft.ResetFlight(650,85,0,true);Time.timeScale=1;b.Aircraft.Mission=null;b.Aircraft.Throttle=(85-60)/95f;b.Aircraft.Visual.gameObject.SetActive(true);
  for(int i=0;i<10;i++)yield return null;
  var roots=new List<float>();var visuals=new List<float>();Vector3 rp=b.Aircraft.transform.position,vp=b.Aircraft.RenderPosition;
  for(int i=0;i<90;i++){yield return null;float dt=Mathf.Max(.0001f,Time.deltaTime);roots.Add(Vector3.Distance(rp,b.Aircraft.transform.position)/dt);visuals.Add(Vector3.Distance(vp,b.Aircraft.RenderPosition)/dt);rp=b.Aircraft.transform.position;vp=b.Aircraft.RenderPosition;}
  double rootDeviation=Deviation(roots),visualDeviation=Deviation(visuals);checks.Add("90-frame speed variation: fixed pose "+rootDeviation.ToString("F2")+" m/s; rendered pose "+visualDeviation.ToString("F2")+" m/s");
  b.Aircraft.Mission=b.Mission;b.Aircraft.Active=false;Time.timeScale=0;b.HUD.Menu=MenuPage.Discover;b.CameraRig.Discover=true;
  File.WriteAllLines("../fleet-and-controls-validation.txt",checks);Debug.Log("SKYBOUND_FLEET_AND_CONTROLS_PASSED "+string.Join("; ",checks));
 }
 public static string ValidateMobile(SkyboundBootstrap b){
b.HUD.Menu=Skybound.MenuPage.Flight;b.HUD.MobileControls=true;b.HUD.MouseJoystick=true;b.CameraRig.Discover=false;b.CameraRig.Cockpit=b.CameraRig.Cabin=false;b.Aircraft.Active=true;UnityEngine.Time.timeScale=0;
float scale=UnityEngine.Mathf.Min(UnityEngine.Screen.width/1440f,UnityEngine.Screen.height/900f);System.Func<UnityEngine.Vector2,UnityEngine.Vector2> pixel=p=>new UnityEngine.Vector2((UnityEngine.Screen.width-1440*scale)/2+p.x*scale,UnityEngine.Screen.height-(UnityEngine.Screen.height-900*scale)/2-p.y*scale);
var device=UnityEngine.InputSystem.InputSystem.AddDevice<UnityEngine.InputSystem.Touchscreen>();
UnityEngine.InputSystem.InputSystem.QueueStateEvent(device,new UnityEngine.InputSystem.LowLevel.TouchState{touchId=1,phase=UnityEngine.InputSystem.TouchPhase.Began,position=pixel(b.HUD.StickArea.center+new UnityEngine.Vector2(40,50))});UnityEngine.InputSystem.InputSystem.Update();b.HUD.SendMessage("Update");
if(b.Aircraft.TouchPitch<=0||b.Aircraft.TouchRoll<=0)throw new System.Exception("Touch joystick failed");float orbit=b.CameraRig.Orbit;b.CameraRig.SendMessage("LateUpdate");if(b.CameraRig.Orbit!=orbit)throw new System.Exception("Joystick moved camera");
UnityEngine.InputSystem.InputSystem.QueueStateEvent(device,new UnityEngine.InputSystem.LowLevel.TouchState{touchId=2,phase=UnityEngine.InputSystem.TouchPhase.Began,position=pixel(new UnityEngine.Vector2(750,400))});UnityEngine.InputSystem.InputSystem.Update();b.CameraRig.SendMessage("LateUpdate");
UnityEngine.InputSystem.InputSystem.QueueStateEvent(device,new UnityEngine.InputSystem.LowLevel.TouchState{touchId=2,phase=UnityEngine.InputSystem.TouchPhase.Moved,position=pixel(new UnityEngine.Vector2(820,400)),delta=new UnityEngine.Vector2(40,0)});UnityEngine.InputSystem.InputSystem.Update();b.CameraRig.SendMessage("LateUpdate");if(b.CameraRig.Orbit<=orbit)throw new System.Exception("Touch camera failed");
UnityEngine.InputSystem.InputSystem.RemoveDevice(device);b.HUD.SendMessage("Update");if(b.Aircraft.TouchPitch!=0||b.Aircraft.TouchRoll!=0)throw new System.Exception("Touch stick did not release");
var mouse=UnityEngine.InputSystem.InputSystem.AddDevice<UnityEngine.InputSystem.Mouse>();UnityEngine.InputSystem.LowLevel.InputState.Change(mouse,new UnityEngine.InputSystem.LowLevel.MouseState{position=pixel(new UnityEngine.Vector2(750,400)),delta=new UnityEngine.Vector2(40,0)}.WithButton(UnityEngine.InputSystem.LowLevel.MouseButton.Left));orbit=b.CameraRig.Orbit;b.CameraRig.SendMessage("LateUpdate");if(b.CameraRig.Orbit<=orbit)throw new System.Exception("Left mouse look failed");
UnityEngine.InputSystem.LowLevel.InputState.Change(mouse,new UnityEngine.InputSystem.LowLevel.MouseState());b.CameraRig.SendMessage("LateUpdate");UnityEngine.InputSystem.LowLevel.InputState.Change(mouse,new UnityEngine.InputSystem.LowLevel.MouseState{position=pixel(b.HUD.StickArea.center),delta=new UnityEngine.Vector2(40,0)}.WithButton(UnityEngine.InputSystem.LowLevel.MouseButton.Left));orbit=b.CameraRig.Orbit;b.CameraRig.SendMessage("LateUpdate");if(b.CameraRig.Orbit!=orbit)throw new System.Exception("Left joystick click moved camera");UnityEngine.InputSystem.LowLevel.InputState.Change(mouse,new UnityEngine.InputSystem.LowLevel.MouseState());b.CameraRig.SendMessage("LateUpdate");UnityEngine.InputSystem.InputSystem.RemoveDevice(mouse);
System.IO.File.AppendAllText("../fleet-and-controls-validation.txt","Mobile touch joystick, simultaneous touch camera, release, left mouse look and joystick exclusion passed.\n");return "Mobile and left-drag input checks passed";

 }
 static double Deviation(List<float> values){double mean=0,sum=0;foreach(float v in values)mean+=v;mean/=values.Count;foreach(float v in values)sum+=(v-mean)*(v-mean);return Math.Sqrt(sum/values.Count);}
}
}
#endif
