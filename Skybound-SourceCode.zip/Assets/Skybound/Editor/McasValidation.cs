#if UNITY_EDITOR
using System;
using UnityEngine;
namespace Skybound.Editor {
public static class McasValidation {
 static void Check(bool value,string message){if(!value)throw new Exception("MCAS validation: "+message);}
 static McasSimulation Fresh(){var m=new McasSimulation();m.Reset(true);return m;}
 public static string Run(){
  var m=Fresh();m.Reset(false);m.Step(.02f,true,true,true,20,true,0);Check(m.NoseDownRate==0,"non-MAX isolation");
  m=Fresh();m.Step(.02f,false,true,true,20,true,0);Check(!m.Active&&m.NoseDownRate==0,"ground inhibit");
  m=Fresh();m.Step(.02f,true,true,false,20,true,0);Check(!m.Active,"flap inhibit");
  m=Fresh();m.Step(.02f,true,false,true,20,true,0);Check(!m.Active,"assist inhibit");
  m=Fresh();m.Step(.02f,true,true,true,20,false,0);Check(!m.Active,"power inhibit");
  m=Fresh();m.LeftSensorBias=10;m.Step(.02f,true,true,true,14,true,0);Check(m.SensorDisagree&&!m.Active&&m.NoseDownRate==0,"dual-sensor inhibit");
  m=Fresh();m.Step(.02f,true,true,true,14,true,0);Check(m.Active&&m.NoseDownRate>0,"high-AOA activation");
  for(int i=0;i<1000;i++)m.Step(.02f,true,true,true,14,true,0);Check(!m.Active&&m.TrimDegrees<=McasSimulation.MaxTrimDegrees+.0001f&&m.NoseDownRate==0,"authority limit and no repeated high-AOA cycles");
  for(int i=0;i<60;i++)m.Step(.02f,true,true,true,3,true,0);m.Step(.02f,true,true,true,14,true,0);Check(m.Active&&m.NoseDownRate>0,"rearm after sustained recovery");
  m=Fresh();for(int i=0;i<200;i++)m.Step(.02f,true,true,true,14,true,1);Check(m.TrimDegrees==0&&m.NoseDownRate==0,"pilot override");
  m=Fresh();m.Step(.02f,true,true,true,14,true,0);float trim=m.TrimDegrees;m.SetCutout(true);for(int i=0;i<100;i++)m.Step(.02f,true,true,true,14,true,0);Check(!m.Active&&m.NoseDownRate==0&&m.TrimDegrees==trim,"cutout stops further commands");
  m.Reset(true);Check(!m.CutOut&&m.TrimDegrees==0&&m.LeftSensorBias==0,"flight reset");
  var maxObject=new GameObject("MCAS integration MAX");var controlObject=new GameObject("MCAS integration control");
  try{var max=maxObject.AddComponent<FlightController>();var control=controlObject.AddComponent<FlightController>();max.ResetFlight(1000,90,0,true);control.ResetFlight(1000,90,0,true);max.ConfigureAircraft("Boeing 737 MAX 8");control.ConfigureAircraft("Boeing 777-300ER");max.Pitch=control.Pitch=14;max.Step(.02f,0,0);control.Step(.02f,0,0);Check(max.Mcas.NoseDownRate>0&&max.Pitch<control.Pitch,"MCAS contributes actual nose-down pitch");Check(!control.McasInstalled&&control.Mcas.NoseDownRate==0,"non-MAX flight controller unchanged");}
  finally{UnityEngine.Object.DestroyImmediate(maxObject);UnityEngine.Object.DestroyImmediate(controlObject);}
  Debug.Log("SKYBOUND_MCAS_VALIDATION: 14 behavioral and integration checks passed");return "14 behavioral and integration checks passed";
 }
}
}
#endif
