#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using UnityEngine;
using UnityEngine.LowLevel;

namespace Skybound.Editor {
// Editor-only regression coverage for runway contacts before an emergency is armed.
public static class DepartureContactValidation {
 const string CompletionKey="Skybound.CompletedChallenges.v1";
 static readonly FlightMode[] Modes={FlightMode.Hudson,FlightMode.Glide,FlightMode.Crosswind,FlightMode.SingleEngine,FlightMode.FuelEmergency,FlightMode.GearFailure,FlightMode.SevereWeather};
 static readonly KeyCode[] Keys={KeyCode.W,KeyCode.S,KeyCode.A,KeyCode.D,KeyCode.UpArrow,KeyCode.DownArrow,KeyCode.LeftArrow,KeyCode.RightArrow,KeyCode.LeftShift,KeyCode.RightShift,KeyCode.LeftControl,KeyCode.RightControl,KeyCode.Q,KeyCode.C,KeyCode.Space};

 public static IEnumerator Run(SkyboundBootstrap b){
  var saved=new SavedState(b);var report=new StringBuilder("Departure-contact state regression\n");bool passed=false;bool oldEnabled=b.Aircraft.enabled;
  try{
   b.Aircraft.enabled=false;
   foreach(var mode in Modes){
    foreach(bool preparing in new[]{false,true}){
     foreach(float verticalSpeed in new[]{-2f,2f}){
      SetupPhase(b,mode,preparing);var m=b.Mission;var a=b.Aircraft;var original=m.CurrentChallenge.Copy();
      ContactFixture(b,verticalSpeed,true);m.Touchdown();
      Require(!m.Finished&&!m.Success&&string.IsNullOrEmpty(m.Result),mode+" pre-entry contact was scored: "+m.Result);
      Require(m.WaitingForTakeoff&&m.PreparingChallenge&&a.Grounded&&a.Active&&Time.timeScale>0,mode+" gentle contact did not return to an active runway departure.");
      Require(a.Engines&&a.LeftEngine&&a.RightEngine&&a.FuelRemaining==1&&m.EmergencyElapsed==0,mode+" gentle contact consumed emergency state.");
      Require(Mathf.Abs(a.VerticalSpeed)<.001f&&Mathf.Abs(a.FlightPathAngle)<.001f&&Mathf.Abs(a.PitchRate)<.001f&&Mathf.Abs(a.RollRate)<.001f,mode+" contact left flight-path momentum on the ground.");
      Require(Mathf.Abs(a.Altitude-b.World.HeightAt(a.transform.position)-a.GroundClearance)<.05f,mode+" recovered contact is not seated above terrain.");
      Require(!ChallengeStore.IsCompleted(original.Id),mode+" departure contact recorded completion.");
      Require(!EmergencySlides.For(b.HUD.Visual).CanDeploy,mode+" active recovered departure allowed evacuation.");
      a.Elapsed=500;m.SendMessage("Update");Require(m.EmergencyElapsed==0&&a.Engines&&a.LeftEngine&&a.RightEngine&&a.FuelRemaining==1&&!a.GearJammedUp,mode+" recovered taxi advanced the emergency timer.");
      m.RetryChallenge(false);Require(m.RunwayStartMode&&m.WaitingForTakeoff&&m.PreparingChallenge&&!m.Finished&&m.CurrentChallenge.Id==original.Id&&m.CurrentChallenge.FailureDelay==original.FailureDelay,mode+" retry lost the challenge or runway-start mode.");
      report.AppendLine($"PASS {mode} / {(preparing?"preparing":"waiting")} / vertical speed {verticalSpeed:+0;-0}m/s: safe contact, grounded motion reset, healthy taxi, no score/completion, retry preserved.");
     }
     SetupPhase(b,mode,preparing);ContactFixture(b,-12,false);b.Mission.Touchdown();
     Require(b.Mission.Finished&&!b.Mission.Success&&!string.IsNullOrEmpty(b.Mission.Result),mode+" hard departure impact was not rejected.");
     Require(!b.Mission.Result.Contains("missed the Hudson")&&!b.Mission.Result.Contains("marked runway")&&!ChallengeStore.IsCompleted(b.Mission.CurrentChallenge.Id),mode+" hard pre-entry contact used armed landing scoring.");
     Require(!b.Mission.WaitingForTakeoff&&!b.Mission.PreparingChallenge&&EmergencySlides.For(b.HUD.Visual).CanDeploy,mode+" finished level, safely seated departure impact retained a phase block on evacuation.");
     report.AppendLine("PASS "+mode+" / "+(preparing?"preparing":"waiting")+" / hard contact: departure-specific failure, no completion, safely seated finished impact can evacuate.");
    }
    SetupPhase(b,mode,true);var mission=b.Mission;var aircraft=b.Aircraft;aircraft.transform.position=mission.ChallengeEntry;aircraft.Heading=mission.EntryHeading;aircraft.Elapsed=80;aircraft.Active=true;mission.SendMessage("Update");
    Require(!mission.WaitingForTakeoff&&!mission.PreparingChallenge,"Entry did not arm "+mode);
    ArmedLanding(b,mode);mission.Touchdown();Require(mission.Finished&&mission.Success&&ChallengeStore.IsCompleted(mission.CurrentChallenge.Id),mode+" armed landing scoring regressed: "+mission.Result);
    report.AppendLine("PASS "+mode+" armed runway-start challenge: original successful landing rules/completion still apply.");
   }
   b.Mission.StartFlight(FlightMode.FreeFlight,51.4647,-.4085,"London Heathrow",false,true);ContactFixture(b,2,true);b.Mission.Touchdown();
   Require(!b.Mission.Finished&&!b.Mission.Success&&string.IsNullOrEmpty(b.Mission.Result)&&b.Mission.WaitingForTakeoff&&!b.Mission.PreparingChallenge&&b.Aircraft.Grounded&&b.Aircraft.Active&&b.Mission.EmergencyElapsed==0,"FreeFlight waiting contact did not recover to its own takeoff phase.");
   b.Aircraft.Elapsed=500;b.Mission.SendMessage("Update");b.Mission.RetryChallenge(false);Require(b.Mission.RunwayStartMode&&b.Mission.WaitingForTakeoff&&!b.Mission.PreparingChallenge&&b.Mission.CurrentChallenge==null,"FreeFlight recovered retry lost its runway-only phase.");
   report.AppendLine("PASS FreeFlight waiting contact and retry recover without scoring or inventing a challenge preparation phase.");
   string[] invalidNames={"gear up","sink greater than6","bank greater than15","pitch greater than15","pitch less than-7","speed105"};
   Action<FlightController>[] invalid={a=>a.Gear=false,a=>a.VerticalSpeed=-6.01f,a=>a.Roll=15.01f,a=>a.Pitch=15.01f,a=>a.Pitch=-7.01f,a=>a.Speed=105};
   for(int i=0;i<invalid.Length;i++){
    SetupPhase(b,FlightMode.Hudson,false);ContactFixture(b,-2,false);invalid[i](b.Aircraft);b.Mission.Touchdown();Require(b.Mission.Finished&&!b.Mission.Success&&b.Mission.Result.StartsWith("Hard contact during departure"),"Unsafe departure boundary was accepted: "+invalidNames[i]);
    report.AppendLine("PASS departure rejection threshold: "+invalidNames[i]+".");
   }
   SetupPhase(b,FlightMode.Hudson,false);ContactFixture(b,-6,true);b.Aircraft.Roll=15;b.Aircraft.Pitch=15;b.Aircraft.Speed=104.99f;b.Mission.Touchdown();
   Require(!b.Mission.Finished&&b.Aircraft.Grounded&&b.Mission.WaitingForTakeoff,"Inclusive sink/bank/pitch limits or strictly-below105 speed were rejected.");report.AppendLine("PASS exact safe boundaries: sink6m/s, bank15deg, pitch15deg, speed104.99m/s.");
   SetupPhase(b,FlightMode.SingleEngine,true);ContactFixture(b,2,true);b.Mission.Touchdown();var recovered=b.Mission;var recoveredAircraft=b.Aircraft;
   recoveredAircraft.Grounded=false;recoveredAircraft.Speed=85;recoveredAircraft.transform.position=new Vector3(0,b.World.HeightAt(Vector3.zero)+recoveredAircraft.GroundClearance+30,0);recoveredAircraft.Elapsed=200;recovered.SendMessage("Update");
   Require(!recovered.WaitingForTakeoff&&recovered.PreparingChallenge&&recovered.EmergencyElapsed==0&&recoveredAircraft.LeftEngine&&recoveredAircraft.RightEngine,"Recovered preparation contact could not retakeoff into healthy transit.");
   recoveredAircraft.transform.position=recovered.ChallengeEntry;recoveredAircraft.Heading=recovered.EntryHeading;recoveredAircraft.Elapsed=300;recovered.SendMessage("Update");Require(!recovered.PreparingChallenge&&recovered.EmergencyElapsed==0,"Recovered departure could not arm the entry.");
   float delay=recovered.FailureDelay;recoveredAircraft.Elapsed=300+delay-.01f;recovered.SendMessage("Update");Require(recoveredAircraft.LeftEngine,"Recovered challenge failure occurred before its new entry-relative delay.");recoveredAircraft.Elapsed=300+delay+.01f;recovered.SendMessage("Update");Require(!recoveredAircraft.LeftEngine&&recoveredAircraft.RightEngine,"Recovered challenge failure did not occur after its new entry-relative delay.");
   report.AppendLine("PASS recovered preparation contact -> retakeoff -> healthy transit -> entry -> failure timer measured from the new entry.");
   b.Mission.StartFlight(FlightMode.Hudson,assist:false,startOnRunway:false);ArmedLanding(b,FlightMode.Hudson);b.Mission.Touchdown();Require(b.Mission.Finished&&b.Mission.Success,"Original airborne Hudson scoring regressed.");
   report.AppendLine("PASS original airborne Hudson API remains scored normally.");passed=true;
  }finally{
   report.AppendLine("passed="+passed);Write("departure-contact-validation.txt",report.ToString());saved.Restore(b);b.Aircraft.enabled=oldEnabled;Debug.Log("SKYBOUND_DEPARTURE_CONTACT_COMPLETE "+report);
  }
  yield break;
 }

 public static IEnumerator RunRealtime(SkyboundBootstrap b){
  foreach(var key in Keys)Require(!FlightInput.Hold(key),"Release "+key+" before the live FixedUpdate departure test.");Require(FlightInput.FlightStick.sqrMagnitude<.001f,"Centre the hardware flight stick before the live departure test.");
  var saved=new SavedState(b);var report=new StringBuilder("Real-time KTEB1 departure: normal FixedUpdate and live asynchronous terrain streaming\n");var samples=new List<Sample>(9000);int failed=0;bool oldEnabled=b.Aircraft.enabled;
  var observer=new DepartureRealtimeObserver();observer.Install();
  try{
   b.HUD.Visual.Select(0);while(b.HUD.Visual.Loading)yield return null;b.Aircraft.enabled=true;b.CameraRig.Cockpit=b.CameraRig.Cabin=false;
   foreach(bool assist in new[]{true,false}){
    var m=b.Mission;var a=b.Aircraft;string label=assist?"assist":"manual pitch input";bool wasGrounded=true,crossedBoundary=false,ready=false;float sustained=0;string initialDem="";
    m.StartChallenge(ChallengeCatalog.CreateDefault(FlightMode.Hudson),assist,true);b.HUD.Menu=MenuPage.Flight;a.Active=false;Time.timeScale=0;
    float readyDeadline=Time.realtimeSinceStartup+42;while(!m.GroundStartReady&&Time.realtimeSinceStartup<readyDeadline){a.Active=false;yield return null;}
    Require(m.GroundStartReady&&b.World.SurfaceLoaded(a.transform.position)&&b.World.ElevationLoadedAt(a.transform.position),"Live runway start did not load imagery and elevation.");
    initialDem=DemKey(b.World,a.transform.position);a.TouchPitch=a.TouchRoll=0;a.Throttle=1;a.Gear=true;a.Flaps=1;a.Active=true;Time.timeScale=1;float began=Time.realtimeSinceStartup;int bounces=0;float peakClearance=0;
    observer.Tick=()=>{
     if(!a.Active)return;string key=DemKey(b.World,a.transform.position);if(key!=initialDem)crossedBoundary=true;
     if(!wasGrounded&&a.Grounded)bounces++;wasGrounded=a.Grounded;
     float clearance=a.HeightAboveGround-a.GroundClearance;peakClearance=Mathf.Max(peakClearance,clearance);
     if(!a.Grounded&&!m.WaitingForTakeoff&&clearance>15)sustained+=Time.fixedDeltaTime;else sustained=0;
     samples.Add(new Sample(label,Time.realtimeSinceStartup-began,Time.frameCount,m,a,b.World,key));
    };
    while(Time.realtimeSinceStartup-began<75&&!m.Finished&&sustained<2){
     if(!assist){a.Throttle=1;a.Gear=true;a.Flaps=1;a.TouchRoll=0;a.TouchPitch=a.Grounded?(a.Speed>a.StallSpeed*1.18f?Mathf.Clamp((8-a.Pitch)*.18f,-.5f,.5f):0):Mathf.Clamp((8-a.Pitch)*.12f,-.4f,.4f);}
     yield return null;
    }
    observer.Tick=null;samples.Add(new Sample(label,Time.realtimeSinceStartup-began,Time.frameCount,m,a,b.World,DemKey(b.World,a.transform.position)));ready=!m.Finished&&!a.Grounded&&!m.WaitingForTakeoff&&sustained>=2&&crossedBoundary;
    if(!ready)failed++;report.AppendLine($"{label}: passed={ready}, elapsed={a.Elapsed:F2}s, wall={Time.realtimeSinceStartup-began:F2}s, normal controller enabled={a.enabled}, waiting={m.WaitingForTakeoff}, preparing={m.PreparingChallenge}, grounded={a.Grounded}, crossed DEM={crossedBoundary}, start DEM={initialDem}, current DEM={DemKey(b.World,a.transform.position)}, bounces={bounces}, speed={a.Speed:F3}m/s, pitch={a.Pitch:F3}deg, gamma={a.FlightPathAngle:F3}deg, vertical speed={a.VerticalSpeed:F3}m/s, AGL={a.HeightAboveGround:F3}m, clearance={a.GroundClearance:F3}m, peak height above contact plane={peakClearance:F3}m, terrain ready={b.World.ElevationLoadedAt(a.transform.position)}, finished={m.Finished}, result={m.Result}");
    a.TouchPitch=a.TouchRoll=0;a.Active=false;Time.timeScale=0;WriteRealtime(report,samples);yield return null;
   }
   report.AppendLine("Two unaccelerated departures; no manual Step calls, no position/velocity teleports after spawn, and no streaming waits after initial runway ready. Manual run uses TouchPitch through the same ReadPitch controller path as keyboard input.");
  }finally{
   observer.Tick=null;observer.Dispose();WriteRealtime(report,samples);saved.Restore(b);b.Aircraft.enabled=oldEnabled;Debug.Log("SKYBOUND_REALTIME_DEPARTURE_COMPLETE failures="+failed+" "+report);
  }
  Require(failed==0,"Real-time departure failed in "+failed+" of 2 runs. See departure-realtime-validation.txt and departure-realtime-trace.csv.");
 }

 static void SetupPhase(SkyboundBootstrap b,FlightMode mode,bool preparing){
  var d=ChallengeCatalog.CreateDefault(mode);d.Id="custom-departure-validation-"+mode;b.Mission.StartChallenge(d,false,true);var a=b.Aircraft;a.Active=false;Time.timeScale=0;
  if(preparing){a.Grounded=false;a.Speed=65;a.transform.position=new Vector3(0,b.World.HeightAt(Vector3.zero)+a.GroundClearance+30,0);a.Elapsed=50;a.Active=true;b.Mission.SendMessage("Update");Require(!b.Mission.WaitingForTakeoff&&b.Mission.PreparingChallenge,"Could not establish pre-entry phase for "+mode);}
 }
 static void ContactFixture(SkyboundBootstrap b,float verticalSpeed,bool benign){var a=b.Aircraft;a.Speed=120/1.94384f;a.Pitch=4;a.Roll=3;a.VerticalSpeed=verticalSpeed;a.Gear=true;a.Stalled=benign;a.Grounded=false;a.Active=true;a.Elapsed=60;Set(a,"FlightPathAngle",verticalSpeed>0?2:-2);Set(a,"PitchRate",1);Set(a,"RollRate",1);var p=a.transform.position;p.y=b.World.HeightAt(p)+a.GroundClearance;a.transform.position=p;}
 static void ArmedLanding(SkyboundBootstrap b,FlightMode mode){var a=b.Aircraft;var m=b.Mission;a.Speed=80;a.Pitch=4;a.Roll=0;a.VerticalSpeed=-2;a.Stalled=a.Grounded=false;a.Gear=mode!=FlightMode.Hudson&&mode!=FlightMode.GearFailure;a.GearJammedUp=mode==FlightMode.GearFailure;Set(a,"FlapPosition",mode==FlightMode.GearFailure?2:1);var p=mode==FlightMode.Hudson?b.World.Local(40.760,-74.014):m.RunwayStart+(m.RunwayEnd-m.RunwayStart)*.1f;p.y=b.World.HeightAt(p)+a.GroundClearance;a.transform.position=p;var axis=m.RunwayEnd-m.RunwayStart;a.Heading=Mathf.Atan2(axis.x,axis.z)*Mathf.Rad2Deg;}
 static void Set(FlightController a,string property,float value){var field=typeof(FlightController).GetField("<"+property+">k__BackingField",BindingFlags.Instance|BindingFlags.NonPublic);Require(field!=null,"Simulation fixture property missing: "+property);field.SetValue(a,value);}
 static string DemKey(SatelliteWorld w,Vector3 p){var f=GeoMath.TileFraction(w.Origin.x+p.x/w.Scale,w.Origin.y+p.z/w.Scale,12);return "12/"+(int)Math.Floor(f.x)+"/"+(int)Math.Floor(f.y);}
 static void Write(string name,string value)=>File.WriteAllText(Path.Combine(Application.dataPath,"../../"+name),value);
 static void WriteRealtime(StringBuilder report,List<Sample> samples){Write("departure-realtime-validation.txt",report.ToString());var csv=new StringBuilder("run,wallSeconds,frame,simSeconds,DEM,DEMReady,groundHeight,altitude,AGL,groundClearance,heightAboveContactPlane,airspeed,pitch,gamma,verticalSpeed,grounded,waiting,preparing,finished,latitude,longitude\n");foreach(var sample in samples)sample.Append(csv);Write("departure-realtime-trace.csv",csv.ToString());}
 static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
 struct Sample {
  string run,dem;float wall,time,ground,alt,agl,clearance,speed,pitch,gamma,vertical;int frame;bool loaded,grounded,waiting,preparing,finished;double lat,lon;
  public Sample(string run,float wall,int frame,MissionDirector m,FlightController a,SatelliteWorld w,string dem){this.run=run;this.wall=wall;this.frame=frame;this.dem=dem;time=a.Elapsed;ground=w.HeightAt(a.transform.position);alt=a.Altitude;agl=alt-ground;clearance=a.GroundClearance;speed=a.Speed;pitch=a.Pitch;gamma=a.FlightPathAngle;vertical=a.VerticalSpeed;loaded=w.ElevationLoadedAt(a.transform.position);grounded=a.Grounded;waiting=m.WaitingForTakeoff;preparing=m.PreparingChallenge;finished=m.Finished;var c=a.Coordinates;lat=c.x;lon=c.y;}
  public void Append(StringBuilder s){s.Append(run).Append(',').Append(F(wall)).Append(',').Append(frame).Append(',').Append(F(time)).Append(',').Append(dem).Append(',').Append(loaded).Append(',').Append(F(ground)).Append(',').Append(F(alt)).Append(',').Append(F(agl)).Append(',').Append(F(clearance)).Append(',').Append(F(agl-clearance)).Append(',').Append(F(speed)).Append(',').Append(F(pitch)).Append(',').Append(F(gamma)).Append(',').Append(F(vertical)).Append(',').Append(grounded).Append(',').Append(waiting).Append(',').Append(preparing).Append(',').Append(finished).Append(',').Append(lat.ToString("F8",CultureInfo.InvariantCulture)).Append(',').Append(lon.ToString("F8",CultureInfo.InvariantCulture)).AppendLine();}
  static string F(float v)=>v.ToString("F4",CultureInfo.InvariantCulture);
 }
 sealed class SavedState {
  ChallengeDefinition challenge;FlightMode mode;bool runway,assist,hadCompletion;double lat,lon;string place,completion;
  public SavedState(SkyboundBootstrap b){challenge=b.Mission.CurrentChallenge?.Copy();mode=b.Mission.Mode;runway=b.Mission.RunwayStartMode;assist=b.Aircraft.Assist;lat=b.World.Latitude;lon=b.World.Longitude;place=b.Mission.Place;hadCompletion=PlayerPrefs.HasKey(CompletionKey);completion=PlayerPrefs.GetString(CompletionKey,"");}
  public void Restore(SkyboundBootstrap b){if(hadCompletion)PlayerPrefs.SetString(CompletionKey,completion);else PlayerPrefs.DeleteKey(CompletionKey);PlayerPrefs.Save();if(challenge!=null)b.Mission.StartChallenge(challenge,assist,runway);else b.Mission.StartFlight(mode,lat,lon,place,assist,runway);b.Aircraft.TouchPitch=b.Aircraft.TouchRoll=0;b.Aircraft.Active=false;Time.timeScale=0;b.HUD.Menu=MenuPage.Discover;b.CameraRig.Discover=true;}
 }
}
sealed class DepartureRealtimeObserver:IDisposable {
 public Action Tick;
 PlayerLoopSystem original;bool installed;
 public void Install(){original=PlayerLoop.GetCurrentPlayerLoop();var next=Clone(original);if(!Insert(ref next))throw new InvalidOperationException("The live player loop has no FixedUpdate phase.");PlayerLoop.SetPlayerLoop(next);installed=true;}
 public void Dispose(){if(installed)PlayerLoop.SetPlayerLoop(original);installed=false;Tick=null;}
 static PlayerLoopSystem Clone(PlayerLoopSystem source){if(source.subSystemList!=null){var copy=new PlayerLoopSystem[source.subSystemList.Length];for(int i=0;i<copy.Length;i++)copy[i]=Clone(source.subSystemList[i]);source.subSystemList=copy;}return source;}
 bool Insert(ref PlayerLoopSystem loop){if(loop.type==typeof(UnityEngine.PlayerLoop.FixedUpdate)){var children=loop.subSystemList??new PlayerLoopSystem[0];var replacement=new PlayerLoopSystem[children.Length+1];Array.Copy(children,replacement,children.Length);replacement[children.Length]=new PlayerLoopSystem{type=typeof(DepartureRealtimeObserver),updateDelegate=()=>Tick?.Invoke()};loop.subSystemList=replacement;return true;}if(loop.subSystemList!=null)for(int i=0;i<loop.subSystemList.Length;i++){var child=loop.subSystemList[i];if(Insert(ref child)){loop.subSystemList[i]=child;return true;}}return false;}
}
}
#endif
