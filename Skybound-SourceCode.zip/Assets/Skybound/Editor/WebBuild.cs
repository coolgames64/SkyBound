#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
namespace Skybound.Editor {
public static class WebBuild {
 public static void Build() {
  string output=Path.GetFullPath("../../outputs/SkyboundWeb");
  var args=Environment.GetCommandLineArgs();
  for(int i=0;i<args.Length-1;i++)if(args[i]=="-buildOutput")output=Path.GetFullPath(args[i+1]);
  if(!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.WebGL,BuildTarget.WebGL))throw new Exception("Web build module missing");
  McasValidation.Run();
  SceneBuilder.EnsureShaders();SceneBuilder.ConvertMaterials();SceneBuilder.UpdateCatalog();
  PlayerSettings.WebGL.compressionFormat=WebGLCompressionFormat.Gzip;
  PlayerSettings.WebGL.decompressionFallback=true;
  PlayerSettings.WebGL.initialMemorySize=128;
  PlayerSettings.WebGL.maximumMemorySize=1024;
  PlayerSettings.WebGL.dataCaching=true;
  PlayerSettings.WebGL.template="PROJECT:Skybound";
  PlayerSettings.SetManagedStrippingLevel(NamedBuildTarget.WebGL,ManagedStrippingLevel.Low);
  PlayerSettings.defaultWebScreenWidth=1440;PlayerSettings.defaultWebScreenHeight=900;
  PlayerSettings.runInBackground=false;
  EditorUserBuildSettings.webGLBuildSubtarget=WebGLTextureSubtarget.Generic;
  var scenes=EditorBuildSettings.scenes.Where(s=>s.enabled).Select(s=>s.path).ToArray();
  if(scenes.Length==0)throw new Exception("No enabled scene");
  var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=scenes,locationPathName=output,target=BuildTarget.WebGL,options=BuildOptions.None});
  File.WriteAllText(Path.GetFullPath("../../work/web-build-summary.json"),JsonUtility.ToJson(new Summary{result=report.summary.result.ToString(),errors=report.summary.totalErrors,warnings=report.summary.totalWarnings,bytes=report.summary.totalSize,output=output},true));
  if(report.summary.result!=BuildResult.Succeeded)throw new Exception("Web build failed: "+report.summary.result);
 }
 [Serializable] class Summary {public string result,output;public int errors,warnings;public ulong bytes;}
}
}
#endif
