#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;

namespace Skybound.Editor {
// Isolated cabin generation and geometric checks; the selected aircraft/mission/camera are not changed.
public static class CabinVisualValidation {
 public static IEnumerator Run(SkyboundBootstrap bootstrap){
  var lines=new List<string>{"V5 passenger cabin geometry, presentation budget and resource lifetime"};
  var holder=new GameObject("Isolated passenger cabin validation");bool complete=false;string stage="initialization";
  string output=Path.GetFullPath(Path.Combine(Application.dataPath,"../../cabin-visual-validation.txt"));
  int[] baselineSeats={144,336,186,120,186,156,450,192,228,468,352,125,296,248,352,352,376,510,172,304,64,92,64};
  try{
   Require(bootstrap&&bootstrap.Catalog&&bootstrap.Catalog.Aircraft.Length==baselineSeats.Length,"Expected the included 23-aircraft catalog.");
   int largestTriangles=0,largestVertices=0;double longestBuild=0;
   for(int index=0;index<bootstrap.Catalog.Aircraft.Length;index++){
    var entry=bootstrap.Catalog.Aircraft[index];stage=entry.Name;
    var clock=Stopwatch.StartNew();var cabin=AircraftCabin.Create(holder.transform,entry.Length,entry.Name,3.5f);clock.Stop();
    Require(cabin.SeatCount==baselineSeats[index],"The existing seating layout changed for "+stage);
    Require(cabin.Width>=2.5f&&cabin.Width<=6.45f&&Close(cabin.Length,Mathf.Clamp(entry.Length*.69f,12,52)),"Cabin dimensions changed for "+stage);
    Require(Close(cabin.transform.localPosition.y,3.5f)&&cabin.transform.localScale==Vector3.one,"Cabin floor placement or scale changed.");
    float originalAisle=cabin.Width>4?cabin.Width>=6.1f?1.25f:cabin.Width>=5.8f?.97f:1.25f:0;
    Require((cabin.EyeOffset-new Vector3(originalAisle,1.43f,-cabin.Length*.22f)).sqrMagnitude<.000001f,"Cabin camera offset changed for "+stage);
    Require(cabin.GetComponentsInChildren<Collider>(true).Length==0,"A visual cabin acquired physics colliders.");
    Require(cabin.GetComponentsInChildren<Light>(true).Length==0,"Cabin added real-time light/shadow cost.");
    var renderers=cabin.GetComponentsInChildren<MeshRenderer>(true);var filters=cabin.GetComponentsInChildren<MeshFilter>(true);
    Require(renderers.Length==AircraftCabin.RendererBudget&&renderers.Length==cabin.BatchedRendererCount&&filters.Length==renderers.Length,"Cabin exceeded its eight material-batch budget.");
    int triangleCount=0,vertexCount=0;var snapshots=new List<Geometry>();var owned=new List<UnityEngine.Object>();
    foreach(var filter in filters){
     var mesh=filter.sharedMesh;Require(mesh&&mesh.vertexCount>0&&mesh.subMeshCount==1,"Cabin batch is empty or has extra draw submeshes.");
     var vertices=mesh.vertices;var normals=mesh.normals;var uv=mesh.uv;var triangles=mesh.triangles;
     Require(normals.Length==vertices.Length&&uv.Length==vertices.Length,"A cabin batch lacks authored normals or texture UVs.");
     for(int v=0;v<vertices.Length;v++)Require(Finite(vertices[v])&&Finite(normals[v])&&Finite(uv[v].x)&&Finite(uv[v].y)&&normals[v].sqrMagnitude>.9f,"Invalid cabin geometry or normals: "+filter.name);
     triangleCount+=triangles.Length/3;vertexCount+=vertices.Length;
     snapshots.Add(new Geometry{ Name=filter.name,Vertices=vertices,Triangles=triangles });owned.Add(mesh);
    }
    Require(triangleCount==cabin.TriangleCount&&vertexCount==cabin.VertexCount&&triangleCount<=AircraftCabin.TriangleBudget,"Cabin geometry exceeded the bounded detail budget.");
    foreach(var renderer in renderers){
     Require(renderer.sharedMaterials.Length==1&&renderer.sharedMaterial,"Unexpected cabin material count.");var material=renderer.sharedMaterial;owned.Add(material);
     Require(material.renderQueue<2500&&(!material.HasProperty("_Surface")||material.GetFloat("_Surface")==0),"Cabin structural material is transparent.");
     Require(!renderer.receiveShadows&&renderer.shadowCastingMode==UnityEngine.Rendering.ShadowCastingMode.Off,"Cabin adds repeated shadow passes.");
     if(material.mainTexture&&material.mainTexture.name.StartsWith("Cabin ")&&!owned.Contains(material.mainTexture))owned.Add(material.mainTexture);
    }
    Require(cabin.OwnedTextureCount==3&&owned.Count==19,"Cabin textures/materials are not shared within each instance as expected.");
    Require(cabin.WindowCount>=16&&cabin.BinDoorCount>=16,"Windows or overhead-bin modules are missing.");
    // Ray/triangle intersection independently proves the opening is empty, and adjacent wall is closed.
    var structural=snapshots.FindAll(g=>g.Name.Contains("shell")||g.Name.Contains("reveals")||g.Name.Contains("seams"));
    int tested=0;int stride=Mathf.Max(1,cabin.WindowCount/6);
    for(int window=0;window<cabin.WindowCount;window+=stride){
     Vector3 center=cabin.WindowCenters[window];float side=Mathf.Sign(center.x);var direction=new Vector3(side,0,0);
     Require(!Hit(structural,center-direction*.13f,direction,.25f),"A supposedly open oval window is filled by cabin geometry.");
     Require(Hit(structural,center+Vector3.forward*.415f-direction*.13f,direction,.25f),"The wall between neighbouring oval windows is open.");tested++;
    }
    foreach(var direction in new[]{Vector3.left,Vector3.right,Vector3.up,Vector3.down,Vector3.forward,Vector3.back})
     Require(!Hit(snapshots,cabin.EyeOffset,direction,.045f),"The preserved cabin eye/near clip intersects cabin geometry.");
    largestTriangles=Mathf.Max(largestTriangles,triangleCount);largestVertices=Mathf.Max(largestVertices,vertexCount);longestBuild=Math.Max(longestBuild,clock.Elapsed.TotalMilliseconds);
    lines.Add($"PASS {stage}: seats={cabin.SeatCount}, windows={cabin.WindowCount}, bin doors={cabin.BinDoorCount}, renderers={renderers.Length}, triangles={triangleCount}, vertices={vertexCount}, build={clock.Elapsed.TotalMilliseconds:F2}ms; {tested} clear oval/closed-wall ray samples, preserved eye and floor");
    cabin.gameObject.SetActive(false);UnityEngine.Object.Destroy(cabin.gameObject);yield return null;yield return null;yield return null;
    foreach(var resource in owned)Require(!resource,"Cabin destruction leaked a generated mesh, material or texture.");
   }
   stage="layout bounds";
   foreach(float length in new[]{0f,500f}){
    var cabin=AircraftCabin.Create(holder.transform,length,"Airbus A380-800",0);
    Require(cabin.Length>=12&&cabin.Length<=52&&cabin.TriangleCount<=AircraftCabin.TriangleBudget,"Minimum/maximum generated-cabin detail is unbounded.");
    UnityEngine.Object.Destroy(cabin.gameObject);yield return null;yield return null;
   }
   lines.Add($"PASS all 23 stock layouts, bounded length, opaque structural materials, no colliders/realtime lights, resource disposal; maximum triangles={largestTriangles}, vertices={largestVertices}, measured longest synchronous generation={longestBuild:F2}ms.");
   lines.Add("Visual review still required in cabin camera on narrow-body and wide-body: seat shaping, window reveals, bins, carpet, galley/EXIT signs. No frame-rate or native mobile claim follows from geometry/batch counts.");
   complete=true;UnityEngine.Debug.Log("SKYBOUND_CABIN_VISUALS_PASSED "+string.Join("; ",lines));
  }finally{
   if(!complete)lines.Add("FAIL during "+stage+"; see Editor exception for the exact assertion.");
   UnityEngine.Object.Destroy(holder);File.WriteAllLines(output,lines);
  }
 }
 sealed class Geometry {public string Name;public Vector3[] Vertices;public int[] Triangles;}
 static bool Hit(List<Geometry> geometry,Vector3 origin,Vector3 direction,float limit){
  foreach(var mesh in geometry)for(int i=0;i<mesh.Triangles.Length;i+=3){
   Vector3 a=mesh.Vertices[mesh.Triangles[i]],b=mesh.Vertices[mesh.Triangles[i+1]],c=mesh.Vertices[mesh.Triangles[i+2]];
   Vector3 edge1=b-a,edge2=c-a,p=Vector3.Cross(direction,edge2);float determinant=Vector3.Dot(edge1,p);
   if(Mathf.Abs(determinant)<.0000001f)continue;
   float inv=1/determinant;Vector3 delta=origin-a;float u=Vector3.Dot(delta,p)*inv;if(u<0||u>1)continue;
   Vector3 q=Vector3.Cross(delta,edge1);float v=Vector3.Dot(direction,q)*inv;if(v<0||u+v>1)continue;
   float distance=Vector3.Dot(edge2,q)*inv;if(distance>.00001f&&distance<=limit)return true;
  }
  return false;
 }
 static bool Finite(float value)=>!float.IsNaN(value)&&!float.IsInfinity(value);
 static bool Finite(Vector3 value)=>Finite(value.x)&&Finite(value.y)&&Finite(value.z);
 static bool Close(float a,float b)=>Mathf.Abs(a-b)<.0001f;
 static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
}
}
#endif
