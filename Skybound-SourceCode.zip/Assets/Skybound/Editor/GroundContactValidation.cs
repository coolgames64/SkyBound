#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace Skybound.Editor {
public static class GroundContactValidation {
 public static IEnumerator Run(SkyboundBootstrap b){
  if(!b||!b.Aircraft||!b.HUD||!b.HUD.Visual||!b.World)throw new InvalidOperationException("Ground-contact validation needs the running Skybound scene.");
  var a=b.Aircraft;var visual=b.HUD.Visual;var mission=b.Mission;var savedMission=a.Mission;
  var savedMode=mission.Mode;bool savedFinished=mission.Finished,savedSuccess=mission.Success;string savedResult=mission.Result,savedMessage=mission.Message;
  float savedNotice=mission.NoticeUntil,savedSink=mission.LandingSink,savedSpeed=mission.LandingSpeed,savedBank=mission.LandingBank;
  var lines=new List<string>{"Skybound model-based ground-contact validation"};
  bool completed=false;string stage="World surface readiness";
  string output=Path.GetFullPath(Path.Combine(Application.dataPath,"../../ground-contact-validation.txt"));
  Time.timeScale=0;a.Active=false;a.Mission=null;b.HUD.Menu=MenuPage.Flight;b.CameraRig.Discover=false;b.CameraRig.Cockpit=b.CameraRig.Cabin=false;a.Visual.gameObject.SetActive(true);
  try {
   Vector3 origin=Vector3.zero;
   if(!b.World.SurfaceLoaded(origin))throw new InvalidOperationException("Load the scenery at the current world origin before running ground-contact validation.");
   for(int i=0;i<b.Catalog.Aircraft.Length;i++){
    stage=b.Catalog.Aircraft[i].Name;
    visual.Select(i);float deadline=Time.realtimeSinceStartup+25;
    do{yield return null;}while(visual.Loading&&Time.realtimeSinceStartup<deadline);
    if(visual.Loading)throw new InvalidOperationException("Aircraft loading timed out: "+b.Catalog.Aircraft[i].Name);
    yield return null; // Allow the previous model's deferred destruction to finish.
    Require(visual.GearUpClearance>0&&visual.GearDownClearance>=visual.GearUpClearance,"Invalid cached clearance for "+visual.AircraftName);
    float up=ContactCase(a,visual,b.World,false,0,0,true);
    float down=ContactCase(a,visual,b.World,true,0,0,true);
    lines.Add($"PASS {visual.AircraftName}: gear-up clearance={visual.GearUpClearance:F3} m, gear-down={visual.GearDownClearance:F3} m; lowest visible renderer above terrain up/down={up:F3}/{down:F3} m");
    if(i==0){
     float flare=ContactCase(a,visual,b.World,true,7,0,true);
     float banked=ContactCase(a,visual,b.World,true,7,15,false);
     lines.Add($"PASS A320 flared/banked contact: pitch7 degrees, bank0/15 degrees; lowest renderer clearance={flare:F3}/{banked:F3} m");
    }
   }

   stage="Successful free-flight touchdown";visual.Select(0);while(visual.Loading)yield return null;yield return null;
   Require(!b.World.LooksLikeWater(origin),"Free-flight touchdown check needs a loaded land location such as Heathrow.");
   a.ResetFlight(b.World.HeightAt(origin)+1,70,0,false);a.Gear=true;a.Pitch=0;a.Roll=0;a.VerticalSpeed=-2;a.Stalled=false;a.Grounded=false;
   mission.Mode=FlightMode.FreeFlight;mission.Finished=false;mission.Success=false;mission.Result="";a.Mission=mission;
   mission.Touchdown();
   Require(mission.Success&&a.Grounded&&!mission.Finished,"Gentle free-flight landing did not reach the successful taxi state.");
   float expected=b.World.HeightAt(a.transform.position)+a.GroundClearance;
   Require(Mathf.Abs(a.Altitude-expected)<.01f,"Successful free-flight touchdown returned before clamping the model to its contact height.");
   SyncVisual(a,visual);float bottom=LowestRenderer(visual)-b.World.HeightAt(a.transform.position);
   Require(bottom>=-.05f,"Free-flight landing model penetrated terrain by "+(-bottom).ToString("F3")+" m.");
   lines.Add($"PASS successful free-flight landing clamps before taxi return: center={a.Altitude:F3} m, floor={expected:F3} m, model bottom above terrain={bottom:F3} m");
   completed=true;Debug.Log("SKYBOUND_GROUND_CONTACT_PASSED "+string.Join("; ",lines));
  }
  finally {
   if(!completed)lines.Add("FAIL during "+stage+"; see the Editor exception for the exact failed assertion.");File.WriteAllLines(output,lines);
   a.Mission=savedMission;mission.Mode=savedMode;mission.Finished=savedFinished;mission.Success=savedSuccess;mission.Result=savedResult;mission.Message=savedMessage;
   mission.NoticeUntil=savedNotice;mission.LandingSink=savedSink;mission.LandingSpeed=savedSpeed;mission.LandingBank=savedBank;
   if(visual.Selected!=0)visual.Select(0);a.ResetFlight(Mathf.Max(650,b.World.HeightAt(Vector3.zero)+650),85,208,false);SyncVisual(a,visual);
   Time.timeScale=0;b.HUD.Menu=MenuPage.Discover;b.CameraRig.Discover=true;b.CameraRig.Cockpit=false;
  }
 }

 static float ContactCase(FlightController a,AircraftVisual visual,SatelliteWorld world,bool gear,float pitch,float roll,bool grounded){
  a.ResetFlight(world.HeightAt(Vector3.zero)+1,grounded?0:70,0,false);a.Engines=false;a.Throttle=0;a.Assist=false;a.Gear=gear;a.Pitch=pitch;a.Roll=roll;a.Grounded=grounded;
  // Begin below the computed contact plane; a simulation step must repair the position.
  a.transform.position=new Vector3(0,world.HeightAt(Vector3.zero)+a.GroundClearance-2,0);
  a.Step(.02f,0,0);SyncVisual(a,visual);
  float ground=world.HeightAt(a.transform.position),floor=ground+a.GroundClearance;
  Require(a.Altitude>=floor-.01f,"Simulation center penetrated its contact plane: "+visual.AircraftName);
  float bottom=LowestRenderer(visual)-ground;
  Require(bottom>=-.05f,$"{visual.AircraftName} rendered below terrain: gear={gear}, pitch={pitch:F1}, bank={roll:F1}, bottom={bottom:F3} m");
  return bottom;
 }
 static void SyncVisual(FlightController a,AircraftVisual visual){visual.SendMessage("LateUpdate");a.SendMessage("LateUpdate");}
 static float LowestRenderer(AircraftVisual visual){
  int count=0;float minimum=float.PositiveInfinity;
  foreach(var renderer in visual.GetComponentsInChildren<Renderer>(false)){
   // Hidden imported blur discs and the inactive interiors are not visible contact geometry.
   if(!renderer.gameObject.activeInHierarchy||!renderer.enabled)continue;
   count++;minimum=Mathf.Min(minimum,renderer.bounds.min.y);
  }
  Require(count>0,"The selected aircraft has no active renderers: "+visual.AircraftName);return minimum;
 }
 static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
}
}
#endif
