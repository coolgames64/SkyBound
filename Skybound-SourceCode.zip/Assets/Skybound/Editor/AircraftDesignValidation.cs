#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;

namespace Skybound.Editor {
public static class AircraftDesignValidation {
 public static IEnumerator Run(SkyboundBootstrap b){
  var report=new StringBuilder("Included-airframe design validation\n");ValidateStore(report);ValidateTuning(report);
  var visual=b.HUD.Visual;var a=b.Aircraft;int savedIndex=visual.Selected;var savedDesign=visual.SelectedDesign==null?null:AircraftDesignStore.Sanitize(visual.SelectedDesign,b.Catalog.Aircraft.Length);
  bool complete=false;float savedTimeScale=Time.timeScale;bool savedActive=a.Active;
  int baseIndex=Array.FindIndex(b.Catalog.Aircraft,entry=>entry.Name.Contains("737"));Require(baseIndex>=0,"737 base model is missing.");
  Time.timeScale=0;a.Active=false;
  try {
   visual.Select(baseIndex);yield return WaitForSelection(visual);visual.SetCabinVisible(true);
   float length=visual.AircraftLength,up=visual.GearUpClearance,down=visual.GearDownClearance;string source=visual.Source;
   var materials=SourceMaterialColours(visual.ExteriorModel);var originalCockpit=SourceMaterialColours(visual.CockpitModel);
   int deckComponents=visual.CockpitModel.GetComponentsInChildren<Component>(true).Length;
   var originalCabin=visual.CabinModel.GetComponent<AircraftCabin>();float width=originalCabin.Width;int seats=originalCabin.SeatCount;
   var design=new AircraftDesign{Id=Guid.NewGuid().ToString("N"),Name="Airbus A350 custom test",BaseAircraftIndex=baseIndex,Tint=new Color(.35f,.65f,.9f),ThrustMultiplier=1.2f,ControlSensitivity=.8f};
   visual.SelectDesign(design);yield return WaitForSelection(visual);visual.SetCabinVisible(true);
   Require(visual.SelectedDesign!=null&&visual.SelectedDesign.Id==design.Id&&visual.AircraftName==design.Name,"Design name/id was not applied.");
   Require(visual.Selected==baseIndex&&visual.StockAircraftName==b.Catalog.Aircraft[baseIndex].Name&&visual.Source==source,"Custom name changed base selection or credits.");
   Require(!a.RATAvailable,"A custom name incorrectly granted A350 RAT capability to a 737.");
   Require(Close(a.ThrustMultiplier,1.2f)&&Close(a.ControlSensitivity,.8f),"Selected design tuning was not applied.");
   Require(Close(visual.AircraftLength,length)&&Close(visual.GearUpClearance,up)&&Close(visual.GearDownClearance,down),"Design changed the airframe dimensions or ground clearance.");
   var cabin=visual.CabinModel.GetComponent<AircraftCabin>();Require(Close(cabin.Width,width)&&cabin.SeatCount==seats,"Custom name changed cabin dimensions or seat layout.");
   Require(!visual.UsesSharedCockpit&&visual.CockpitModel.name=="A320 flight deck"&&visual.CockpitModel.GetComponentsInChildren<Component>(true).Length==deckComponents,"Design did not retain the exact imported A320 cockpit components.");
   Require(CountTintedRenderers(visual.ExteriorModel)>0,"Design tint was not installed as a renderer property block.");
   Require(UnmodifiedSourceMaterials(materials)&&UnmodifiedSourceMaterials(originalCockpit),"Design mutated shared source material colours.");
   Require(NoPropertyBlocks(visual.CockpitModel)&&NoPropertyBlocks(visual.CabinModel),"Design tint reached cockpit or cabin.");
   var rat=visual.GetComponentInChildren<RamAirTurbine>(true);Require(!rat||NoPropertyBlocks(rat.gameObject),"Design tint reached the RAT.");
   ValidateSlideWidth(visual,report);
   report.AppendLine("PASS async design selection retains the original airframe dimensions, cabin layout, source credits and base RAT capability; only exterior instance property blocks are tinted, not shared materials/cockpit/cabin/RAT.");
   visual.Select(baseIndex);yield return WaitForSelection(visual);
   Require(visual.SelectedDesign==null&&visual.AircraftName==visual.StockAircraftName&&a.ThrustMultiplier==1&&a.ControlSensitivity==1,"Stock selection retained custom state or tuning.");
   Require(NoPropertyBlocks(visual.ExteriorModel),"Stock selection retained the custom tint.");
   visual.SelectDesign(new AircraftDesign{Id=Guid.NewGuid().ToString("N"),Name="Boeing 707 custom test",BaseAircraftIndex=0});yield return WaitForSelection(visual);
   Require(a.RATAvailable&&visual.StockAircraftName==b.Catalog.Aircraft[0].Name,"Custom display name removed A320 RAT capability.");
   visual.SelectDesign(design);visual.Select(0);yield return WaitForSelection(visual);
   Require(visual.Selected==0&&visual.SelectedDesign==null&&a.ThrustMultiplier==1&&a.ControlSensitivity==1,"Superseded async design selection overwrote the latest stock selection.");
   report.AppendLine("PASS stock selection clears design/name/tint/tuning; both fitted and unfitted base RAT capabilities survive custom names; superseded async selections stay cancelled.");
   complete=true;Debug.Log("SKYBOUND_AIRCRAFT_DESIGNS_PASSED "+report);
  }finally {
   if(!complete)report.AppendLine("FAIL: see Editor assertion.");File.WriteAllText("aircraft-design-validation.txt",report.ToString());
   visual.SetCabinVisible(false);if(savedDesign!=null)visual.SelectDesign(savedDesign);else visual.Select(savedIndex);a.Active=savedActive;Time.timeScale=savedTimeScale;
  }
 }
 static void ValidateSlideWidth(AircraftVisual visual,StringBuilder report){
  var originalController=visual.Aircraft;var testObject=new GameObject("Stopped custom-airframe slide validation");var slides=EmergencySlides.For(visual);
  try {
   // Use an isolated controller so evacuation cannot change the real plane or mission state.
   var stopped=testObject.AddComponent<FlightController>();stopped.enabled=false;stopped.Visual=visual.transform;stopped.ResetFlight(visual.GearUpClearance,0,0,false);stopped.Grounded=true;visual.Aircraft=stopped;
   Require(slides.CanDeploy,"Stopped custom 737 could not deploy slides.");slides.Deploy();Require(slides.Deployed,"Custom 737 evacuation did not create slides.");
   float expected=AircraftCabin.WidthFor(visual.StockAircraftName)*.51f;int doors=0;
   foreach(Transform child in visual.transform)if(child.name=="Inflatable exit slide"){doors++;Require(Close(Mathf.Abs(child.localPosition.x),expected),"Custom A350 display name changed the 737 exit-slide door width.");}
   Require(doors==4,"Expected four exit-slide door stations on the base 737.");
   report.AppendLine($"PASS stopped 737 named A350 retains base-family slide door x=±{expected:F3}m across four doors; real aircraft/mission fields untouched.");
  }finally {slides.ResetSlides();visual.Aircraft=originalController;UnityEngine.Object.Destroy(testObject);}
 }
 static void ValidateStore(StringBuilder report){
  bool existed=PlayerPrefs.HasKey(AircraftDesignStore.PreferenceKey);string original=PlayerPrefs.GetString(AircraftDesignStore.PreferenceKey,"");
  try {
   PlayerPrefs.DeleteKey(AircraftDesignStore.PreferenceKey);
   var draft=new AircraftDesign{Id=Guid.NewGuid().ToString("N"),Name="  <Test>\n\0 aircraft  ",BaseAircraftIndex=999,Tint=new Color(float.NaN,-1,2,0),ThrustMultiplier=float.NaN,ControlSensitivity=100};
   var saved=AircraftDesignStore.Save(draft);Require(saved!=null&&saved.Name=="Test aircraft"&&saved.BaseAircraftIndex==22,"Design name/base sanitization failed.");
   Require(saved.Tint==new Color(1,0,1,1)&&saved.ThrustMultiplier==1&&saved.ControlSensitivity==1.25f,"Non-finite/out-of-range design values were not sanitized.");
   var loaded=AircraftDesignStore.Load();Require(loaded.Count==1&&loaded[0].Id==saved.Id&&loaded[0].Name==saved.Name&&loaded[0].Tint==saved.Tint,"PlayerPrefs JSON roundtrip changed design identity or colour.");
   saved.Name="Updated design";Require(AircraftDesignStore.Save(saved)!=null&&AircraftDesignStore.Load().Count==1&&AircraftDesignStore.Load()[0].Name==saved.Name,"Saving an existing ID duplicated it.");
   for(int i=1;i<AircraftDesignStore.MaxDesigns;i++)Require(AircraftDesignStore.Save(new AircraftDesign{Id=Guid.NewGuid().ToString("N"),Name="Design "+i})!=null,"Design capacity filled too early.");
   Require(AircraftDesignStore.Save(new AircraftDesign{Id=Guid.NewGuid().ToString("N")})==null&&AircraftDesignStore.Load().Count==AircraftDesignStore.MaxDesigns,"Design capacity limit failed.");
   Require(AircraftDesignStore.Delete(saved.Id)&&!AircraftDesignStore.Delete(saved.Id)&&AircraftDesignStore.Load().Count==AircraftDesignStore.MaxDesigns-1,"Delete failed or removed unrelated designs.");
   Require(AircraftDesignStore.Deserialize("{invalid json").Count==0&&AircraftDesignStore.Deserialize("{\"Version\":2,\"Designs\":[]}").Count==0,"Invalid/unsupported JSON was accepted.");
   var oversized=new List<AircraftDesign>();for(int i=0;i<30;i++)oversized.Add(new AircraftDesign{Id=Guid.NewGuid().ToString("N"),Name=new string('X',70)});
   var bounded=AircraftDesignStore.Deserialize(AircraftDesignStore.Serialize(oversized));Require(bounded.Count==20&&bounded[0].Name.Length==40,"Serialized design/name bounds failed.");
   report.AppendLine("PASS saved JSON roundtrip, update, delete, 20-design limit, 40-character names, invalid JSON handling, colour sanitization and finite .75–1.25 tuning. Original preference value preserved.");
  }finally {if(existed)PlayerPrefs.SetString(AircraftDesignStore.PreferenceKey,original);else PlayerPrefs.DeleteKey(AircraftDesignStore.PreferenceKey);PlayerPrefs.Save();}
 }
 static void ValidateTuning(StringBuilder report){
  var stockObject=new GameObject("Stock tuning validation");var tunedObject=new GameObject("Design tuning validation");
  try {
   var stock=stockObject.AddComponent<FlightController>();var tuned=tunedObject.AddComponent<FlightController>();stock.enabled=tuned.enabled=false;
   Require(stock.ThrustMultiplier==1&&stock.ControlSensitivity==1,"Stock tuning defaults changed.");
   tuned.ThrustMultiplier=1.25f;tuned.ControlSensitivity=1.25f;stock.ResetFlight(2000,85,0,false);tuned.ResetFlight(2000,85,0,false);
   Require(tuned.ThrustMultiplier==1.25f&&tuned.ControlSensitivity==1.25f,"ResetFlight discarded selected tuning.");
   stock.Step(.02f,1,1);tuned.Step(.02f,1,1);Require(tuned.Speed>stock.Speed+.005f&&tuned.PitchRate>stock.PitchRate&&tuned.RollRate>stock.RollRate,"Tuning did not affect thrust and pilot input rates.");
   tuned.ThrustMultiplier=float.PositiveInfinity;tuned.ControlSensitivity=float.NaN;Require(tuned.ThrustMultiplier==1&&tuned.ControlSensitivity==1,"Controller accepted non-finite tuning.");
   tuned.ThrustMultiplier=-5;tuned.ControlSensitivity=10;Require(tuned.ThrustMultiplier==.75f&&tuned.ControlSensitivity==1.25f,"Controller tuning escaped safety bounds.");
   report.AppendLine("PASS stock tuning defaults1; design tuning changes thrust and pilot pitch/bank rates, stays finite/bounded, and survives ResetFlight.");
  }finally {UnityEngine.Object.Destroy(stockObject);UnityEngine.Object.Destroy(tunedObject);}
 }
 static IEnumerator WaitForSelection(AircraftVisual visual){float deadline=Time.realtimeSinceStartup+30;do{yield return null;}while(visual.Loading&&Time.realtimeSinceStartup<deadline);Require(!visual.Loading&&visual.ExteriorModel,"Timed out loading design/stock model.");yield return null;}
 static bool Close(float a,float b)=>Mathf.Abs(a-b)<.0001f;
 static int CountTintedRenderers(GameObject root){int count=0;var block=new MaterialPropertyBlock();foreach(var renderer in root.GetComponentsInChildren<Renderer>(true))for(int i=0;i<renderer.sharedMaterials.Length;i++){renderer.GetPropertyBlock(block,i);if(!block.isEmpty){count++;break;}}return count;}
 static bool NoPropertyBlocks(GameObject root)=>CountTintedRenderers(root)==0;
 static Dictionary<Material,Color> SourceMaterialColours(GameObject root){var result=new Dictionary<Material,Color>();foreach(var renderer in root.GetComponentsInChildren<Renderer>(true))foreach(var material in renderer.sharedMaterials)if(material&&!result.ContainsKey(material)){if(material.HasProperty("_BaseColor"))result.Add(material,material.GetColor("_BaseColor"));else if(material.HasProperty("_Color"))result.Add(material,material.GetColor("_Color"));}return result;}
 static bool UnmodifiedSourceMaterials(Dictionary<Material,Color> originals){foreach(var pair in originals)if(pair.Key){Color current=pair.Key.GetColor(pair.Key.HasProperty("_BaseColor")?"_BaseColor":"_Color");if(current!=pair.Value)return false;}return true;}
 static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
}
}
#endif
