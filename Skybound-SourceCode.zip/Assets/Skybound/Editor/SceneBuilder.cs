#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;
namespace Skybound.Editor {
[Serializable] public class FleetManifest {public FleetSpec[] aircraft;}
[Serializable] public class FleetSpec {public string id,name,source,license;public float length;}
public static class SceneBuilder {
 [MenuItem("Skybound/Create simulator scene")]
 public static void Create(){
  Directory.CreateDirectory("Assets/Skybound/Scenes");Directory.CreateDirectory("Assets/Skybound/Data");
  EnsureShaders();ConvertMaterials();
  var catalog=UpdateCatalog();
  var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);var go=new GameObject("Skybound simulator");go.AddComponent<SkyboundBootstrap>().Catalog=catalog;
  EditorSceneManager.SaveScene(scene,"Assets/Skybound/Scenes/Skybound.unity");EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene("Assets/Skybound/Scenes/Skybound.unity",true)};
  PlayerSettings.companyName="Skybound";PlayerSettings.productName="Skybound Flight Simulator";PlayerSettings.defaultScreenWidth=1440;PlayerSettings.defaultScreenHeight=900;PlayerSettings.fullScreenMode=FullScreenMode.FullScreenWindow;PlayerSettings.runInBackground=true;PlayerSettings.defaultInterfaceOrientation=UIOrientation.AutoRotation;PlayerSettings.allowedAutorotateToLandscapeLeft=true;PlayerSettings.allowedAutorotateToLandscapeRight=true;PlayerSettings.allowedAutorotateToPortrait=false;PlayerSettings.allowedAutorotateToPortraitUpsideDown=false;PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android,"com.skybound.flightsimulator");PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.iOS,"com.skybound.flightsimulator");
  Debug.Log("SKYBOUND_SCENE_READY");
 }
 [MenuItem("Skybound/Refresh aircraft catalog")]
 public static AircraftCatalog UpdateCatalog(){
  string path="Assets/Skybound/Data/AircraftCatalog.asset";var catalog=AssetDatabase.LoadAssetAtPath<AircraftCatalog>(path);if(!catalog){catalog=ScriptableObject.CreateInstance<AircraftCatalog>();AssetDatabase.CreateAsset(catalog,path);}
  var prefab=AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Resources/Aircraft/A320/A320.fbx");
  var entries=new System.Collections.Generic.List<AircraftEntry>{new AircraftEntry{Name="Airbus A320",ResourcePath="Aircraft/A320/A320",CockpitResourcePath="Aircraft/Cockpit/Cockpit",CockpitOffset=new Vector3(-.45f,.67f,13.72f),Length=37.6f,Source="FlightGear · legoboyvdlp / IDG A320 Family",License="GPL-2.0",YawOffset=180}};
  var fleet=JsonUtility.FromJson<FleetManifest>(File.ReadAllText("Assets/Skybound/Editor/FleetManifest.json"));
  foreach(var plane in fleet.aircraft){var resource="Aircraft/Fleet/"+plane.id+"/"+plane.id;if(!AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Resources/"+resource+".fbx"))throw new Exception("Missing fleet model "+plane.name);entries.Add(new AircraftEntry{Name=plane.name,ResourcePath=resource,Length=plane.length,Source=plane.source,License=plane.license,YawOffset=180,CockpitOffset=new Vector3(-.5f,1.4f,plane.length*.40f)});}
  entries.Add(new AircraftEntry{Name="Regional jet",ResourcePath="Aircraft/regional-airliner",Length=27,Source="3DAssets.dev · Vehicle Collection HD",License="CC0 1.0",YawOffset=180});
  if(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Resources/Aircraft/UserAirliner/UserAirliner.fbx")){var supplied=new AircraftEntry{Name="Boeing 777-300ER",ResourcePath="Aircraft/UserAirliner/UserAirliner",Length=73.9f,Source="User-supplied Boeing 777-300ER · neutral material",License="Royalty-free, as supplied by user",YawOffset=0,CockpitOffset=new Vector3(-.5f,1.4f,29.56f)};int existing=entries.FindIndex(e=>e.ResourcePath=="Aircraft/Fleet/B777/B777");if(existing>=0)entries[existing]=supplied;else entries.Add(supplied);}
  if(AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Resources/Aircraft/User737Max8/User737Max8.fbx"))entries.Add(new AircraftEntry{Name="Boeing 737 MAX 8",ResourcePath="Aircraft/User737Max8/User737Max8",Length=39.52f,Source="User-supplied 737 MAX 8 · neutral materials",License="User-supplied asset",YawOffset=0,CockpitOffset=new Vector3(-.5f,1.4f,15.8f)});
  catalog.Aircraft=entries.ToArray();
  EditorUtility.SetDirty(catalog);AssetDatabase.SaveAssets();
  return catalog;
 }
 public static void EnsureShaders(){
  var settings=AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset")[0];var serialized=new SerializedObject(settings);var list=serialized.FindProperty("m_AlwaysIncludedShaders");
  foreach(var name in new[]{"Skybound/Satellite","Skybound/Atmosphere","Universal Render Pipeline/Unlit"}){var shader=Shader.Find(name);if(!shader)throw new Exception("Missing shader: "+name);bool exists=false;for(int i=0;i<list.arraySize;i++)if(list.GetArrayElementAtIndex(i).objectReferenceValue==shader)exists=true;if(!exists){list.InsertArrayElementAtIndex(list.arraySize);list.GetArrayElementAtIndex(list.arraySize-1).objectReferenceValue=shader;}}
  serialized.ApplyModifiedPropertiesWithoutUndo();AssetDatabase.SaveAssets();
 }
 public static void ConvertMaterials(){Directory.CreateDirectory("Assets/Skybound/Materials");foreach(string guid in AssetDatabase.FindAssets("t:Model",new[]{"Assets/Resources/Aircraft"})){string p=AssetDatabase.GUIDToAssetPath(guid);var imp=(ModelImporter)AssetImporter.GetAtPath(p);string stamp="SkyboundURP:"+File.GetLastWriteTimeUtc(p).Ticks;if(imp.userData==stamp)continue;imp.ExtractTextures(Path.GetDirectoryName(p));imp.materialImportMode=ModelImporterMaterialImportMode.ImportStandard;imp.SaveAndReimport();
  foreach(var asset in AssetDatabase.LoadAllAssetsAtPath(p).OfType<Material>()){string safe=Path.GetFileNameWithoutExtension(p)+"_"+string.Concat(asset.name.Select(c=>char.IsLetterOrDigit(c)?c:'_'));string mp="Assets/Skybound/Materials/"+safe+".mat";var material=AssetDatabase.LoadAssetAtPath<Material>(mp);if(!material){material=new Material(asset);AssetDatabase.CreateAsset(material,mp);}Color color=asset.HasProperty("_BaseColor")?asset.GetColor("_BaseColor"):asset.HasProperty("_Color")?asset.GetColor("_Color"):Color.white;Texture tex=asset.HasProperty("_BaseMap")?asset.GetTexture("_BaseMap"):asset.HasProperty("_MainTex")?asset.GetTexture("_MainTex"):null;material.shader=Shader.Find("Universal Render Pipeline/Lit");material.SetColor("_BaseColor",color);material.SetTexture("_BaseMap",tex);material.SetFloat("_Smoothness",.32f);material.SetFloat("_Cull",0);EditorUtility.SetDirty(material);imp.AddRemap(new AssetImporter.SourceAssetIdentifier(typeof(Material),asset.name),material);}
  imp.userData=stamp;imp.SaveAndReimport();
 }
 AssetDatabase.SaveAssets();}
 [MenuItem("Skybound/Build Mac application")]
 public static void BuildMac(){Directory.CreateDirectory("../SkyboundMac");var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=new[]{"Assets/Skybound/Scenes/Skybound.unity"},locationPathName="../SkyboundMac/Skybound.app",target=BuildTarget.StandaloneOSX,options=BuildOptions.None});Debug.Log("SKYBOUND_BUILD_"+report.summary.result+" "+report.summary.totalSize);}
 public static string Validate(){var p=GeoMath.Project(40.773,-73.998);var c=GeoMath.Unproject(p.x,p.y);if(Math.Abs(c.x-40.773)>.00001||Math.Abs(c.y+73.998)>.00001)throw new Exception("Mercator roundtrip failed");if(GeoMath.DistanceToSegment(new Vector2(1,1),Vector2.zero,new Vector2(2,0))!=1)throw new Exception("Landing segment distance failed");return "Coordinate roundtrip and landing geometry passed";}
}
}
#endif
