#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;

namespace Skybound.Editor {
// Exercises the managed input path in a live Play Mode scene. GUI rendering and
// native phone input still need a visual/device check outside this validator.
public static class SideControlsValidation {
 public static string Run(SkyboundBootstrap b){
  if(!b||!b.HUD||!b.Aircraft||!b.CameraRig||!b.Mission)throw new InvalidOperationException("A running Skybound scene is required.");
  var hud=b.HUD;var aircraft=b.Aircraft;var camera=b.CameraRig;
  MenuPage savedMenu=hud.Menu;bool savedMobile=hud.MobileControls,savedJoystick=hud.MouseJoystick,savedActive=aircraft.Active,savedFinished=b.Mission.Finished;
  float savedThrottle=aircraft.Throttle,savedTouchPitch=aircraft.TouchPitch,savedTouchRoll=aircraft.TouchRoll,savedTimeScale=Time.timeScale;
  int savedFlaps=aircraft.Flaps;bool savedDiscover=camera.Discover,savedCockpit=camera.Cockpit,savedCabin=camera.Cabin;
  float savedOrbit=camera.Orbit,savedElevation=camera.OrbitElevation,savedDistance=camera.Distance;
  Vector3 savedCameraPosition=camera.transform.position;Quaternion savedCameraRotation=camera.transform.rotation;
  var view=camera.GetComponent<Camera>();float savedFov=view.fieldOfView,savedNearClip=view.nearClipPlane;
  bool savedVisualActive=aircraft.Visual.gameObject.activeSelf;var cockpit=hud.Visual.CockpitModel;bool savedCockpitActive=cockpit&&cockpit.activeSelf;
  CursorLockMode savedCursor=Cursor.lockState;bool savedCursorVisible=Cursor.visible;
  Touchscreen touch=null;Mouse mouse=null;Gamepad pad=null;var checks=new List<string>();
  try {
   Time.timeScale=0;aircraft.Active=false;b.Mission.Finished=false;hud.Menu=MenuPage.Flight;hud.MobileControls=hud.MouseJoystick=true;
   camera.Discover=camera.Cockpit=camera.Cabin=false;hud.SendMessage("ReleaseFlightControls");camera.SendMessage("OnDisable");
   // Dedicated neutral devices prevent a previously connected controller or mouse
   // from adding camera movement to the injected touch gestures.
   touch=InputSystem.AddDevice<Touchscreen>();mouse=InputSystem.AddDevice<Mouse>();pad=InputSystem.AddDevice<Gamepad>();
   InputState.Change(mouse,new MouseState());InputState.Change(pad,new GamepadState());camera.SendMessage("LateUpdate");
   Vector2 stick=hud.StickArea.center+new Vector2(40,50),thrust=new Vector2(hud.ThrustArea.center.x,297);
   Require(hud.PointerOverControl(Pixel(hud,stick)),"Joystick bounds do not exclude camera input.");
   Require(hud.PointerOverControl(Pixel(hud,thrust)),"Thrust bounds do not exclude camera input.");
   Vector2 controlCamera=new Vector2(camera.Orbit,camera.OrbitElevation);

   SendTouch(touch,hud,1,UnityEngine.InputSystem.TouchPhase.Began,stick,Vector2.zero);
   Require(aircraft.TouchPitch>0&&aircraft.TouchRoll>0,"First finger did not hold the mobile joystick.");
   camera.SendMessage("LateUpdate");RequireCameraUnchanged(camera,controlCamera,"Joystick touch");
   SendTouch(touch,hud,2,UnityEngine.InputSystem.TouchPhase.Began,thrust,Vector2.zero);
   RequireNear(aircraft.Throttle,1,"Thrust maximum");camera.SendMessage("LateUpdate");RequireCameraUnchanged(camera,controlCamera,"Thrust touch begin");
   MoveThrust(touch,hud,camera,240,thrust.y,controlCamera);RequireNear(aircraft.Throttle,1,"Thrust upper clamp");
   MoveThrust(touch,hud,camera,397,240,controlCamera);RequireNear(aircraft.Throttle,.5f,"Thrust midpoint");
   Require(aircraft.TouchPitch>0&&aircraft.TouchRoll>0,"Second finger interrupted joystick steering.");

   SendTouch(touch,hud,1,UnityEngine.InputSystem.TouchPhase.Ended,stick,Vector2.zero);
   RequireNear(aircraft.TouchPitch,0,"Joystick release pitch");RequireNear(aircraft.TouchRoll,0,"Joystick release roll");
   MoveThrust(touch,hud,camera,600,397,controlCamera);RequireNear(aircraft.Throttle,0,"Thrust idle lower clamp after joystick release");
   MoveThrust(touch,hud,camera,347,600,controlCamera);RequireNear(aircraft.Throttle,.75f,"Independent thrust finger retained");
   SendTouch(touch,hud,2,UnityEngine.InputSystem.TouchPhase.Ended,new Vector2(thrust.x,347),Vector2.zero);
   RequireNear(aircraft.Throttle,.75f,"Released thrust setting retained");
   checks.Add("Touch thrust reaches MAX, midpoint and IDLE, clamps beyond both ends, and retains its setting after release.");
   checks.Add("Simultaneous joystick/thrust touches work independently; ending the joystick touch preserves the thrust drag.");

   aircraft.Flaps=2;
   for(int setting=0;setting<3;setting++){
    Vector2 point=hud.FlapArea(setting).center;
    Require(hud.PointerOverControl(Pixel(hud,point)),"Flap button bounds do not exclude camera input.");
    SendTouch(touch,hud,3,UnityEngine.InputSystem.TouchPhase.Began,point,Vector2.zero);camera.SendMessage("LateUpdate");
    Require(aircraft.Flaps==setting,"Flap touch did not select setting "+setting+".");RequireCameraUnchanged(camera,controlCamera,"Flap touch");
    SendTouch(touch,hud,3,UnityEngine.InputSystem.TouchPhase.Ended,point,Vector2.zero);
    Require(aircraft.Flaps==setting,"Flap selection changed on touch release.");
   }
   checks.Add("Touch taps select and retain flap commands 0, 1 and 2 without moving the camera.");

   SendMouse(mouse,hud,new Vector2(thrust.x,297),true,Vector2.zero);camera.SendMessage("LateUpdate");
   RequireNear(aircraft.Throttle,1,"Mouse thrust maximum");RequireCameraUnchanged(camera,controlCamera,"Mouse thrust press");
   SendMouse(mouse,hud,new Vector2(thrust.x,397),true,new Vector2(0,-50));camera.SendMessage("LateUpdate");
   RequireNear(aircraft.Throttle,.5f,"Mouse thrust midpoint");RequireCameraUnchanged(camera,controlCamera,"Mouse thrust midpoint drag");
   SendMouse(mouse,hud,new Vector2(thrust.x,600),true,new Vector2(0,-100));camera.SendMessage("LateUpdate");
   RequireNear(aircraft.Throttle,0,"Mouse thrust idle lower clamp");RequireCameraUnchanged(camera,controlCamera,"Mouse thrust idle drag");
   SendMouse(mouse,hud,new Vector2(thrust.x,447),true,Vector2.zero);
   SendMouse(mouse,hud,new Vector2(thrust.x,447),false,Vector2.zero);camera.SendMessage("LateUpdate");
   RequireNear(aircraft.Throttle,.25f,"Mouse released thrust setting retained");
   // Crossing the lever during an existing sky drag must not acquire it.
   Vector2 sky=new Vector2(760,390);
   SendMouse(mouse,hud,sky,true,Vector2.zero);
   SendMouse(mouse,hud,new Vector2(thrust.x,297),true,Vector2.zero);
   RequireNear(aircraft.Throttle,.25f,"Mouse drag beginning outside the thrust rail");
   SendMouse(mouse,hud,new Vector2(thrust.x,297),false,Vector2.zero);camera.SendMessage("LateUpdate");
   checks.Add("Injected mouse presses and drags set thrust MAX, midpoint and IDLE, retain the setting on release, and cannot capture a drag that began outside the rail.");

   // The side panel is excluded from mouse camera look independently of IMGUI
   // slider/button dispatch. This does not claim to click rendered GUI buttons.
   Vector2 panelPoint=hud.ThrustArea.center;
   SendMouse(mouse,hud,panelPoint,true,new Vector2(60,30));camera.SendMessage("LateUpdate");
   RequireCameraUnchanged(camera,controlCamera,"Mouse drag starting on the side panel");
   SendMouse(mouse,hud,panelPoint,false,Vector2.zero);camera.SendMessage("LateUpdate");
   Require(!hud.PointerOverControl(Pixel(hud,sky)),"The clear sky was marked as a flight control.");
   SendMouse(mouse,hud,sky,true,new Vector2(60,0));camera.SendMessage("LateUpdate");
   Require(camera.Orbit>controlCamera.x+.1f,"Mouse drag outside the side panel did not rotate the camera.");
   SendMouse(mouse,hud,sky,false,Vector2.zero);camera.SendMessage("LateUpdate");
   checks.Add("Left mouse drag on the side panel leaves the camera still; a drag over clear sky rotates it.");

   float touchOrbit=camera.Orbit;
   SendTouch(touch,hud,4,UnityEngine.InputSystem.TouchPhase.Began,sky,Vector2.zero);camera.SendMessage("LateUpdate");
   Vector2 movedSky=sky+new Vector2(80,0);
   SendTouch(touch,hud,4,UnityEngine.InputSystem.TouchPhase.Moved,movedSky,Pixel(hud,movedSky)-Pixel(hud,sky));camera.SendMessage("LateUpdate");
   Require(camera.Orbit>touchOrbit+.1f,"Touch drag outside the side panel did not rotate the camera.");
   SendTouch(touch,hud,4,UnityEngine.InputSystem.TouchPhase.Ended,movedSky,Vector2.zero);camera.SendMessage("LateUpdate");
   checks.Add("A touch drag over clear sky still rotates the camera.");
   string result="SKYBOUND_SIDE_CONTROLS_PASSED\n"+string.Join("\n",checks)+"\nManaged Input System injection only; GUI rendering and native phone input were not tested by this validator.";
   Debug.Log(result);return result;
  } finally {
   if(touch!=null&&touch.added)InputSystem.RemoveDevice(touch);
   if(mouse!=null&&mouse.added)InputSystem.RemoveDevice(mouse);
   if(pad!=null&&pad.added)InputSystem.RemoveDevice(pad);
   hud.SendMessage("ReleaseFlightControls");camera.SendMessage("OnDisable");
   hud.Menu=savedMenu;hud.MobileControls=savedMobile;hud.MouseJoystick=savedJoystick;
   aircraft.Active=savedActive;aircraft.Throttle=savedThrottle;aircraft.Flaps=savedFlaps;aircraft.TouchPitch=savedTouchPitch;aircraft.TouchRoll=savedTouchRoll;b.Mission.Finished=savedFinished;
   camera.Discover=savedDiscover;camera.Cockpit=savedCockpit;camera.Cabin=savedCabin;camera.Orbit=savedOrbit;camera.OrbitElevation=savedElevation;camera.Distance=savedDistance;
   camera.transform.SetPositionAndRotation(savedCameraPosition,savedCameraRotation);view.fieldOfView=savedFov;view.nearClipPlane=savedNearClip;
   aircraft.Visual.gameObject.SetActive(savedVisualActive);if(cockpit)cockpit.SetActive(savedCockpitActive);
   Cursor.lockState=savedCursor;Cursor.visible=savedCursorVisible;Time.timeScale=savedTimeScale;
  }
 }
 static Vector2 Pixel(FlightHUD hud,Vector2 gui){
  Rect safe=hud.MobileControls?Screen.safeArea:new Rect(0,0,Screen.width,Screen.height);
  float scale=Mathf.Min(safe.width/1440f,safe.height/900f);
  Vector2 point=new Vector2(safe.x+(safe.width-1440*scale)/2+gui.x*scale,safe.yMax-(safe.height-900*scale)/2-gui.y*scale);
  Require(Vector2.Distance(hud.GuiPoint(point),gui)<.02f,"Safe-area GUI coordinate conversion is inconsistent.");return point;
 }
 static void SendTouch(Touchscreen touch,FlightHUD hud,int id,UnityEngine.InputSystem.TouchPhase phase,Vector2 gui,Vector2 delta){
  InputSystem.QueueStateEvent(touch,new TouchState{touchId=id,phase=phase,position=Pixel(hud,gui),delta=delta});InputSystem.Update();hud.SendMessage("Update");
 }
 static void SendMouse(Mouse mouse,FlightHUD hud,Vector2 gui,bool held,Vector2 delta){
  var state=new MouseState{position=Pixel(hud,gui),delta=delta};if(held)state=state.WithButton(MouseButton.Left);InputState.Change(mouse,state);hud.SendMessage("Update");
 }
 static void MoveThrust(Touchscreen touch,FlightHUD hud,FlightCamera camera,float y,float previousY,Vector2 cameraAngles){
  Vector2 p=new Vector2(hud.ThrustArea.center.x,y),previous=new Vector2(p.x,previousY);
  SendTouch(touch,hud,2,UnityEngine.InputSystem.TouchPhase.Moved,p,Pixel(hud,p)-Pixel(hud,previous));camera.SendMessage("LateUpdate");RequireCameraUnchanged(camera,cameraAngles,"Thrust touch drag");
 }
 static void RequireCameraUnchanged(FlightCamera camera,Vector2 angles,string gesture){Require(Mathf.Abs(camera.Orbit-angles.x)<.001f&&Mathf.Abs(camera.OrbitElevation-angles.y)<.001f,gesture+" moved the camera.");}
 static void RequireNear(float value,float expected,string check){Require(Mathf.Abs(value-expected)<.002f,check+" failed: expected "+expected+", got "+value+".");}
 static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
}
}
#endif
