#if UNITY_EDITOR
using System;
using System.Collections;
using System.IO;
using System.Text;
using UnityEngine;
namespace Skybound.Editor {
public static class ScenarioValidation {
 public static IEnumerator Run(SkyboundBootstrap b){
  var report=new StringBuilder("Accelerated approaches against streamed imagery and elevation\n");int failures=0;
  b.CameraRig.Cockpit=b.CameraRig.Cabin=false;b.HUD.Visual.Select(0);
  while(b.HUD.Visual.Loading)yield return null;
  foreach(var mode in new[]{FlightMode.Hudson,FlightMode.Glide,FlightMode.Crosswind,FlightMode.SingleEngine,FlightMode.FuelEmergency,FlightMode.GearFailure,FlightMode.SevereWeather}){
   b.Mission.StartFlight(mode,assist:true);b.HUD.Menu=MenuPage.Flight;b.Aircraft.Active=false;Time.timeScale=0;
   float deadline=Time.realtimeSinceStartup+35;
   while((b.World.LoadedTiles<70||!b.World.SurfaceLoaded(b.Aircraft.transform.position))&&Time.realtimeSinceStartup<deadline)yield return null;
   if(!b.World.SurfaceLoaded(b.Aircraft.transform.position))throw new Exception("Scenery timeout for "+mode);
   for(int step=0;step<15000&&!b.Mission.Finished;step++){
    b.Aircraft.Active=true;b.Aircraft.Step(.02f,0,0);b.Mission.SendMessage("Update");
    if(step%200==0&&!b.Mission.Finished){b.Aircraft.Active=false;b.World.SendMessage("RefreshTiles");yield return null;
     deadline=Time.realtimeSinceStartup+30;
     while(!b.World.SurfaceLoaded(b.Aircraft.transform.position)&&Time.realtimeSinceStartup<deadline)yield return null;
    }
   }
   b.Aircraft.Active=false;Time.timeScale=0;
   string line=$"{mode}: finished={b.Mission.Finished}, success={b.Mission.Success}, seconds={b.Aircraft.Elapsed:F2}, speedKt={b.Mission.LandingSpeed:F2}, sink={b.Mission.LandingSink:F3}, bank={b.Mission.LandingBank:F3}, pitch={b.Aircraft.Pitch:F3}, result={b.Mission.Result}";
   report.AppendLine(line);Debug.Log("SKYBOUND_APPROACH "+line);if(!b.Mission.Finished||!b.Mission.Success)failures++;
  }
  report.AppendLine("Failed approaches: "+failures);File.WriteAllText("scenario-validation.txt",report.ToString());Debug.Log("SKYBOUND_SCENARIOS_COMPLETE failures="+failures);
  b.HUD.Menu=MenuPage.Discover;b.CameraRig.Discover=true;
 }
}
}
#endif
