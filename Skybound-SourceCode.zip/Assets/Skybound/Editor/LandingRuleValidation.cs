#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace Skybound.Editor {
// Tests landing assessment, with synthetic touchdown conditions on already
// streamed dry land. Actual approach trajectories are validated separately.
public static class LandingRuleValidation {
 public static string Run(SkyboundBootstrap b){
  if(!b||!b.Aircraft||!b.Mission||!b.World)throw new InvalidOperationException("A running Skybound scene is required.");
  if(!b.World.SurfaceLoaded(Vector3.zero)||b.World.LooksLikeWater(Vector3.zero))throw new InvalidOperationException("Load the Heathrow dry-land scenery before landing-rule validation.");
  foreach(var key in new[]{KeyCode.LeftShift,KeyCode.RightShift,KeyCode.LeftControl,KeyCode.RightControl,KeyCode.Q,KeyCode.C,KeyCode.Space})if(FlightInput.Hold(key))throw new InvalidOperationException("Release "+key+" before landing-rule validation.");
  var a=b.Aircraft;var m=b.Mission;var aircraftState=Snapshot(a);var missionState=Snapshot(m);
  Vector3 savedPosition=a.transform.position;Quaternion savedRotation=a.transform.rotation;float savedTimeScale=Time.timeScale;
  var checks=new List<string>();
  try {
   Time.timeScale=0;
   // Deploy/retract through actual simulation steps rather than setting the
   // read-only deployment property to manufacture a passing touchdown.
   a.World=null;a.Mission=null;a.ResetFlight(2000,85,0,false);a.Assist=false;a.Flaps=2;for(int i=0;i<310;i++)a.Step(.02f,0,0);
   Require(a.FlapPosition>1.9f,"Full flaps did not deploy during preparation.");var fullFlapState=Snapshot(a);
   a.Flaps=0;for(int i=0;i<310;i++)a.Step(.02f,0,0);Require(a.FlapPosition<.05f,"Flaps did not retract during preparation.");var cleanState=Snapshot(a);
   FlightMode[] modes={FlightMode.SingleEngine,FlightMode.FuelEmergency,FlightMode.GearFailure,FlightMode.SevereWeather};
   foreach(var mode in modes){
    Check(b,mode,fullFlapState,null,true,"gentle correctly configured touchdown",checks);
    Check(b,mode,fullFlapState,f=>f.Speed=120,false,"overspeed touchdown",checks);
    Check(b,mode,fullFlapState,f=>f.VerticalSpeed=-7,false,"hard descent",checks);
    Check(b,mode,fullFlapState,f=>f.Roll=16,false,"excessive bank",checks);
    Check(b,mode,fullFlapState,f=>f.Gear=mode==FlightMode.GearFailure,false,"incorrect gear configuration",checks);
    Check(b,mode,fullFlapState,f=>f.Stalled=true,false,"stalled touchdown",checks);
    Check(b,mode,fullFlapState,f=>f.transform.position+=new Vector3(120,0,0),false,"outside the marked runway",checks);
   }
   Check(b,FlightMode.GearFailure,cleanState,null,false,"belly landing with retracted flaps",checks);
   Check(b,FlightMode.GearFailure,fullFlapState,f=>f.VerticalSpeed=-3.1f,false,"belly landing over its 3 m/s sink limit",checks);
   Check(b,FlightMode.GearFailure,fullFlapState,f=>f.Roll=7.1f,false,"belly landing over its 7 degree bank limit",checks);
   Check(b,FlightMode.GearFailure,fullFlapState,f=>f.Speed=90.1f,false,"belly landing over its 90 m/s speed limit",checks);
   Check(b,FlightMode.SingleEngine,fullFlapState,f=>f.VerticalSpeed=-4.6f,false,"single-engine landing over its 4.5 m/s sink limit",checks);
   Check(b,FlightMode.SevereWeather,fullFlapState,f=>f.VerticalSpeed=-4.6f,false,"weather landing over its 4.5 m/s sink limit",checks);
   Check(b,FlightMode.SevereWeather,fullFlapState,f=>f.Heading=21,false,"weather landing outside runway heading tolerance",checks);
   string result="SKYBOUND_LANDING_RULES_PASSED\n"+string.Join("\n",checks)+"\nSynthetic touchdown assessment only; actual assisted approaches and native-device controls are separate checks.";Debug.Log(result);return result;
  } finally {
   Restore(a,aircraftState);Restore(m,missionState);a.transform.SetPositionAndRotation(savedPosition,savedRotation);Time.timeScale=savedTimeScale;
  }
 }
 static void Check(SkyboundBootstrap b,FlightMode mode,Dictionary<FieldInfo,object> prepared,Action<FlightController> change,bool expected,string name,List<string> checks){
  var a=b.Aircraft;var m=b.Mission;Restore(a,prepared);a.World=b.World;a.Mission=m;a.Active=true;a.Assist=false;
  a.Speed=80;a.Pitch=4;a.Roll=a.Heading=0;a.VerticalSpeed=-2;a.Stalled=a.Grounded=false;a.Gear=mode!=FlightMode.GearFailure;a.GearJammedUp=mode==FlightMode.GearFailure;
  float ground=b.World.HeightAt(Vector3.zero);a.transform.SetPositionAndRotation(new Vector3(0,ground+a.GroundClearance,0),Quaternion.identity);
  m.Mode=mode;m.Finished=m.Success=false;m.Result=m.Message="";m.RunwayWidth=70;m.RunwayAltitude=ground;m.RunwayStart=new Vector3(0,ground,-1200);m.RunwayEnd=new Vector3(0,ground,1200);
  change?.Invoke(a);m.Touchdown();Require(m.Finished&&m.Success==expected,mode+" / "+name+": expected "+(expected?"accept":"reject")+", got "+m.Success+" ("+m.Result+")");
  checks.Add(mode+": "+(expected?"accepted ":"rejected ")+name+".");
 }
 // Restore captured managed states between conditions and on cleanup, including
 // read-only simulation/interpolation backing fields; assess landings through Touchdown.
 static Dictionary<FieldInfo,object> Snapshot(object value){var state=new Dictionary<FieldInfo,object>();foreach(var field in value.GetType().GetFields(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.DeclaredOnly))if(!field.IsInitOnly)state[field]=field.GetValue(value);return state;}
 static void Restore(object value,Dictionary<FieldInfo,object> state){foreach(var item in state)item.Key.SetValue(value,item.Value);}
 static void Require(bool condition,string message){if(!condition)throw new InvalidOperationException(message);}
}
}
#endif
