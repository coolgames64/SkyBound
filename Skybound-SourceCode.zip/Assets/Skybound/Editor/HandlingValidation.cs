using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace Skybound.EditorTools {
// Deterministic checks use isolated, disabled components and never advance the live aircraft.
public static class HandlingValidation {
 const float Dt=.02f;
 static readonly KeyCode[] ExternalKeys={KeyCode.LeftShift,KeyCode.RightShift,KeyCode.LeftControl,KeyCode.RightControl,KeyCode.Q,KeyCode.C,KeyCode.Space};

 public static string Run(){
  foreach(var key in ExternalKeys)if(FlightInput.Hold(key))throw new InvalidOperationException("Release "+key+" before running the isolated handling checks.");
  var objects=new List<GameObject>();var report=new StringBuilder("Skybound aerodynamic handling validation\n");var failures=new List<string>();
  try {
   CheckGlide(objects,report,failures);
   CheckPitch(objects,report,failures);
   CheckBank(objects,report,failures);
   CheckThrust(objects,report,failures);
   CheckFlaps(objects,report,failures);
   CheckTimestep(objects,report,failures);
   CheckResetAndRebase(objects,report,failures);
  }finally{foreach(var go in objects)if(go)UnityEngine.Object.DestroyImmediate(go);}
  if(failures.Count>0)throw new InvalidOperationException(report+"FAILED: "+string.Join("; ",failures));
  report.Append("All isolated handling checks passed.\n");return report.ToString();
 }

 static FlightController Create(List<GameObject> objects,float speed=85){var go=new GameObject("Isolated handling validation"){hideFlags=HideFlags.HideAndDontSave};objects.Add(go);var f=go.AddComponent<FlightController>();f.enabled=false;f.ResetFlight(2000,speed,0,false);f.Assist=false;return f;}
 static void Simulate(FlightController f,float seconds,float pitch=0,float roll=0,float step=Dt){int count=Mathf.RoundToInt(seconds/step);for(int i=0;i<count;i++){f.Step(step,pitch,roll);Finite(f);}}
 static void Finite(FlightController f){if(float.IsNaN(f.Speed)||float.IsInfinity(f.Speed)||float.IsNaN(f.VerticalSpeed)||float.IsInfinity(f.VerticalSpeed)||float.IsNaN(f.FlightPathAngle)||float.IsInfinity(f.FlightPathAngle)||float.IsNaN(f.Altitude)||float.IsInfinity(f.Altitude))throw new InvalidOperationException("Simulation produced a non-finite value.");}
 static float Energy(FlightController f)=>.5f*f.Speed*f.Speed+9.81f*f.Altitude;
 static void Check(bool condition,string name,string detail,StringBuilder report,List<string> failures){report.Append(condition?"PASS ":"FAIL ").Append(name).Append(": ").Append(detail).Append('\n');if(!condition)failures.Add(name);}

 static void CheckGlide(List<GameObject> objects,StringBuilder report,List<string> failures){
  var f=Create(objects,70);f.Engines=false;f.Throttle=0;Simulate(f,8); // Let any remaining turbine spool decay before testing powerless energy.
  f.Speed=70;f.Pitch=f.FlightPathAngle;float initialEnergy=Energy(f),initialAltitude=f.Altitude,previous=initialEnergy,maxGain=float.NegativeInfinity;
  for(int i=0;i<500;i++){f.Step(Dt,0,0);Finite(f);float next=Energy(f);maxGain=Mathf.Max(maxGain,next-previous);previous=next;}
  float loss=initialEnergy-Energy(f);
  Check(loss>50&&maxGain<.5f,"Powerless glide loses energy",$"loss={loss:F2} J/kg over10s, largest per-step gain={maxGain:F4} J/kg, final speed={f.Speed:F2} m/s",report,failures);
  Check(f.Altitude<initialAltitude&&f.Speed>20,"Powerless glide remains airborne",$"altitude change={f.Altitude-initialAltitude:F2} m, flight-path angle={f.FlightPathAngle:F2} degrees",report,failures);
 }

 static void CheckPitch(List<GameObject> objects,StringBuilder report,List<string> failures){
  var f=Create(objects);Simulate(f,.6f,.8f);float attitude=f.Pitch,path=f.FlightPathAngle,rate=f.PitchRate;
  Check(attitude>.1f&&rate>.1f&&Mathf.Abs(attitude-path)>.1f,"Attitude and flight path are independent",$"pitch={attitude:F3}, flight path={path:F3}, pitch rate={rate:F3} deg/s",report,failures);
  f.Step(Dt,0,0);float releaseRate=f.PitchRate,releasePitch=f.Pitch;Simulate(f,2);
  Check(releasePitch>attitude&&releaseRate>0&&Mathf.Abs(f.PitchRate)<Mathf.Abs(rate)*.35f,"Pitch momentum continues then damps",$"release rate={releaseRate:F3}, rate after2s={f.PitchRate:F3} deg/s, first release pitch change={releasePitch-attitude:F4} degrees",report,failures);
 }

 static void CheckBank(List<GameObject> objects,StringBuilder report,List<string> failures){
  var f=Create(objects);f.Roll=30;float heading=f.Heading;Simulate(f,1);
  float turn=Mathf.DeltaAngle(heading,f.Heading);
  Check(Mathf.Abs(f.Roll-30)<2&&turn>1,"Unassisted bank holds and turns",$"bank={f.Roll:F3} degrees after1s, heading change={turn:F3} degrees",report,failures);
 }

 static void CheckThrust(List<GameObject> objects,StringBuilder report,List<string> failures){
  var f=Create(objects);f.Throttle=0;Simulate(f,8);float idle=f.EnginePower;f.Throttle=1;float immediate=f.EnginePower;f.Step(Dt,0,0);float first=f.EnginePower;Simulate(f,3);float later=f.EnginePower;
  Check(Mathf.Abs(immediate-idle)<.0001f&&first-idle<.15f&&later>idle+.3f&&later<=1.001f,"Thrust command spools over time",$"idle={idle:F3}, immediate={immediate:F3}, first step={first:F3}, after3s={later:F3}",report,failures);
 }

 static void CheckFlaps(List<GameObject> objects,StringBuilder report,List<string> failures){
  var clean=Create(objects);var flapped=Create(objects);clean.Engines=flapped.Engines=false;clean.Throttle=flapped.Throttle=0;float cleanStall=clean.StallSpeed;
  flapped.Flaps=2;float immediate=flapped.FlapPosition;flapped.Step(Dt,0,0);float first=flapped.FlapPosition;Simulate(flapped,6);Simulate(clean,6+Dt);
  float deployed=flapped.FlapPosition;
  Check(immediate<.001f&&first>0&&first<.05f&&deployed>1.9f,"Flaps deploy rather than jump",$"immediate={immediate:F3}, first step={first:F4}, after6s={deployed:F3} detents",report,failures);
  // Match airspeed, angle of attack and bank after deployment, independent of each preceding flight path.
  clean.Speed=flapped.Speed=85;clean.Roll=flapped.Roll=0;clean.Pitch=clean.FlightPathAngle;flapped.Pitch=flapped.FlightPathAngle;
  clean.Step(Dt,0,0);flapped.Step(Dt,0,0);
  float liftDelta=flapped.LiftAcceleration-clean.LiftAcceleration,dragDelta=flapped.DragAcceleration-clean.DragAcceleration;
  Check(Mathf.Abs(clean.AngleOfAttack-flapped.AngleOfAttack)<.1f&&liftDelta>.1f&&dragDelta>.05f&&flapped.StallSpeed<cleanStall-2,"Flaps increase lift and drag and lower stall speed",$"AoA clean/full={clean.AngleOfAttack:F3}/{flapped.AngleOfAttack:F3}, lift delta={liftDelta:F3}, drag delta={dragDelta:F3} m/s², stall clean/full={cleanStall:F2}/{flapped.StallSpeed:F2} m/s",report,failures);
 }

 static void CheckTimestep(List<GameObject> objects,StringBuilder report,List<string> failures){
  var fine=Trajectory(objects,.01f);var nominal=Trajectory(objects,.02f);var coarse=Trajectory(objects,.04f);
  float positionDelta=Mathf.Max(Vector3.Distance(fine.transform.position,nominal.transform.position),Vector3.Distance(fine.transform.position,coarse.transform.position));
  float speedDelta=Mathf.Max(Mathf.Abs(fine.Speed-nominal.Speed),Mathf.Abs(fine.Speed-coarse.Speed));
  float attitudeDelta=Mathf.Max(Mathf.Abs(fine.Pitch-coarse.Pitch),Mathf.Max(Mathf.Abs(fine.Roll-coarse.Roll),Mathf.Abs(Mathf.DeltaAngle(fine.Heading,coarse.Heading))));
  Check(positionDelta<6&&speedDelta<.75f&&attitudeDelta<1,"Fixed-step trajectory remains consistent",$"dt .01/.02/.04 over10s: largest position delta={positionDelta:F3} m, speed delta={speedDelta:F3} m/s, coarse attitude delta={attitudeDelta:F3} degrees",report,failures);
 }
 static FlightController Trajectory(List<GameObject> objects,float dt){var f=Create(objects);f.Throttle=.7f;int count=Mathf.RoundToInt(10/dt);for(int i=0;i<count;i++){float t=i*dt;f.Step(dt,t<2?.25f:0,t<4?.3f:0);Finite(f);}return f;}

 static void CheckResetAndRebase(List<GameObject> objects,StringBuilder report,List<string> failures){
  var f=Create(objects);f.Flaps=2;Simulate(f,2,.4f,.3f);f.ResetFlight(2000,85,90,false);
  bool reset=f.Pitch==0&&f.Roll==0&&Mathf.Abs(f.PitchRate)<.0001f&&Mathf.Abs(f.RollRate)<.0001f&&f.FlapPosition<.001f&&Vector3.Distance(f.RenderPosition,f.transform.position)<.001f;
  Vector3 before=f.transform.position,render=f.RenderPosition,shift=new Vector3(10000,0,-20000);float speed=f.Speed;f.Rebase(shift);
  bool rebased=Vector3.Distance(f.transform.position,before-shift)<.001f&&Vector3.Distance(f.RenderPosition,render-shift)<.001f&&Mathf.Abs(f.Speed-speed)<.001f;
  Check(reset&&rebased,"Reset and floating origin preserve valid poses",$"reset={reset}, rebase={rebased}, altitude={f.Altitude:F2} m",report,failures);
 }
}
}
